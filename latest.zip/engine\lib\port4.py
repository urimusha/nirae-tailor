"""Bloodrake [NeoLithe] -> Crimson Body port (all chest, belly and hips/legs options, all builds).
Pipeline (see ffxiv-outfit-port skill):
  * each chest option is fitted from the author size closest to it (XS or S, measured through shared Bibo UVs)
  * cloth on the author's skin is glued to the same skin spot of our body (exact UV interpolation) at the author's
    exact height; bridging/free cloth (straps, frills, the long skirt) gets a smooth fill of the displacement
  * clipping: one smooth lift field along the skin normal shared by every layer
  * belly (none/soft/full) and hips (small/medium/large): attribute variants of the cloth near the moving skin,
    displaced by the body's own shape field, propagated smoothly into hanging cloth
  * weights: the body's own skin + jiggle weights at the same skin spot (skirt bones kept)"""
import sys, os, json, copy as _copy
from surf import *
from scipy.sparse import coo_matrix, diags, identity
from scipy.sparse.linalg import splu


GAP = float(os.environ.get('GAP', '0.002'))
PICK = None   # filled by measuring
DIST = {}
REF = 'medium'

# ---------------------------------------------------------------- cloth graph + smooth solves
def weld_key(V, tol=2e-5):
    """same id for vertices closer than tol (seam duplicates), robust to rounding boundaries"""
    from scipy.sparse.csgraph import connected_components
    pr = cKDTree(V).query_pairs(tol, output_type='ndarray')
    A = coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(V), len(V)))
    return connected_components(A, directed=False)[1]

class Graph:
    def __init__(s, V0, T):
        key = weld_key(V0); n = key.max() + 1
        Tk = key[T]
        r = np.r_[Tk[:, 0], Tk[:, 1], Tk[:, 2], Tk[:, 1], Tk[:, 2], Tk[:, 0]]; c = np.r_[Tk[:, 1], Tk[:, 2], Tk[:, 0], Tk[:, 0], Tk[:, 1], Tk[:, 2]]
        A = coo_matrix((np.ones(len(r)), (r, c)), shape=(n, n)).tocsr(); A.data[:] = 1; A.setdiag(0); A.eliminate_zeros()
        deg = np.asarray(A.sum(1)).ravel(); s.deg = deg
        W = diags(1 / np.maximum(deg, 1)) @ A
        s.key, s.n, s.A, s.W = key, n, A, W
        s.L = (identity(n, format='csr') - W)
        dm = diags(1 / np.sqrt(np.maximum(deg, 1)))
        s.Ls = identity(n, format='csr') - dm @ A @ dm
        s.cnt = np.bincount(key, minlength=n)
        s.W0 = s.avg(V0)
        from scipy.sparse.csgraph import connected_components
        s.ncomp, s.comp = connected_components(A, directed=False)
    def avg(s, X):
        out = np.zeros((s.n,) + X.shape[1:]); np.add.at(out, s.key, X); return out / s.cnt.reshape((-1,) + (1,) * (X.ndim - 1))
    def solve(s, wa, target, mu=0.6, nu=0.02):
        """minimise sum wa|d-target|^2 + mu|L d|^2 + nu d'Ls d  (welded vertices)"""
        M = (diags(wa) + mu * (s.L.T @ s.L) + nu * s.Ls).tocsc()
        lu = splu(M)
        return np.stack([lu.solve(wa * target[:, i]) for i in range(target.shape[1])], 1)

def G_avg_bool(G, b):
    out = np.ones(G.n, bool); np.logical_and.at(out, G.key, b); return out

def frames(G, V0, P, N0, T0):
    """rotate normals/tangents with the local deformation (polar decomposition of the 1-ring)"""
    W0 = G.avg(V0); W1 = G.avg(P)
    A = G.A.tocoo(); e0 = W0[A.col] - W0[A.row]; e1 = W1[A.col] - W1[A.row]
    M = np.zeros((G.n, 3, 3)); np.add.at(M, A.row, e1[:, :, None] * e0[:, None, :])
    U, S, Vt = np.linalg.svd(M); D = np.ones((G.n, 3)); D[:, 2] = np.sign(np.linalg.det(U @ Vt))
    R = U @ (D[:, :, None] * Vt)
    bad = S[:, 1] < 1e-12; R[bad] = np.eye(3)
    Rv = R[G.key]
    return np.einsum('nij,nj->ni', Rv, N0), np.einsum('nij,nj->ni', Rv, T0)

def cloth_data(m):
    V = attr(m, 0)[0][:, :3].astype(float); N = attr(m, 3)[0][:, :3].astype(float)
    tg = np.frombuffer(m['streams'][1], np.uint8).reshape(m['nv'], -1)[:, 12:15] / 255 * 2 - 1
    return V, N, tg.astype(float), np.frombuffer(m['idx'], np.uint16).astype(int).reshape(-1, 3)

# ---------------------------------------------------------------- fitting one chest option
def fit_chest(B, A, X, ch, log):
    tri, w, err = uv_map(A, B)
    QA = B.at(tri, w); NA = B.at(tri, w, B.N); NA /= np.linalg.norm(NA, axis=1)[:, None]
    if CFG.get('smooth_nipples'):
        # tight fabric bridges over the nipples: glue to a smoothed copy of our chest (collision still uses the real skin)
        Ps_ = B.P.copy(); reg_ = (B.part == 0) & (B.P[:, 1] > 1.10) & (B.P[:, 1] < 1.33) & (B.P[:, 2] > 0.03)
        nb_ = cKDTree(B.P).query_ball_point(B.P[reg_], 0.012); idx_ = np.where(reg_)[0]
        for _ in range(3):
            Ps_[idx_] = np.array([Ps_[j].mean(0) for j in nb_])
        QA = np.einsum('ni,nid->nd', w, Ps_[B.T[tri]])
    if CFG.get('smooth_crotch'):
        # tight fabric bridges the cleft between the thighs at the crotch instead of following each thigh into it:
        # glue to a copy of our skin smoothed across both thighs there (collision still uses the real skin)
        Pc = B.P.copy(); y, x, z = B.P[:, 1], np.abs(B.P[:, 0]), B.P[:, 2]
        fw = (B.part == 1) * np.clip((0.95 - y) / 0.04, 0, 1) * np.clip((y - 0.74) / 0.03, 0, 1) * np.clip((0.085 - x) / 0.03, 0, 1) * np.clip((z + 0.03) / 0.03, 0, 1)
        idx_ = np.where(fw > 0)[0]; nb_ = cKDTree(B.P).query_ball_point(B.P[idx_], 0.015)
        for _ in range(4):
            Pn = np.array([Pc[j].mean(0) for j in nb_]); Pc[idx_] += fw[idx_, None] * (Pn - Pc[idx_])
        base_ = QA if CFG.get('smooth_nipples') else B.at(tri, w)
        QA = base_ + np.einsum('ni,nid->nd', w, (Pc - B.P)[B.T[tri]])
        log.append('%s crotch bridge: max %.1f mm' % (ch, np.linalg.norm(Pc - B.P, axis=1).max() * 1000))
    # where the UV match is not trustworthy (point outside our UV islands, normal flipped, jumped far), fill the
    # author->our displacement smoothly from the trusted neighbours over the author body surface
    good = (err < 5e-4) & (np.einsum('nd,nd->n', NA, A.N) > 0.3) & (np.linalg.norm(QA - A.P, axis=1) < 0.08)
    if (~good).any():
        GA = Graph(A.P, A.T)
        wa = np.where(G_avg_bool(GA, good), 1.0, 0.0) + 1e-6
        Dg = GA.solve(wa, GA.avg(QA - A.P), mu=0.0, nu=1.0)
        Dg = Dg[GA.key]; QA = np.where(good[:, None], QA, A.P + Dg)
        Ng = GA.avg(NA)[GA.key]; NA = np.where(good[:, None], NA, A.N)
        log.append('%s untrusted UV matches filled: %d of %d' % (ch, int((~good).sum()), len(good)))
    res = []
    TT = CFG.get('tighten') or {}
    reg = lambda S, P: (S.part == 0) & (P[:, 1] > 1.10) & (P[:, 1] < 1.32)
    gain = float(B.P[reg(B, B.P), 2].max() - A.P[reg(A, A.P), 2].max())
    log.append('%s chest protrudes %.1f mm more than the author body' % (ch, gain * 1000))
    for mi, m in enumerate(X['meshes']):
        if is_skin(m): continue
        V0, N0, T0, I = cloth_data(m); G = GR[mi]
        t, bw, sp, dist = A.closest(V0)
        sn = A.nrm(t, bw)
        off = np.einsum('nd,nd->n', V0 - sp, sn)
        q = np.einsum('ni,nid->nd', bw, QA[A.T[t]]); qn = np.einsum('ni,nid->nd', bw, NA[A.T[t]]); qn /= np.linalg.norm(qn, axis=1)[:, None]
        Pg = q + off[:, None] * qn
        a = np.clip((0.016 - dist) / 0.006, 0, 1)
        # cloth lying over the underside of OUR breast (skin faces down) bridges straight down instead of following the fold
        legs = A.part[A.T[t, 0]] == 1
        chest = (~legs) & (q[:, 1] > 1.08) & (q[:, 1] < 1.33) & (q[:, 2] > 0.02)
        rel = chest * np.clip((-qn[:, 1] - 0.30) / 0.25, 0, 1)
        if any(k in m['mat'] for k in CFG.get('drape', [])):
            # the cape hangs from the bust: below it, it must not be pulled back in to the waist when our bust is bigger
            k = np.clip(gain / 0.02, 0, 1) * (V0[:, 2] > 0.0) * np.clip((1.20 - V0[:, 1]) / 0.04, 0, 1)
            rel = np.maximum(rel, k)
        if any(k in m['mat'] for k in CFG.get('loose', [])):
            # loose garments hang from a bigger bust instead of being glued back onto the ribs/belly below it:
            # the front below the bust is released and filled smoothly (bridges down from the bust)
            k = (np.clip(gain / 0.02, 0, 1) * np.clip((V0[:, 2] - 0.0) / 0.03, 0, 1) * np.clip((0.16 - np.abs(V0[:, 0])) / 0.05, 0, 1)
                 * np.clip((1.21 - V0[:, 1]) / 0.05, 0, 1) * np.clip((V0[:, 1] - TT.get('below', 0.0)) / 0.05, 0, 1))
            rel = np.maximum(rel, k)
        if TT and any(k_ in m['mat'] for k_ in CFG.get('loose', [])):
            # tighten: the lower part of a loose top sits closer to the body than the author made it
            # (its height above the skin shrinks: h' = min + (h - min) * scale), glued all around
            r_ = np.clip((TT['below'] - V0[:, 1]) / 0.06, 0, 1)
            r_ = r_ * (TT.get('side', 1.0) + (1 - TT.get('side', 1.0)) * np.clip((V0[:, 2] + 0.02) / 0.06, 0, 1))   # front fully, sides/back less
            offt = np.where(off > TT['min'], TT['min'] + (off - TT['min']) * TT['scale'], off)
            offu = off + r_ * (offt - off)
            Pg = q + offu[:, None] * qn
            a = np.maximum(a, r_)
        a = a * (1 - rel)
        Db = np.einsum('ni,nid->nd', bw, (QA - A.P)[A.T[t]])          # skin displacement under the vertex
        # cloth floating 1.6-7 cm off the author's skin (padded cups, cape) follows the skin under it (keeps its float)
        af = 0.3 * np.clip((0.070 - dist) / 0.054, 0, 1) * (1 - a) * (1 - rel)
        wb = 0.002
        wa = G.avg(a + af) + wb
        tgt = (G.avg(a[:, None] * (Pg - V0)) + G.avg(af[:, None] * Db) + wb * G.avg(Db)) / wa[:, None]
        log.append('%s %s anchored %d/%d released-under-breast %d' % (ch, m['mat'][-8:-5], int((a > 0.5).sum()), m['nv'], int((rel > 0.5).sum())))
        res.append(dict(mi=mi, G=G, V0=V0, I=I, wa=wa, tgt=tgt, off=off, sn=sn, mat=m['mat'], loose=any(k in m['mat'] for k in CFG.get('loose', []))))
    return res

def layer_pairs(items, lim=0.03, latlim=0.004):
    """author layer order between pieces. For every vertex v of piece i and the point q right above/below it on piece j
    (same skin spot): da = author height(v) - author height(q). da>0: v must stay over j; da<0: j's triangle must stay over v."""
    offs = np.cumsum([0] + [len(it['V0']) for it in items]); R = []
    for i, a in enumerate(items):
        for j, b in enumerate(items):
            if i == j: continue
            # alternative copies of one garment (toggled skirts): no layer order between them
            if any(k in a['mat'] and k in b['mat'] for k in CFG.get('alternatives', [])): continue
            C = Surf.__new__(Surf); C.P = b['V0']; C.T = b['I']; C.C = cKDTree(b['V0'][b['I']].mean(1))
            t, w, q, d = C.closest(a['V0'], k=8)
            dv = a['V0'] - q; h = np.einsum('nd,nd->n', dv, a['sn']); lat = np.linalg.norm(dv - h[:, None] * a['sn'], axis=1)
            offq = np.einsum('ni,ni->n', w, b['off'][b['I'][t]])
            da = a['off'] - offq
            ok = (d < lim) & (lat < latlim) & (np.abs(da) > 0.0008)
            # tight layers (<4 mm apart) keep their order everywhere; the cape keeps floating over everything
            dr = lambda mat: any(k in mat for k in CFG.get('drape', []))
            cape_out = dr(a['mat']) & (da > 0) | dr(b['mat']) & (da < 0)
            ok &= (np.abs(da) < 0.004) | cape_out
            v = np.where(ok)[0]
            R.append((v + offs[i], b['I'][t[ok]] + offs[j], w[ok], da[ok], np.full(len(v), j)))
    if not R: return np.zeros(0, int), np.zeros((0, 3), int), np.zeros((0, 3)), np.zeros(0)   # single cloth piece
    v, tv, w, da, jj = [np.concatenate(x) for x in zip(*R)]
    # a part (connected piece of cloth) that is both over and under the same mesh pierces it in the author's model
    # (stitches, threads, a lip cutting through the layer below): no consistent order there, skip all its pairs
    cid = np.concatenate([it['G'].comp[it['G'].key] + 100000 * k for k, it in enumerate(items)])
    key = cid[v] * 16 + jj
    up = set(key[da > 0].tolist()); dn = set(key[da < 0].tolist()); bad = up & dn
    keep = np.array([k not in bad for k in key.tolist()], bool)
    return v[keep], tv[keep], w[keep], da[keep]

def needs(Ps, Is, B, gap=GAP, reach=0.02, pairs=None):
    """how far each cloth vertex must rise along the skin normal: (a) the vertex itself is too close / inside,
    (b) skin pokes through the middle of a cloth triangle (nipples, coarse cups)"""
    P = np.concatenate(Ps)
    t, w, q, d = B.closest(P); n = B.nrm(t, w)
    sd = np.einsum('nd,nd->n', P - q, n)
    if hasattr(B, 'Ns'):
        n = B.at(t, w, B.Ns); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
    need = np.where(((d < reach) & (sd < gap)) | ((d < 0.06) & (sd < 0)), gap - sd, 0.0)
    o = 0; Ts = []
    for Pi, I in zip(Ps, Is): Ts.append(I + o); o += len(Pi)
    C = Surf.__new__(Surf); C.P = P; C.T = np.concatenate(Ts); C.C = cKDTree(P[C.T].mean(1))
    near = cKDTree(P).query(B.P, distance_upper_bound=0.02)[0] < 0.02
    used = np.zeros(len(B.P), bool); used[np.unique(B.T)] = True        # (arm vertices are not part of the collider)
    sp = np.where(near & used)[0]
    if len(sp):
        tt, ww, qq, dd = C.closest(B.P[sp], k=8)
        dv = qq - B.P[sp]; h = np.einsum('nd,nd->n', dv, B.N[sp]); lat = np.linalg.norm(dv - h[:, None] * B.N[sp], axis=1)
        bad = (dd < 0.02) & (lat < 0.003) & (h < gap)
        for k in range(3):
            v = C.T[tt[bad], k]; np.maximum.at(need, v, gap - h[bad])
    needL = np.zeros(len(P))
    if pairs is not None:
        v, tv, w, da = pairs
        h = sd; hq = np.einsum('ni,ni->n', w, h[tv]); dob = h[v] - hq
        up = da > 0
        tgt = np.clip(0.8 * np.abs(da), 0.0006, 0.003)     # keep (most of) the author's own spacing, never inflate it
        np.maximum.at(needL, v[up], np.maximum(tgt[up] - dob[up], 0))           # outer vertex over inner triangle
        miss = np.maximum(tgt[~up] + dob[~up], 0)                              # inner vertex under outer triangle
        for k in range(3): np.maximum.at(needL, tv[~up, k], miss)
    return need, n, needL

class Drape:
    """loose garments hang from the bust: in front, below the bust, cloth may come back in toward the body by at most
    K per unit of drop (z >= max over skin above it of z' - K*(y'-y)) plus its own author looseness"""
    def __init__(s, B, K=0.45, bw=0.006):
        S = B.P[(B.P[:, 2] > 0.0) & (np.abs(B.P[:, 0]) < 0.2)]
        s.K = K; s.bw = bw; s.cols = {}
        g = S[:, 2] - K * S[:, 1]; b = np.floor(S[:, 0] / bw).astype(int)
        for c in np.unique(b):
            m = np.abs(b - c) <= 1; y = S[m, 1]; o = np.argsort(-y)
            s.cols[c] = (-y[o], np.maximum.accumulate(g[m][o]))
    def env(s, P):
        out = np.full(len(P), -np.inf); b = np.floor(P[:, 0] / s.bw).astype(int)
        for c in np.unique(b):
            if c not in s.cols: continue
            ny, cm = s.cols[c]; k = b == c
            j = np.searchsorted(ny, -(P[k, 1] + 0.02), side='left') - 1     # skin at least 2 cm higher (not the slope beside it)
            ok = j >= 0; e = np.full(k.sum(), -np.inf); e[ok] = cm[j[ok]] + s.K * P[k, 1][ok]; out[k] = e
        return out

def collide(items, B, log, ch, r=0.006, iters=16):
    cw = [np.zeros(it['G'].n) for it in items]; ct = [np.zeros((it['G'].n, 3)) for it in items]
    pairs = layer_pairs(items)
    log.append('%s layer pairs %d' % (ch, len(pairs[0])))
    drape = None
    if CFG.get('drape_envelope') and any(it['loose'] for it in items):
        drape = Drape(B)
        V0c = np.concatenate([it['V0'] for it in items]); offc = np.concatenate([it['off'] for it in items])
        lo = np.concatenate([np.full(len(it['V0']), it['loose']) for it in items])
        dmask = lo & (V0c[:, 2] > 0.03) & (np.abs(V0c[:, 0]) < 0.10) & (V0c[:, 1] < 1.20) & (V0c[:, 1] > 0.75)
        gapd = np.clip(offc, 0.002, 0.03)
    for k in range(iters):
        Ps = []
        for j, it in enumerate(items):
            G = it['G']; wa = it['wa'] + cw[j]
            tg = (it['wa'][:, None] * it['tgt'] + cw[j][:, None] * ct[j]) / wa[:, None]
            Ps.append(it['V0'] + G.solve(wa, tg)[G.key])
        if k == 0:
            # pairs the fit already crosses by a lot are structural (e.g. corset lip under a bigger bust): don't fight them
            P0 = np.concatenate(Ps); t0, w0, q0, d0 = B.closest(P0); h0 = np.einsum('nd,nd->n', P0 - q0, B.nrm(t0, w0))
            v_, tv_, w_, da_ = pairs; dob0 = h0[v_] - np.einsum('ni,ni->n', w_, h0[tv_])
            viol0 = np.where(da_ > 0, -dob0, dob0)
            keep = viol0 < 0.006
            pairs = (v_[keep], tv_[keep], w_[keep], da_[keep])
            log.append('%s layer pairs kept %d dropped (structural crossing) %d' % (ch, int(keep.sum()), int((~keep).sum())))
        need, n, needL = needs(Ps, [it['I'] for it in items], B, pairs=pairs)
        P = np.concatenate(Ps)
        if drape is not None:
            # front of loose pieces below the bust: hang from it (push straight forward)
            e = drape.env(P) + gapd
            nd = np.where(dmask, e - P[:, 2], 0); nd[~np.isfinite(nd)] = 0; nd = np.maximum(nd, 0)
            usez = nd > need
            need = np.maximum(need, nd); n = np.where(usez[:, None], np.array([0, 0, 1.0]), n)
        if max(need.max(), needL.max()) < 5e-5: break
        tree = cKDTree(P); nb = tree.query_ball_point(P, r)
        L = np.array([need[jj].max() for jj in nb])
        if CFG.get('smooth_nipples'):
            # tight fabric over a nipple lifts as a wide smooth tent (2 cm), not a small bump
            R_ = 0.02; hot = np.where(need > 0)[0]
            if len(hot):
                for jj_, i_ in zip(cKDTree(P[hot]).query_ball_point(P, R_), range(len(P))):
                    if jj_:
                        dd_ = np.linalg.norm(P[hot[jj_]] - P[i_], axis=1)
                        L[i_] = max(L[i_], float((need[hot[jj_]] * np.clip(1 - (dd_ / R_) ** 2, 0, 1)).max()))
        # layer-order needs move only the outer piece (spreading them to the layer below would never separate the two)
        mid = np.repeat(np.arange(len(items)), [len(it['V0']) for it in items])
        LL = np.array([needL[jj][mid[jj] == mid[k]].max() for k, jj in enumerate(nb)])
        L = np.maximum(L, LL); need0 = need; need = np.maximum(need, needL)
        o = 0
        for j, it in enumerate(items):
            G = it['G']; nv = len(it['V0']); Lj = L[o:o + nv]; nj = n[o:o + nv]; o += nv
            Lw = np.zeros(G.n); np.maximum.at(Lw, G.key, Lj)
            if not (Lw > 0).any(): continue
            Dcur = G.avg(Ps[j] - it['V0']); nw = G.avg(nj); nw /= np.maximum(np.linalg.norm(nw, axis=1), 1e-9)[:, None]
            m = Lw > 0
            ct[j][m] = Dcur[m] + (Lw[m] * 1.15)[:, None] * nw[m]; cw[j][m] = 20.0
        log.append('%s collide iter %d max need %.1f mm, verts %d (skin %.1f / layers %.1f mm)' % (ch, k, need.max() * 1000, int((need > 0).sum()), need0.max() * 1000, needL.max() * 1000))
    items[0]['_pairs'] = pairs
    return Ps

def lift(Ps, B, gap=GAP, reach=0.02, r=0.006, iters=4):
    """smooth lift along the skin normal; every layer over a spot rises together"""
    P = np.concatenate(Ps); sizes = [len(x) for x in Ps]
    total = np.zeros(len(P))
    for it in range(iters):
        t, w, q, d = B.closest(P); n = B.nrm(t, w)
        sd = np.einsum('nd,nd->n', P - q, n)
        need = np.where(((d < reach) & (sd < gap)) | ((d < 0.06) & (sd < 0)), gap - sd, 0.0)
        if need.max() < 2e-5: break
        tree = cKDTree(P); nb = tree.query_ball_point(P, r)
        L = np.array([need[j].max() for j in nb])
        L = np.array([L[j].mean() for j in nb]) if it < iters - 1 else np.maximum(L, need)
        P = P + L[:, None] * n; total += L
    out = []; o = 0
    for s in sizes: out.append(P[o:o + s]); o += s
    return out, total

ARM = ('j_ude_a', 'j_ude_b', 'n_hhiji', 'n_hte', 'j_te', 'n_hkata', 'j_oya')
def no_arms(B):
    """collision surface without the arms (cloth near the armpit must not be pushed along the arm's normals)"""
    aw = B.W[:, [i for i, n in enumerate(B.names) if n.startswith(ARM)]].sum(1)
    # (excluding the arm triangles left an open edge at the shoulder whose normals pushed the cape up: keep them)
    S = Surf(B.P, B.T, B.UV, B.part, B.W, B.names)
    # push direction: skin normal averaged over 2.5 cm, so cloth in a fold (under a hanging breast) is pushed out
    # of the fold instead of deeper into it along the breast's underside
    nb = cKDTree(B.P).query_ball_point(B.P, 0.025)
    Ns = np.array([S.N[j].sum(0) for j in nb]); S.Ns = Ns / np.maximum(np.linalg.norm(Ns, axis=1), 1e-9)[:, None]
    return S

# ---------------------------------------------------------------- body shape variants for the cloth
def variant_field(P, B, Dk, G, near=0.015, far=0.060):
    t, w, q, d = B.closest(P)
    tree = cKDTree(B.P); dd, jj = tree.query(P, k=8)
    wi = 1 / np.maximum(dd, 1e-4) ** 2; wi /= wi.sum(1, keepdims=True)
    Dv = np.einsum('nk,nkd->nd', wi, Dk[jj])
    a = np.clip((far - d) / (far - near), 0, 1)
    wb = 0.004
    wa = G.avg(a) + wb
    tgt = G.avg(a[:, None] * Dv) / wa[:, None]
    D = G.solve(wa, tgt, mu=0.6, nu=0.05)[G.key]
    return D

def smooth_mask(G, mag, lo, hi):
    m = np.clip((G.avg(mag) - lo) / (hi - lo), 0, 1)
    for _ in range(2): m = np.maximum(m, G.W @ m * 0.999)   # never shrink the moving region
    return m[G.key]

# ---------------------------------------------------------------- weights from the body
SKIRT_PREFIX = 'j_sk'
def body_weights(P, B, Wc_names, Wc, near=0.008, far=0.020):
    t, w, q, d = B.closest(P)
    Wb = np.einsum('ni,nij->nj', w, B.W[B.T[t]])
    names = sorted(set(Wc_names) | set(B.names))
    F = np.zeros((len(P), len(names))); F[:, [names.index(n) for n in Wc_names]] = Wc
    Fb = np.zeros((len(P), len(names))); Fb[:, [names.index(n) for n in B.names]] = Wb
    skirt = (Wc[:, [i for i, n in enumerate(Wc_names) if n.startswith(SKIRT_PREFIX)]].sum(1) > 0) if any(n.startswith(SKIRT_PREFIX) for n in Wc_names) else np.zeros(len(P), bool)
    tt = np.clip((far - d) / (far - near), 0, 1); tt[skirt] = 0
    # arms: cloth near the arm (cape) keeps the author's own arm rigging; elsewhere arm bones are not taken from the body
    armc = [i for i, n in enumerate(names) if n.startswith(ARM + ('iv_nitoukin',))]
    af = Fb[:, armc].sum(1); tt[af > 0.3] = 0
    Fb[:, armc] = 0; Fb /= np.maximum(Fb.sum(1, keepdims=True), 1e-9)
    out = (1 - tt[:, None]) * F + tt[:, None] * Fb
    return add_jiggle(out, names, Fb, d, skirt, af), names, tt

# body jiggle bones every outfit takes advantage of: breasts, pecs, belly, butt, thighs (never genital/arm bones)
JIGGLE = ('iv_c_mune', 'iv_kyokin_phys', 'iv_fukubu_phys', 'ya_fukubu_phys', 'iv_shiri', 'ya_shiri_phys', 'iv_daitai_phys', 'ya_daitai_phys')
JIG_FULL, JIG_ZERO, JIG_SKIRT = 0.020, 0.050, 0.6
def add_jiggle(F, names, Fb, d, skirt, af):
    """loose cloth beyond the glued zone still jiggles with the body under it: up to JIG_FULL from the skin it takes the
    body's full jiggle share at that skin spot, fading to 0 at JIG_ZERO (skirt-bone cloth gets JIG_SKIRT of it, so the
    skirt bones still swing it). The jiggle weight replaces the parent bones' share, so the cloth's rest motion is kept."""
    jc = [i for i, n in enumerate(names) if n.startswith(JIGGLE)]
    if not jc: return F
    Jb = Fb[:, jc]; share = Jb.sum(1)
    reach = np.clip((JIG_ZERO - d) / (JIG_ZERO - JIG_FULL), 0, 1) * np.where(skirt, JIG_SKIRT, 1.0) * (af < 0.3)
    target = share * reach
    have = F[:, jc].sum(1)
    up = target > have + 1e-4
    if not up.any(): return F
    F = F.copy(); rest = 1 - have
    k = np.where(up, (1 - target) / np.maximum(rest, 1e-9), 1.0)
    nonj = np.ones(F.shape[1], bool); nonj[jc] = False
    F[:, nonj] *= k[:, None]
    dist = Jb / np.maximum(share, 1e-9)[:, None]
    F[np.ix_(up, jc)] = (target[up, None] * dist[up])
    return F


def quant(Wf, names):
    used = np.nonzero(Wf.sum(0) > 1e-6)[0]; tbl = [names[j] for j in used]; Wf = Wf[:, used]
    if Wf.shape[1] < 8: Wf = np.c_[Wf, np.zeros((len(Wf), 8 - Wf.shape[1]))]
    order = np.argsort(-Wf, 1)[:, :8]; top = np.take_along_axis(Wf, order, 1); top /= np.maximum(top.sum(1, keepdims=True), 1e-12)
    q8 = np.floor(top * 255).astype(int); rem = 255 - q8.sum(1)
    frac = top * 255 - q8
    for r in np.nonzero(rem)[0]: q8[r, np.argsort(-frac[r])[:rem[r]]] += 1
    order = np.where(q8 > 0, order, 0)
    return q8.astype(np.uint8), order.astype(np.uint8), tbl


# ---------------------------------------------------------------- skin-tight garments (underwear): relax + pose-aware lift
def relax_tight(Ps, items, log, ch):
    """restore the author's local shape where the fit crumpled it (crotch between touching thighs): keep the author's
    Laplacian (detail, lace edges) and stay near the fit where it is smooth"""
    out = []
    for P, it in zip(Ps, items):
        G = it['G']; V0 = it['V0']
        D = G.avg(P - V0); r = np.linalg.norm(G.L @ D, axis=1)
        wa = np.clip(1.0 - (r - 0.0004) / 0.0012, 0.03, 1.0)
        Dn = G.solve(wa, D, mu=1.0, nu=0.0)
        out.append(V0 + Dn[G.key])
        log.append('%s relax: rough verts %d, max move %.1f mm' % (ch, int((r > 0.0008).sum()), np.linalg.norm(Dn - D, axis=1).max() * 1000))
    return out

def pose_lift(Ps, items, Bw, Bc, Xm, log, ch, cap=0.003, iters=3):
    """approximate animation (thigh swing/abduction/sitting/jiggle, linear blend skinning with the body's weights):
    where cloth goes under the posed skin, lift it at rest (smooth, capped) so it stays out in motion"""
    import pose as PZ
    bary_ = PZ.bary_
    SW = Bw.W; SN = Bw.names
    cl = PZ.pivot(Bw.P, SW, SN, PZ.LEFT); cr = PZ.pivot(Bw.P, SW, SN, PZ.RIGHT)
    specs = dict(PZ.poses(cl, cr)); specs.pop('sit')
    specs['sit60'] = {'rot': [(PZ.LEFT, PZ.rotm((1, 0, 0), -60), cl), (PZ.RIGHT, PZ.rotm((1, 0, 0), -60), cr)]}
    posed = {k: Surf(PZ.pose_pts(Bw.P, SW, SN, None, sp), Bw.T, None, Bw.part) for k, sp in specs.items()}
    total = [np.zeros(len(P)) for P in Ps]
    for it_ in range(iters):
        worst = 0.0
        for k_, (P, it) in enumerate(zip(Ps, items)):
            m = Xm[it['mi']]; Wc = dense_w(m)
            W, names, _ = body_weights(P, Bw, m['table'], Wc)
            T = it['I']; need = np.zeros(len(P))
            for k, sp in specs.items():
                C = PZ.pose_pts(P, W, names, None, sp)
                S = np.einsum('kb,tbd->tkd', bary_, C[T]); Sf = S.reshape(-1, 3)
                t, w, q, d = posed[k].closest(Sf); n = posed[k].nrm(t, w); h = np.einsum('nd,nd->n', Sf - q, n)
                pen = np.where((d < 0.03), np.maximum(0.0006 - h, 0), 0).reshape(len(T), -1)
                # a sample's need goes to the triangle's vertices by barycentric share
                for j in range(3):
                    np.maximum.at(need, T[:, j], (pen * (bary_[None, :, j] > 0.3)).max(1))
            need = np.minimum(need, np.maximum(cap - total[k_], 0))
            worst = max(worst, need.max())
            if need.max() < 5e-5: continue
            nb = cKDTree(P).query_ball_point(P, 0.006)
            L = np.array([need[j].max() for j in nb]); L = np.array([L[j].mean() for j in nb])
            t, w, q, d = Bc.closest(P); nn = Bc.nrm(t, w)
            Ps[k_] = P + L[:, None] * nn; total[k_] += L
        log.append('%s pose lift iter %d: max need %.1f mm' % (ch, it_, worst * 1000))
        if worst < 5e-5: break
    return Ps, np.concatenate(total)

# ---------------------------------------------------------------- main
def run_group(top, dwn, AS, X, CHS, REF_, log, report):
    """fit + variants + emission for one group of chest options that share one author topology"""
    global GR
    cloth_idx = [i for i, m in enumerate(X['meshes']) if not is_skin(m)]
    GR = {}
    for i in cloth_idx:
        V0, N0, T0, I = cloth_data(X['meshes'][i]); GR[i] = Graph(V0, I)
    Bs = {}; Ds = {}; FIT = {}; BC = {}
    for ch in CHS:
        B, D = our_rest_and_shapes(top, dwn, ch); Bs[ch] = B; Ds[ch] = D
        sz = PICK[ch]; Xs, A = AS[sz]
        items = fit_chest(B, A, Xs, ch, log)
        Bc = no_arms(B); BC[ch] = Bc
        Ps = collide(items, Bc, log, ch)
        Ps, lifted = lift(Ps, Bc, iters=2)
        log.append('%s from %s: lift max %.1f mm, moved %d' % (ch, sz, lifted.max() * 1000, int((lifted > 1e-4).sum())))
        if CFG.get('tight'):
            Ps = relax_tight(Ps, items, log, ch)
            Ps, _ = lift(Ps, Bc, iters=4)
            Ps, pl = pose_lift(Ps, items, B, Bc, Xs['meshes'], log, ch)
            Ps, _ = lift(Ps, Bc, iters=2)
            log.append('%s pose lift max %.1f mm' % (ch, pl.max() * 1000))
        FIT[ch] = dict(zip(cloth_idx, Ps))
    # ---- chest dependency (relative to REF_), locked seams
    CHM = {}
    for i in cloth_idx:
        G = GR[i]; Pr = FIT[REF_][i]
        mag = np.max([np.linalg.norm(FIT[ch][i] - Pr, axis=1) for ch in CHS], 0)
        mk = smooth_mask(G, mag, 0.00025, 0.0006)
        for ch in CHS: FIT[ch][i] = Pr + mk[:, None] * (FIT[ch][i] - Pr)
        CHM[i] = mk > 0
        log.append('mesh %d chest-dependent verts %d/%d' % (i, int(CHM[i].sum()), len(mk)))
    # ---- belly / hips variant displacements (per chest), then lift against the variant body
    VAR = {}  # (i, ch, group, opt) -> displacement
    DEP = {i: {'belly': np.zeros(len(FIT[REF_][i]), bool), 'hips': np.zeros(len(FIT[REF_][i]), bool)} for i in cloth_idx}
    for ch in CHS:
        for g, opts in (('belly', ('none', 'soft')), ('hips', ('small', 'large'))):
            for o in opts:
                for i in cloth_idx:
                    VAR[(i, ch, g, o)] = variant_field(FIT[ch][i], Bs[ch], Ds[ch][g + '_' + o], GR[i])
    for i in cloth_idx:
        G = GR[i]
        for g, opts in (('belly', ('none', 'soft')), ('hips', ('small', 'large'))):
            mag = np.max([np.linalg.norm(VAR[(i, ch, g, o)], axis=1) for ch in CHS for o in opts], 0)
            mk = smooth_mask(G, mag, 0.0003, 0.0008)
            for ch in CHS:
                for o in opts: VAR[(i, ch, g, o)] *= mk[:, None]
            # vertices shared by every chest option must move the same way in every chest option (no seams)
            for ch in CHS:
                for o in opts: VAR[(i, ch, g, o)] = np.where(CHM[i][:, None], VAR[(i, ch, g, o)], VAR[(i, REF_, g, o)])
            DEP[i][g] = mk > 0
            log.append('mesh %d %s-dependent verts %d' % (i, g, int(DEP[i][g].sum())))
    # variant collision: lift the displaced cloth against the displaced body (only where it moved)
    shapeD = lambda ch, sel: sum(Ds[ch][g + '_' + o] for g, o in sel.items() if (g, o) not in (('belly', 'full'), ('hips', 'medium')))
    def positions(ch, belly, hips):
        out = {}
        for i in cloth_idx:
            P = FIT[ch][i].copy()
            if belly != 'full': P += VAR[(i, ch, 'belly', belly)]
            if hips != 'medium': P += VAR[(i, ch, 'hips', hips)]
            out[i] = P
        return out
    POS = {}
    for ch in [REF_] + [c for c in CHS if c != REF_]:
        for be in ('full', 'soft', 'none'):
            for hi in ('medium', 'small', 'large'):
                Pd = positions(ch, be, hi)
                if (be, hi) != ('full', 'medium'):
                    B = BC[ch]; Bv = Surf(B.P + shapeD(ch, {'belly': be, 'hips': hi}), B.T, B.UV, B.part)
                    mv = {i: DEP[i]['belly'] * (be != 'full') | DEP[i]['hips'] * (hi != 'medium') for i in cloth_idx}
                    Ps, lifted = lift([Pd[i] for i in cloth_idx], Bv)
                    for k, i in enumerate(cloth_idx):
                        # only moving cloth may change, so the seams to the shared piece stay closed
                        Pd[i] = np.where(mv[i][:, None], Ps[k], Pd[i])
                    report.setdefault('variant_lift', {})['%s/%s/%s' % (ch, be, hi)] = round(float(lifted.max() * 1000), 2)
                if ch != REF_:
                    for i in cloth_idx: Pd[i] = np.where(CHM[i][:, None], Pd[i], POS[(REF_, be, hi)][i])
                POS[(ch, be, hi)] = Pd
    # ---- weights (shared vertices share weights)
    WT = {}
    for i in cloth_idx:
        m = X['meshes'][i]; Wc = dense_w(m)
        Wref, names, tt = body_weights(POS[(REF_, 'full', 'medium')][i], Bs[REF_], m['table'], Wc)
        WT[(i, REF_, 'full', 'medium')] = (Wref, names)
        report.setdefault('reweighted', {})[i] = int((tt > 0).sum())
    def weights_for(i, ch, be, hi):
        key = (i, ch, be, hi)
        if key in WT: return WT[key]
        m = X['meshes'][i]; Wc = dense_w(m)
        B = Bs[ch]; Bv = Surf(B.P + shapeD(ch, {'belly': be, 'hips': hi}), B.T, B.UV, B.part, B.W, B.names)
        Wv, names, _ = body_weights(POS[(ch, be, hi)][i], Bv, m['table'], Wc)
        Wr, nr = WT[(i, REF_, 'full', 'medium')]
        allm = sorted(set(names) | set(nr)); F = np.zeros((len(Wv), len(allm))); F[:, [allm.index(n) for n in names]] = Wv
        Fr = np.zeros_like(F); Fr[:, [allm.index(n) for n in nr]] = Wr
        dep = np.zeros(len(F), bool)
        if ch != REF_: dep |= CHM[i]
        if be != 'full': dep |= DEP[i]['belly']
        if hi != 'medium': dep |= DEP[i]['hips']
        F = np.where(dep[:, None], F, Fr); WT[key] = (F, allm); return WT[key]
    # ---- emission
    pieces = []
    for i in cloth_idx:
        m = X['meshes'][i]; V0, N0, T0, I = cloth_data(m); G = GR[i]
        src = {k: cloth_data(AS[k][0]['meshes'][i]) for k in AS}
        ref_frames = None
        tc = CHM[i][I].any(1); tb = DEP[i]['belly'][I].any(1); th = DEP[i]['hips'][I].any(1)
        attr_sets = []; tri_attr = np.zeros(len(I), int)
        for s_ in m['subs']:
            if not s_['cnt']: continue
            a_ = tuple(s_['attr'])
            if a_ not in attr_sets: attr_sets.append(a_)
            tri_attr[s_['off'] // 3:(s_['off'] + s_['cnt']) // 3] = attr_sets.index(a_)
        for cdep in (0, 1):
            for bdep in (0, 1):
                for hdep in (0, 1):
                    sel = (tc == cdep) & (tb == bdep) & (th == hdep)
                    if not sel.any(): continue
                    combos = []
                    for ch in (CHS if cdep else [REF_]):
                        for be in (('full', 'soft', 'none') if bdep else ['full']):
                            for hi in (('medium', 'small', 'large') if hdep else ['medium']):
                                P = POS[(ch, be, hi)][i]
                                sV0, sN0, sT0, _ = src[PICK[ch]]
                                Nn, Tn = frames(G, sV0, P, sN0, sT0)
                                # vertices shared with the common piece keep the common piece's normals (no shading seam)
                                dep = np.zeros(len(P), bool)
                                if ch != REF_: dep |= CHM[i]
                                if be != 'full': dep |= DEP[i]['belly']
                                if hi != 'medium': dep |= DEP[i]['hips']
                                if ref_frames is None:
                                    rV0, rN0, rT0, _ = src[PICK[REF_]]; ref_frames = frames(G, rV0, POS[(REF_, 'full', 'medium')][i], rN0, rT0)
                                Nn = np.where(dep[:, None], Nn, ref_frames[0]); Tn = np.where(dep[:, None], Tn, ref_frames[1])
                                Wf, names = weights_for(i, ch, be, hi)
                                tags = (['atrx_cb_chest_' + ch] if cdep else []) + (['atrx_cb_belly_' + be] if bdep else []) + (['atrx_cb_hips_' + hi] if hdep else [])
                                combos.append((P, Nn, Tn, Wf, names, tags))
                    # keep the author's sub-meshes apart (each has its own toggle attributes)
                    for sa in sorted(set(tri_attr[sel].tolist())):
                        pieces += shared_pieces(m, I[sel & (tri_attr == sa)], combos, base_attr=list(attr_sets[sa]))
    return pieces

def topo_key(X):
    return tuple((m['mat'], m['nv'], hash(m['idx'])) for m in X['meshes'] if not is_skin(m))

CG = {'s': ['flat', 'small', 'champs', 'smallperky', 'medium', 'earth'], 'l': ['large', 'saggy', 'perky', 'mireya']}   # Crimson chest groups (atrx_cb_cg_*)
def run(build, out_path, report):
    global PICK
    top, dwn = read(CB + BUILDS[build][0]), read_dwn(build)
    AS = {s: author_surface(s) for s in CFG['sizes']}
    log = []; pieces = []
    keys = {k: topo_key(AS[k][0]) for k in AS}
    if len(set(keys.values())) == 1:
        X = AS[list(CFG['sizes'])[0]][0]
        # Legs/Feet slots have no chest switches in the Crimson meta: one fit, against the chest given (default medium)
        chs = [CFG['only_chest']] if CFG.get('only_chest') else CH
        pieces = run_group(top, dwn, AS, X, chs, chs[0] if CFG.get('only_chest') else REF, log, report)
    else:
        # author sizes with different meshes: one fit per Crimson chest group (cg_s / cg_l), each from the sizes of that group
        for g, chs in CG.items():
            sizes = CFG['groups'][g]
            if len({keys[k] for k in sizes}) > 1 and DIST:
                # these sizes don't share a mesh: the group is fitted from the one size closest over all its chests
                sizes = [min(sizes, key=lambda k: sum(DIST[c][k] for c in chs))]
            PICK.update({c: min(sizes, key=lambda k: DIST[c][k]) if DIST else sizes[0] for c in chs})
            assert len({keys[PICK[c]] for c in chs}) == 1, 'sizes of one chest group must share the mesh'
            X = AS[PICK[chs[0]]][0]
            ref = 'medium' if 'medium' in chs else chs[0]
            pg = run_group(top, dwn, AS, X, chs, ref, log, report)
            for p in pg:
                for s_ in p['subs']: s_['attr'] = s_['attr'] + ['atrx_cb_cg_' + g]
            pieces += pg
            log.append('chest group %s: %s fitted from %s' % (g, chs, {c: PICK[c] for c in chs}))
    if CFG.get('skin'):   # gloves/shoes: the body pieces come from the user's own hands/feet model
        body_meshes = [mm for f in CFG['skin'] for mm in read(f)['meshes'] if 'piercing' not in mm['mat'] and mm['nv'] > 0]
        rep_ = CFG.get('skin_attr_replace', {})
        for mm in body_meshes:
            for s_ in mm['subs']: s_['attr'] = [rep_.get(a, a) for a in s_['attr']]
    else:
        body_meshes = [mm for mm in (dwn if CFG.get('slot', 'top') == 'dwn' else top)['meshes'] if 'piercing' not in mm['mat'] and 'pierce' not in mm['mat']]   # the body pieces (piercings dropped: under clothes) of the slot this garment replaces
    # body coverage: an outfit that hides other slots (full-length dress: EQP hides the Legs model) ships that skin
    # inside its own model. Carry the same pieces of OUR body, or the legs/hands/feet vanish in game.
    def _cover(meshes):
        out = set()
        for m_ in meshes:
            if not is_skin(m_) or m_['nv'] == 0 or 'b0001_bibo' not in m_['mat']: continue
            P_ = attr(m_, 0)[0][:, :3][np.unique(tris(m_))]; y_ = P_[:, 1]; ax_ = np.abs(P_[:, 0])
            if ((y_ > 1.0) & (y_ < 1.45) & (ax_ < 0.2)).sum() > 200: out.add('torso')
            if ((y_ > 0.2) & (y_ < 0.85)).sum() > 200: out.add('legs')
            if ((ax_ > 0.5) & (y_ > 0.8) & (y_ < 1.1)).sum() > 200: out.add('hands')
            if (y_ < 0.12).sum() > 200: out.add('feet')
        return out
    a_cov = _cover(read(CFG['sizes'][list(CFG['sizes'])[0]])['meshes'])
    if 'legs' in a_cov and not ('legs' in _cover(body_meshes)):
        body_meshes = body_meshes + [mm for mm in dwn['meshes'] if mm['mat'] == '/mt_c0201b0001_bibo.mtrl' and mm['nv'] > 0]
        log.append('author model carries the legs skin (dress hides the Legs model): our legs skin added to the model')
    miss = a_cov - _cover(body_meshes)
    if miss: log.append('WARNING body pieces the author ships but the port lacks: %s' % sorted(miss)); print('WARNING missing body pieces', miss)
    report['body_cover'] = sorted(_cover(body_meshes))
    cloth_meshes = merge(pieces)
    meshes = body_meshes + cloth_meshes
    Y = _copy.copy(X); Y['meshes'] = meshes
    bb = bonebbox_map(X); bb.update(bonebbox_map(top)); bb.update(bonebbox_map(dwn))
    for f in CFG.get('skin', []): bb.update(bonebbox_map(read(f)))
    Y['bonebbox_by_name'] = bb
    Y['attrs'] = list(X['attrs']); Y['mats'] = []; Y['bones'] = []
    vb = sum(len(s) for mm in meshes for s in mm['streams'])
    report.update(vb_mb=round(vb / 2 ** 20, 2), meshes=len(meshes), max_nv=max(mm['nv'] for mm in meshes),
                  max_table=max(len(mm['table']) for mm in meshes), shape_vals=sum(len(v) for mm in meshes for v in mm['shapes'].values()),
                  pieces=len(pieces))
    if vb >= 15.5 * 2 ** 20:
        bym = {}
        for mm in meshes: bym[mm['mat']] = bym.get(mm['mat'], 0) + sum(len(s) for s in mm['streams'])
        print('VERTEX BUFFER TOO BIG', {k: round(v / 2 ** 20, 2) for k, v in sorted(bym.items(), key=lambda x: -x[1])})
        print('\n'.join(log))
    report['too_big'] = bool(vb >= 15.5 * 2 ** 20)
    assert vb < 15.5 * 2 ** 20 or os.environ.get('PORT4_ALLOW_BIG') == '1', vb
    assert report['max_table'] <= 64, report['max_table']
    assert report['shape_vals'] < 65536
    write(Y, out_path)
    report['log'] = log
    return report

def pick_sizes(build):
    """author size closest to each chest option: mean distance author chest skin -> our chest (same Bibo UV spot)"""
    keys = list(CFG['sizes'])
    if len(keys) == 1: return {c: keys[0] for c in CH}
    top, dwn = read(CB + BUILDS[build][0]), read_dwn(build); res = {}
    for sz in keys:
        X, A = author_surface(sz)
        for ch in CH:
            B = our_surface_from(top, dwn, ch); tri, w, err = uv_map(A, B); Q = B.at(tri, w)
            sel = (A.part == 0) & (A.P[:, 1] > 1.12) & (A.P[:, 1] < 1.34) & (A.P[:, 2] > 0.0)
            res.setdefault(ch, {})[sz] = float(np.linalg.norm(Q - A.P, axis=1)[sel].mean())
    print('chest distance mm', {c: {k: round(v * 1000, 1) for k, v in d.items()} for c, d in res.items()})
    DIST = res
    return {c: min(d, key=d.get) for c, d in res.items()}

def shared_pieces(m, Tsel, combos, qmm=float(os.environ.get('QMM', '0.05')), base_attr=None):
    """one vertex buffer for all option copies of these triangles: a vertex that sits at the same place in several
    options is stored once and referenced by each option's sub-mesh (saves most of the vertex buffer)"""
    u, inv = np.unique(Tsel, return_inverse=True); T = inv.reshape(-1, 3)
    out = []; cur = None
    for P, Nn, Tn, Wf, names, tags in combos:
        Pu = P[u]
        key = np.c_[np.arange(len(u)), np.rint(Pu / (qmm * 1e-3)).astype(np.int64)]
        if cur is not None:
            idmap = np.array([cur['keys'].get(tuple(k), -1) for k in key.tolist()])
            if cur['n'] + int((idmap < 0).sum()) > 65000: cur = None
        if cur is None:
            cur = {'keys': {}, 'n': 0, 'rows': [], 'subs': [], 'names': set()}; out.append(cur)
            idmap = np.full(len(u), -1)
        new = np.where(idmap < 0)[0]
        idmap[new] = cur['n'] + np.arange(len(new))
        for k, j in zip(key[new].tolist(), idmap[new].tolist()): cur['keys'][tuple(k)] = j
        cur['n'] += len(new)
        cur['rows'].append((u[new], Pu[new], Nn[u][new], Tn[u][new], Wf[u][new], names))
        cur['names'] |= set(names)
        cur['subs'].append((idmap[T], tags))
    pieces = []
    for c in out:
        names = sorted(c['names'])
        src_idx = np.concatenate([r[0] for r in c['rows']]); P = np.concatenate([r[1] for r in c['rows']])
        Nn = np.concatenate([r[2] for r in c['rows']]); Tn = np.concatenate([r[3] for r in c['rows']])
        Wf = np.zeros((len(P), len(names))); o = 0
        for r in c['rows']:
            Wf[o:o + len(r[1]), [names.index(n) for n in r[5]]] = r[4]; o += len(r[1])
        mm = make_piece(m, np.arange(len(P)).reshape(-1, 1).repeat(3, 1)[:0], P, Nn, Tn, Wf, names, [], src_idx=src_idx)
        idx = []; subs = []; off = 0
        for Ti, tags in c['subs']:
            idx.append(Ti.astype(np.uint16).tobytes()); subs.append({'off': off, 'cnt': Ti.size, 'attr': (list(m['subs'][0]['attr']) if base_attr is None else base_attr) + tags, 'sbm': list(range(len(mm['table'])))}); off += Ti.size
        mm['idx'] = b''.join(idx); mm['ic'] = off; mm['subs'] = subs
        pieces.append(mm)
    return pieces

def make_piece(m, Tsel, P, Nn, Tn, Wf, names, tags, src_idx=None):
    if src_idx is not None:
        # rows given directly: P/Nn/Tn/Wf are already per output vertex, src_idx = source vertex for the other attributes
        u = src_idx; T = np.zeros((0, 3), int)
        P = _expand(P, u, m['nv']); Nn = _expand(Nn, u, m['nv']); Tn = _expand(Tn, u, m['nv']); Wf = _expand(Wf, u, m['nv'])
        u = np.arange(len(src_idx)); _src = src_idx
    else:
        u, inv = np.unique(Tsel, return_inverse=True); T = inv.reshape(-1, 3); _src = u
    s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(m['nv'], -1)[_src].copy()
    s1 = np.frombuffer(m['streams'][1], np.uint8).reshape(m['nv'], -1)[_src].copy()
    s0[:, :12] = P[u].astype(np.float32).view(np.uint8).reshape(-1, 12)
    q8, order, tbl = quant(Wf[u], names)
    s0[:, 12:20] = q8; s0[:, 20:28] = order
    Nq = Nn[u] / np.maximum(np.linalg.norm(Nn[u], axis=1), 1e-12)[:, None]
    assert np.isfinite(Nq).all()
    s1[:, :12] = Nq.astype(np.float32).view(np.uint8).reshape(-1, 12)
    Tq = Tn[u] - np.einsum('nd,nd->n', Tn[u], Nq)[:, None] * Nq
    Tq /= np.maximum(np.linalg.norm(Tq, axis=1), 1e-12)[:, None]
    s1[:, 12:15] = np.clip(np.rint((Tq + 1) / 2 * 255), 0, 255).astype(np.uint8)
    mm = dict(m); mm['nv'] = len(u); mm['ic'] = T.size; mm['idx'] = T.astype(np.uint16).tobytes()
    mm['streams'] = [s0.tobytes(), s1.tobytes()] + list(m['streams'][2:]); mm['shapes'] = {}
    mm['table'] = tbl
    base_attr = m['subs'][0]['attr']
    mm['subs'] = [{'off': 0, 'cnt': T.size, 'attr': list(base_attr) + tags, 'sbm': list(range(len(tbl)))}]
    return mm

def _expand(X, u, nv):
    return X   # rows are already in output order (indexed by np.arange below)

def merge(pieces):
    """pack pieces of the same material into meshes <=65000 vertices (shared bone table)"""
    groups = {}
    for p in pieces: groups.setdefault(p['mat'], []).append(p)
    out = []
    for mat, ps in groups.items():
        cur = None
        for p in ps:
            names = sorted(set(p['table']) | (set(cur['table']) if cur else set()))
            if cur is not None and cur['nv'] + p['nv'] <= 65000 and len(names) <= 64:
                remap_into(cur, names); q = dict(p); remap_into(q, names)
                off = cur['nv']; ic = cur['ic']
                cur['streams'] = [a + b for a, b in zip(cur['streams'], q['streams'])]
                cur['idx'] = cur['idx'] + (np.frombuffer(q['idx'], np.uint16).astype(np.int64) + off).astype(np.uint16).tobytes()
                cur['subs'] = cur['subs'] + [dict(s, off=s['off'] + ic, sbm=list(range(len(names)))) for s in q['subs']]
                for s in cur['subs']: s['sbm'] = list(range(len(names)))
                cur['nv'] += q['nv']; cur['ic'] += q['ic']
            else:
                cur = dict(p); cur['streams'] = list(p['streams']); out.append(cur)
    return out

def remap_into(mm, names):
    if mm['table'] == names: return
    old = mm['table']; lut = np.array([names.index(n) for n in old], np.uint8)
    s0 = np.frombuffer(mm['streams'][0], np.uint8).reshape(mm['nv'], -1).copy()
    w = s0[:, 12:20]; s0[:, 20:28] = np.where(w > 0, lut[s0[:, 20:28]], 0)
    mm['streams'] = [s0.tobytes()] + list(mm['streams'][1:]); mm['table'] = list(names)

if __name__ == '__main__':
    build = sys.argv[1]; out = sys.argv[2]   # usage: port4.py BUILD OUT.mdl outfit.json
    load_cfg(sys.argv[3]); import surf as _s; CFG = _s.CFG
    PICK = pick_sizes(build); print('PICK', PICK)
    rep = run(build, out, {})
    print(json.dumps({k: v for k, v in rep.items() if k != 'log'}, indent=0))
    print('\n'.join(rep['log']))
