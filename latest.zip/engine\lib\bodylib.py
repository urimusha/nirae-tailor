"""Author bodies for tall -> NIRÆ ports.

scan(root): every body model the installed mods ship - each option (or default data) of any mod that maps the
smallclothes body top or legs (chara/equipment/e0000|e0279/model/c0201e0000_top|dwn.mdl, or the c0201 b0001 body
model) is one candidate (mod, group, option, file). The files come from the mods' own option tables, so names of
folders do not matter (Bibo+ keeps its Nude - Medium chest in files/common/39).

detect(outfit, candidates): which candidate the outfit was made on. Outfits ship the visible part of their author's
body unchanged, so its skin (materials mt_c0201b0001_*) lies exactly on the right candidate: the share of skin points
within 0.3 mm decides, then the mean distance of the points the candidate covers (within 3 cm)."""
import os, json
import numpy as np

TOP = {'chara/equipment/e0000/model/c0201e0000_top.mdl', 'chara/equipment/e0279/model/c0201e0279_top.mdl',
       'chara/human/c0201/obj/body/b0001/model/c0201b0001_top.mdl'}
DWN = {'chara/equipment/e0000/model/c0201e0000_dwn.mdl', 'chara/equipment/e0279/model/c0201e0279_dwn.mdl'}
GLV = {'chara/equipment/e0000/model/c0201e0000_glv.mdl', 'chara/equipment/e0279/model/c0201e0279_glv.mdl'}
SHO = {'chara/equipment/e0000/model/c0201e0000_sho.mdl', 'chara/equipment/e0279/model/c0201e0279_sho.mdl'}


def _json(p):
    try:
        with open(p, encoding='utf-8-sig') as f:
            return json.load(f)
    except Exception:
        return None


def containers(moddir):
    """(meta, [(group or None, option index, container)]) for a Penumbra mod (meta.json groups or group_*.json files)"""
    meta = _json(os.path.join(moddir, 'meta.json')) or {}
    out = []
    dd = meta.get('DefaultData') or _json(os.path.join(moddir, 'default_mod.json'))
    if isinstance(dd, dict):
        out.append((None, None, dd))
    groups = [g for g in (meta.get('Groups') or []) if isinstance(g, dict)]
    try:
        names = sorted(os.listdir(moddir))
    except OSError:
        names = []
    for f in names:
        if f.lower().startswith('group_') and f.lower().endswith('.json'):
            g = _json(os.path.join(moddir, f))
            if isinstance(g, dict):
                groups.append(g)
    for g in groups:
        for oi, o in enumerate(g.get('Options') or []):
            if isinstance(o, dict):
                out.append((g, oi, o))
    return meta, out


def _is_default(g, oi):
    if g is None:
        return True
    d = g.get('DefaultSettings') or 0
    try:
        d = int(d)
    except (TypeError, ValueError):
        d = 0
    return d == oi if g.get('Type') == 'Single' else bool((d >> oi) & 1)


def scan(root, skip=()):
    """[{mod, modname, group, option, kind ('top' | 'dwn'), file, default}] - one entry per file"""
    out = []; seen = set()
    skip = {os.path.normcase(os.path.abspath(s)) for s in skip}
    try:
        dirs = sorted(os.listdir(root))
    except OSError:
        return out
    for name in dirs:
        d = os.path.join(root, name)
        if not os.path.isdir(d) or name.startswith('_') or os.path.normcase(os.path.abspath(d)) in skip:
            continue
        meta, cs = containers(d)
        mname = meta.get('Name') or name
        for g, oi, c in cs:
            for gp, rel in (c.get('Files') or {}).items():
                key = gp.replace('\\', '/').lower()
                kind = 'top' if key in TOP else 'dwn' if key in DWN else 'glv' if key in GLV else 'sho' if key in SHO else None
                if kind is None or not isinstance(rel, str):
                    continue
                f = os.path.join(d, rel.replace('\\', os.sep).replace('/', os.sep))
                k = (kind, os.path.normcase(os.path.abspath(f)))
                if k in seen or not os.path.isfile(f):
                    continue
                seen.add(k)
                out.append(dict(mod=name, modname=mname, group=(g or {}).get('Name'), option=c.get('Name') if g else None,
                                kind=kind, file=f, default=_is_default(g, oi)))
    return out


def label(c):
    parts = [c['modname']] + [x for x in (c.get('group'), c.get('option')) if x]
    return ' / '.join(parts)


def skin_points(path):
    """vertices of the body-skin meshes (materials mt_c0201b0001_* / c0101b0001) used by triangles, or None"""
    from mdlio import read
    import vtx
    M = read(path); P = []
    for m in M['meshes']:
        if not m['nv'] or 'b0001' not in m['mat']:
            continue
        d = vtx.decode(m)
        used = np.unique(np.frombuffer(m['idx'], np.uint16))
        if len(used):
            P.append(d[(0, 0)][1][used, :3])
    return np.concatenate(P) if P else None


def detect(outfit, cands, near=0.0003, cover=0.03):
    """[(score, cand)] best first for each kind present: {'top': [...], 'dwn': [...]}; score = (exact share, mean mm,
    covered share). Kinds whose best candidate covers < 20 % of the outfit skin are left out."""
    from scipy.spatial import cKDTree
    Q = skin_points(outfit)
    res = {'top': [], 'dwn': [], 'glv': [], 'sho': [], 'skin_points': 0 if Q is None else len(Q)}
    if Q is None or not len(Q):
        return res
    cache = {}
    for c in cands:
        f = c['file']
        if f not in cache:
            try:
                P = skin_points(f)
                cache[f] = cKDTree(P) if P is not None and len(P) else None
            except Exception:
                cache[f] = None
        t = cache[f]
        if t is None:
            continue
        d, _ = t.query(Q, distance_upper_bound=cover)
        cov = np.isfinite(d)
        exact = float((d < near).mean())
        mean = float(d[cov].mean() * 1000) if cov.any() else 99.0
        res[c['kind']].append(((round(exact, 4), round(mean, 3), round(float(cov.mean()), 4)), c))
    for k in ('top', 'dwn', 'glv', 'sho'):
        res[k].sort(key=lambda sc: (-sc[0][0], sc[0][1]))
        if res[k] and res[k][0][0][2] < 0.2:
            res[k] = []
    return res


def legs_for(top, cands):
    """the legs to use with a detected top when the outfit shows no legs skin: the same mod's default legs option,
    else one named medium, else its first"""
    same = [c for c in cands if c['kind'] == 'dwn' and c['mod'] == top['mod']]
    for pick in (lambda c: c['default'], lambda c: 'medium' in (c.get('option') or '').lower(), lambda c: True):
        x = [c for c in same if pick(c)]
        if x:
            return x[0]
    return None
