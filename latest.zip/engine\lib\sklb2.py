import re,struct,sys,numpy as np
def parse(p):
    d=open(p,'rb').read()
    def varint(o):
        r=0;s=0
        while True:
            b=d[o];o+=1;r|=(b&0x7f)<<s;s+=7
            if not b&0x80: return r,o
    st=d.find(b'n_root')-1; o=st; names=[]
    while True:
        L,o2=varint(o); n=L>>1; s=d[o2:o2+n]
        if L&1 or n==0 or not re.fullmatch(rb'[A-Za-z0-9_]+',s): break
        names.append(s.decode()); o=o2+n
    N=len(names); c,o=varint(o); assert c>>1==N,(c,N)
    T=[];Q=[];S=[]
    for k in range(N):
        f=struct.unpack_from('<12f',d,o+48*k); T.append(f[0:3]); Q.append(f[4:8]); S.append(f[8:11])
    T=np.array(T);Q=np.array(Q)
    # parents: search zigzag varint array of N ints ending right before names region
    par=None
    for s0 in range(st-4*N, st):
        o=s0; vals=[]
        try:
            for k in range(N):
                v,o=varint(o); vals.append((v>>1)^-(v&1))
        except IndexError: continue
        if vals[0]==0 and vals[1]==0 and all(0<=vals[k]<k for k in range(1,N)):
            par=[-1]+vals[1:]; break
    return names,par,T,Q,np.array(S)
def qrot(q,v):
    x,y,z,w=q; u=np.array([x,y,z]); return v+2*np.cross(u,np.cross(u,v)+w*v)
def qmul(a,b):
    x1,y1,z1,w1=a;x2,y2,z2,w2=b
    return np.array([w1*x2+x1*w2+y1*z2-z1*y2,w1*y2-x1*z2+y1*w2+z1*x2,w1*z2+x1*y2-y1*x2+z1*w2,w1*w2-x1*x2-y1*y2-z1*z2])
def world(names,par,T,Q):
    N=len(names); WP=np.zeros((N,3)); WQ=np.zeros((N,4))
    for k in range(N):
        if par[k]<0: WP[k]=T[k]; WQ[k]=Q[k]
        else: WQ[k]=qmul(WQ[par[k]],Q[k]); WP[k]=WP[par[k]]+qrot(WQ[par[k]],T[k])
    return WP,WQ
if __name__=='__main__':
    n,p,T,Q,S=parse(sys.argv[1]); print(len(n),'parents found',p is not None)
    WP,WQ=world(n,p,T,Q)
    for b in sys.argv[2:]:
        k=n.index(b); print(b,'parent',n[p[k]],'local',np.round(T[k],4),'world',np.round(WP[k],4),'wq',np.round(WQ[k],3))
