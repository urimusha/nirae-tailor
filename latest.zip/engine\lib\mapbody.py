"""NIRÆ body (human c0201, current 0.9.128) -> FluxHD2 SFW female body (Lalafell c1201): a smooth space deformation.
1. retarget: every standard bone gets an affine map  p' = O_dst + F_dst diag(s_len, s_v, s_w) F_src^T (p - O_src)
   (frames from the joint positions: u = toward the child joint, v/w across it; s_len = bone length ratio, s_v / s_w =
   cross-section spread ratio of the skin that bone carries; the breast bones use the spine's map); the NIRÆ skin moves
   by linear blend skinning with its own weights (custom bones collapsed onto their standard ancestors)
2. non-rigid fit: smooth displacement field on the NIRÆ skin (welded graph, Laplacian^2 + membrane), closest points on
   the FluxHD2 surface both ways, stiffness lowered stepwise while no triangle folds (a fold = a face whose normal turns
   > 90 deg against the retargeted surface); the step that would fold is undone
Only NIRÆ's outer skin is used (no vulva / pube / inner meshes and no vulva sub-meshes: the crotch is matched from the
skin around it). Heights of the cloth over the FluxHD2 skin are set later against the real FluxHD2 surface.
usage: mapbody.py CHEST BELLY FLUXCHEST OUT.npz"""
import sys, os, numpy as np
pass
import surf as S
from surf import read, attr, Surf, tris, dense_w, merge_w, vnorm, cKDTree
from port4 import Graph
import lalaskel as skel

FLUXD = os.path.join(os.environ.get('LP_FLUX_DIR', '/mnt/user-data/uploads/FFXIVMods/_crimson_work/fluxhd2_src'), '')
nA, parA, WA = skel.load(skel.SRC)
nB, parB, WB = skel.load(skel.DST)
STD = {b for b in nB if b.startswith(('j_', 'n_'))}


def collapse(b):
    """standard ancestor of a (custom) NIRÆ bone"""
    while b not in STD:
        b = parA.get(b)
        if b is None: return 'j_kosi'
    return b


def collapse_w(W, names):
    out = sorted({collapse(n) for n in names})
    F = np.zeros((len(W), len(out)))
    for j, n in enumerate(names): F[:, out.index(collapse(n))] += W[:, j]
    return F, out


def _surface(items):
    """items: [(P, T, N, (W, table), part)] -> Surf with stored normals Ns"""
    Ps, Ts, Ns, parts, Ws = [], [], [], [], []; o = 0
    for P, T, N, Wt, part in items:
        u, inv = np.unique(T, return_inverse=True)
        Ps.append(P[u]); Ts.append(inv.reshape(-1, 3) + o); Ns.append(N[u]); parts.append(np.full(len(u), part))
        Ws.append((Wt[0][u], Wt[1])); o += len(u)
    W, names = merge_w(Ws)
    s = Surf(np.concatenate(Ps), np.concatenate(Ts), None, np.concatenate(parts), W, names)
    Nn = np.concatenate(Ns); s.Nst = Nn / np.maximum(np.linalg.norm(Nn, axis=1), 1e-12)[:, None]
    # faces whose winding disagrees with the stored normals (none expected) are counted, not trusted
    fn = np.cross(s.P[s.T[:, 1]] - s.P[s.T[:, 0]], s.P[s.T[:, 2]] - s.P[s.T[:, 0]])
    s.fsign = np.sign(np.einsum('nd,nd->n', fn, s.Nst[s.T].sum(1))); s.fsign[s.fsign == 0] = 1
    s.Nw = s.N; s.N = s.Nst          # every inside/outside test uses the stored normals (a few FluxHD2 faces wind the other way)
    return s


NIRAE = dict(build='curvy', hips='medium')       # the NIRÆ build · hips an outfit is fitted to (the engine sets it)


def nirae_body(chest, belly, build=None, hips=None):
    build = build or NIRAE['build']; hips = hips or NIRAE['hips']
    top = read(S.CB + S.BUILDS[build][0]); dwn = S.read_dwn(build)
    hD = dwn['_hipsD'].get(hips) if hips != 'medium' else None     # small / large: the medium legs moved to that file
    shp = [] if belly == 'full' else ['shpx_cb_belly_' + belly]
    items = []
    for mi, m in enumerate(top['meshes']):
        if not S.is_skin(m) or 'b0001_bibo' not in m['mat'] or not m['nv']: continue
        at = [a for s in m['subs'] for a in s['attr'] if a.startswith('atrx_cb_chest_')]
        if at and 'atrx_cb_chest_' + chest not in at: continue
        subs = [s for s in m['subs'] if 'atrx_cb_nip_inv' not in s['attr']]
        items.append((attr(m, 0)[0][:, :3].astype(float), tris(m, subs, shp), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), 0))
    for mi, m in enumerate(dwn['meshes']):
        if m['mat'] != '/mt_c0201b0001_bibo.mtrl' or not m['nv']: continue
        P = attr(m, 0)[0][:, :3]
        if np.abs(P[:, 0]).max() < 0.02: continue                      # the vulva mesh
        if hD is not None and mi in hD: P = P + hD[mi]
        subs = [s for s in m['subs'] if not any(a.startswith('atrx_cb_vulva_') for a in s['attr'])]
        items.append((P.astype(float), tris(m, subs, shp), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), 1))
    return _surface(items)


# which FluxHD2 body the outfit is fitted to and carries: 'full' = the full skin (the outfit covers chest and hips,
# as on NIRÆ - the user's choice for Sleepy Panda, 2026-11-06), 'sfw' = the SFW body whose skin has holes under its
# smallclothes (those then count as the body surface)
BODY = os.environ.get('FLUX_BODY', 'full')
FLUX_FILES = {'sfw': ('base_top_%s_sfw.mdl', 'base_dwn_sfw.mdl'), 'full': ('base_top_%s_nsfw.mdl', 'base_dwn_nsfw_closed.mdl'),
              # fit target with the full body: its chest, but the SFW legs + panties - the full body's crotch detail
              # (slit, folds) drew NIRÆ's perineum into folds and stopped the fit at stiffness 60 (mean 0.87 mm)
              'fit_full': ('base_top_%s_nsfw.mdl', 'base_dwn_sfw.mdl')}
FLUX_SKIN = ('fluxhd_female',) if BODY == 'full' else ('fluxhd_female', 'mt_c1201e0000_top_a', 'mt_c1201e0000_dwn_a')
FIT_SKIN = ('fluxhd_female', 'mt_c1201e0000_dwn_a') if BODY == 'full' else FLUX_SKIN


def flux_files(chest='vanilla', fit=False):
    t, d = FLUX_FILES['fit_full' if (fit and BODY == 'full') else BODY]
    return FLUXD + (t % chest), FLUXD + d


def flux_body(chest='vanilla'):
    """the fit's target, FluxHD2 female body as one closed surface: the full skin (legs: SFW + panties, see
    FLUX_FILES), or the SFW skin (cut away under the smallclothes: chest hole under the bra, waist to leg openings under
    the panties) with the smallclothes pieces as part of it"""
    tf, df = flux_files(chest, fit=True); top = read(tf); dwn = read(df)
    items = []
    for k, M in enumerate((top, dwn)):
        for m in M['meshes']:
            if not m['nv'] or not any(x in m['mat'] for x in FIT_SKIN): continue
            items.append((attr(m, 0)[0][:, :3].astype(float), tris(m), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), k))
    return _surface(items)


def pos(Wm, b): return Wm[b][:3, 3]

CHILD = {'j_sebo_a': 'j_sebo_b', 'j_sebo_b': 'j_sebo_c', 'j_sebo_c': 'j_kubi', 'j_kubi': 'j_kao'}
for s in 'lr':
    CHILD.update({'j_sako_' + s: 'j_ude_a_' + s, 'j_ude_a_' + s: 'j_ude_b_' + s, 'n_hkata_' + s: 'j_ude_b_' + s,
                  'j_ude_b_' + s: 'j_te_' + s, 'n_hhiji_' + s: 'j_te_' + s, 'j_te_' + s: 'j_naka_a_' + s,
                  'j_asi_a_' + s: 'j_asi_b_' + s, 'j_asi_b_' + s: 'j_asi_c_' + s, 'j_asi_c_' + s: 'j_asi_d_' + s,
                  'j_asi_d_' + s: 'j_asi_e_' + s})
    for c in 'bfs':
        CHILD.update({'j_sk_%s_a_%s' % (c, s): 'j_sk_%s_b_%s' % (c, s), 'j_sk_%s_b_%s' % (c, s): 'j_sk_%s_c_%s' % (c, s)})
    for f in ('hito', 'naka', 'kusu', 'ko', 'oya'):             # fingers: proximal -> distal phalanx
        CHILD['j_%s_a_%s' % (f, s)] = 'j_%s_b_%s' % (f, s)
SAME = {'j_mune_l': 'j_sebo_b', 'j_mune_r': 'j_sebo_b'}       # bones that use another bone's map
for s in 'lr': SAME['j_asi_b_' + s] = 'j_asi_a_' + s           # the short knee bone: the thigh's cross-section


def axis(Wm, b):
    O = pos(Wm, b)
    if b in CHILD and CHILD[b] in Wm:
        u = pos(Wm, CHILD[b]) - O; L = np.linalg.norm(u)
    elif b.startswith('n_hte'):
        s = b[-1]; u = pos(Wm, 'j_te_' + s) - pos(Wm, 'j_ude_b_' + s); L = np.linalg.norm(u)
    elif b == 'j_kosi':
        u = np.array([0, -1.0, 0]); L = O[1] - 0.5 * (pos(Wm, 'j_asi_a_l')[1] + pos(Wm, 'j_asi_a_r')[1])
    elif b.startswith('j_asi_e'):
        s = b[-1]; u = O - pos(Wm, 'j_asi_d_' + s); L = np.linalg.norm(u)
    elif b.startswith(('j_hito_b', 'j_naka_b', 'j_kusu_b', 'j_ko_b', 'j_oya_b')):
        a = b.replace('_b_', '_a_'); u = O - pos(Wm, a); L = 0.8 * np.linalg.norm(u)
    elif b.startswith('j_sk_') and b[7] == 'c':
        u = O - pos(Wm, b.replace('_c_', '_b_')); L = np.linalg.norm(u)
    elif b == 'j_kao':
        u = np.array([0, 1.0, 0]); L = pos(Wm, 'j_kao')[1] - pos(Wm, 'j_kubi')[1]
    else:
        return None
    u = u / max(np.linalg.norm(u), 1e-9)
    ref = np.array([0, 0, 1.0]) if abs(u[0]) > 0.5 else np.array([1.0, 0, 0])
    v = ref - (ref @ u) * u; v /= np.linalg.norm(v); w = np.cross(u, v)
    return O, np.stack([u, v, w], 1), L


def bone_maps(XA, WAs, namesA, XB, WBs, namesB, log, pelvis=True):
    info = {}
    for b in sorted(set(namesA) | set(CHILD) | {'j_kosi'}):
        a = axis(WA, b); d = axis(WB, b)
        if a is None or d is None: continue
        Oa, Fa, La = a; Ob, Fb, Lb = d
        sv = sw = None
        if b in namesA and b in namesB:
            ka = WAs[:, namesA.index(b)] > 0.5; kb = WBs[:, namesB.index(b)] > 0.5
            if ka.sum() > 30 and kb.sum() > 10:
                ca = (XA[ka] - Oa) @ Fa; cb = (XB[kb] - Ob) @ Fb
                sv = cb[:, 1].std() / max(ca[:, 1].std(), 1e-6); sw = cb[:, 2].std() / max(ca[:, 2].std(), 1e-6)
        info[b] = [Lb / max(La, 1e-6), sv, sw]
    for b in info:
        p = b
        while info[b][1] is None:
            p = parA.get(p)
            if p is None: info[b][1:] = [0.8, 0.8]; break
            if p in info and info[p][1] is not None: info[b][1:] = info[p][1:]
    for b, src in SAME.items():
        if b in info and src in info: info[b] = list(info[src])
    maps = {}
    for b, (s_len, sv, sw) in info.items():
        Oa, Fa, La = axis(WA, b); Ob, Fb, Lb = axis(WB, b)
        src = SAME.get(b)
        if src in info and b.startswith('j_mune'):
            Oa, Fa, La = axis(WA, src); Ob, Fb, Lb = axis(WB, src)
        A = np.eye(4); L3 = Fb @ np.diag([s_len, sv, sw]) @ Fa.T; A[:3, :3] = L3; A[:3, 3] = Ob - L3 @ Oa
        maps[b] = A
        log.append('%-12s len x%.2f  across x%.2f / x%.2f' % (b, s_len, sv, sw))
    if pelvis: maps['j_kosi'] = pelvis_map(XA, XB, log)
    for b in LIMB_CHAIN:
        if b in maps:
            g = limb_map(b, XA, WAs, namesA, XB, WBs, namesB, log)
            if g is not None: maps[b] = g
    for b, src in SAME.items():
        if b.startswith('j_asi_b') and src in maps:
            maps[b] = maps[src]
    return maps


LIMB_CHAIN = {}
for s_ in 'lr':
    arm = ['j_ude_a_' + s_, 'n_hkata_' + s_, 'j_ude_b_' + s_, 'n_hhiji_' + s_, 'n_hte_' + s_, 'j_te_' + s_]
    leg = ['j_asi_a_' + s_, 'j_asi_b_' + s_, 'j_asi_c_' + s_, 'j_asi_d_' + s_]
    for b in ('j_ude_a_' + s_, 'n_hkata_' + s_): LIMB_CHAIN[b] = (arm, 'j_ude_a_' + s_)
    for b in ('j_ude_b_' + s_, 'n_hhiji_' + s_, 'n_hte_' + s_): LIMB_CHAIN[b] = (arm, 'j_ude_b_' + s_)
    LIMB_CHAIN['j_asi_a_' + s_] = (leg, 'j_asi_a_' + s_)
    LIMB_CHAIN['j_asi_c_' + s_] = (leg, 'j_asi_c_' + s_)


def _slabs(X, W, names, chain, seg, Wm):
    """cross-sections of the limb segment seg (25-75 % of its length): centroid (v, w) and spread (std v, std w) of
    the skin carried by the limb chain, averaged over 5 slabs"""
    O, F, L = axis(Wm, seg)
    idx = [names.index(b) for b in chain if b in names]
    if not idx: return None
    k = W[:, idx].sum(1) > 0.6
    c = (X[k] - O) @ F
    out = []
    for a in np.linspace(0.3, 0.7, 5):
        m = np.abs(c[:, 0] - a * L) < 0.06 * L
        if m.sum() < 8: continue
        cv, cw = c[m, 1].mean(), c[m, 2].mean()
        out.append((cv, cw, c[m, 1].std(), c[m, 2].std()))
    return np.mean(out, 0) if out else None


def limb_map(b, XA, WAs, namesA, XB, WBs, namesB, log):
    chain, seg = LIMB_CHAIN[b]
    sa = _slabs(XA, WAs, namesA, chain, seg, WA); sb = _slabs(XB, WBs, namesB, chain, seg, WB)
    if sa is None or sb is None: return None
    Oa, Fa, La = axis(WA, b); Ob, Fb, Lb = axis(WB, b)
    _, Fsa, Lsa = axis(WA, seg); _, Fsb, Lsb = axis(WB, seg)
    s_len = Lsb / max(Lsa, 1e-6); sv = sb[2] / max(sa[2], 1e-6); sw = sb[3] / max(sa[3], 1e-6)
    # in the segment's frame: u scaled by the length ratio about the joint, the cross-section centre line moved onto
    # the destination's, the cross-section scaled by the spread ratios
    L3 = Fsb @ np.diag([s_len, sv, sw]) @ Fsa.T
    ca = Oa + Fsa @ np.array([0, sa[0], sa[1]]); cb = Ob + Fsb @ np.array([0, sb[0], sb[1]])
    A = np.eye(4); A[:3, :3] = L3; A[:3, 3] = cb - L3 @ ca
    log.append('%-12s (slices) len x%.2f  across x%.2f / x%.2f' % (b, s_len, sv, sw))
    return A


def pelvis_map(XA, XB, log):
    """the pelvis from the shape itself (its weight painting differs too much between the bodies): the band between
    the hip joints and the waist joint, width = 98th percentile |x|, depth = 2nd..98th percentile z, centre kept;
    height scaled about the waist joint by the waist-to-crotch distance ratio"""
    def band(X, Wm):
        yk = pos(Wm, 'j_kosi')[1]; yh = 0.5 * (pos(Wm, 'j_asi_a_l')[1] + pos(Wm, 'j_asi_a_r')[1])
        # crotch = lowest skin point on the midline below the hip joints (the pelvis' own depth)
        mid = (np.abs(X[:, 0]) < 0.006) & (X[:, 1] < yh) & (X[:, 1] > yh - 0.25)
        yc = X[mid, 1].min()
        k = (X[:, 1] > yh - 0.25 * (yk - yh)) & (X[:, 1] < yk) & (np.abs(X[:, 0]) < 0.3)
        xw = np.percentile(np.abs(X[k, 0]), 98); z0, z1 = np.percentile(X[k, 2], [2, 98])
        return yk, yk - yc, xw, 0.5 * (z0 + z1), z1 - z0
    ya, ha, xa, za, da = band(XA, WA); yb, hb, xb, zb, db = band(XB, WB)
    A = np.eye(4); A[0, 0] = xb / xa; A[1, 1] = hb / ha; A[2, 2] = db / da
    A[:3, 3] = np.array([0, yb, zb]) - A[:3, :3] @ np.array([0, ya, za])
    log.append('j_kosi (shape) height x%.2f  width x%.2f  depth x%.2f' % (hb / ha, xb / xa, db / da))
    return A


def lbs(X, Wc, names, maps, cyl=None, limbs=None):
    """linear blend of the bone maps; torso bones (cyl given) use the torso profile map and limb bones (limbs given)
    their segment's profile map instead of their affine map"""
    out = np.zeros_like(X); tot = np.zeros(len(X)); Xh = np.c_[X, np.ones(len(X))]
    wt = np.zeros(len(X))
    for j, b in enumerate(names):
        w = Wc[:, j]; k = w > 0
        if not k.any(): continue
        if cyl is not None and b in TORSO_CYL:
            wt += w; continue
        if limbs is not None and b in limbs:
            out[k] += w[k, None] * limbs[b].map(X[k]); tot[k] += w[k]; continue
        A = maps.get(b); p = b
        while A is None and p is not None:
            p = parA.get(p); A = maps.get(p)
        if A is None: A = maps['j_kosi']
        out[k] += w[k, None] * (Xh[k] @ A.T)[:, :3]; tot[k] += w[k]
    if cyl is not None:
        k = wt > 0
        out[k] += wt[k, None] * cyl.map(X[k]); tot[k] += wt[k]
    return out / np.maximum(tot, 1e-9)[:, None]


TORSO = ('j_kosi', 'j_sebo_a', 'j_sebo_b', 'j_sebo_c', 'j_kubi', 'j_kao', 'j_mune_l', 'j_mune_r')
TORSO_CYL = TORSO[1:]
EASE = 0.85                    # largest scale of the gap between loose cloth and the torso outline          # the pelvis (two legs below it) keeps its affine map
LIMB = ('j_ude', 'n_hkata', 'n_hhiji', 'n_hte', 'j_te', 'j_sako')


def _knots(Wm):
    hip = 0.5 * (pos(Wm, 'j_asi_a_l') + pos(Wm, 'j_asi_a_r'))
    P = [hip] + [pos(Wm, b) for b in ('j_kosi', 'j_sebo_b', 'j_sebo_c', 'j_kubi', 'j_kao')]
    return np.array([p[1] for p in P]), np.array([p[2] for p in P])


def _lev(y, ys):
    """piecewise-linear spine level of height y (knot k -> level k), extrapolated with the end intervals"""
    s = np.interp(y, ys, np.arange(len(ys)), left=np.nan, right=np.nan)
    lo = y < ys[0]; hi = y > ys[-1]
    s[lo] = (y[lo] - ys[0]) / (ys[1] - ys[0]); s[hi] = len(ys) - 1 + (y[hi] - ys[-1]) / (ys[-1] - ys[-2])
    return s


def _unlev(s, ys):
    k = np.clip(np.floor(s).astype(int), 0, len(ys) - 2); f = s - k
    return ys[k] + f * (ys[k + 1] - ys[k])


class CylMap:
    """torso profile map: a point at spine level s, angle th around the spine and distance r from it goes to the same
    level and angle on the destination with r scaled by the ratio of the two torsos' outlines there (the 90th
    percentile radius per level x angle bin, smoothed). Torso skin = weight on torso bones > 0.6, no arm/leg weight."""
    NS, NT = 60, 36

    def __init__(s, XA, WAs, namesA, XB, WBs, namesB, log):
        s.ya, s.za = _knots(WA); s.yb, s.zb = _knots(WB)
        s.lo, s.hi = -0.6, len(s.ya) - 0.6
        Ra = s._prof(XA, WAs, namesA, s.ya, s.za); Rb = s._prof(XB, WBs, namesB, s.yb, s.zb)
        s.ratio = s._smooth(np.where(np.isfinite(Ra) & np.isfinite(Rb), Rb / np.maximum(Ra, 1e-6), np.nan))
        s.Ra = s._smooth(Ra)
        r = s.ratio
        log.append('torso profile ratio: median %.2f, front %.2f, back %.2f, sides %.2f (per level: %s)' % (
            np.median(r), np.median(r[:, :3]), np.median(r[:, 16:20]), np.median(r[:, 8:10]),
            ' '.join('%.2f' % np.median(r[i]) for i in range(0, s.NS, 6))))

    def _coords(s, X, ys, zs):
        lev = _lev(X[:, 1], ys)
        zsp = np.interp(lev, np.arange(len(zs)), zs)
        dx, dz = X[:, 0], X[:, 2] - zsp
        return lev, np.arctan2(dx, dz), np.hypot(dx, dz)

    def _bins(s, lev, th):
        i = np.clip(((lev - s.lo) / (s.hi - s.lo) * s.NS).astype(int), 0, s.NS - 1)
        j = np.clip(((th + np.pi) / (2 * np.pi) * s.NT).astype(int), 0, s.NT - 1)
        return i, j

    def _prof(s, X, W, names, ys, zs):
        idx = [names.index(b) for b in TORSO if b in names]; lim = [k for k, n in enumerate(names) if n.startswith(LIMB) or n.startswith('j_asi')]
        k = (W[:, idx].sum(1) > 0.6) & (W[:, lim].sum(1) < 0.05) if lim else (W[:, idx].sum(1) > 0.6)
        lev, th, r = s._coords(X[k], ys, zs); i, j = s._bins(lev, th)
        R = np.full((s.NS, s.NT), np.nan)
        for a in range(s.NS):
            for b in range(s.NT):
                m = (i == a) & (j == b)
                if m.sum() >= 3: R[a, b] = np.percentile(r[m], 90)
        return R

    def _smooth(s, R):
        R = R.copy()
        for _ in range(200):                                   # fill holes from the neighbours (angle wraps)
            nan = ~np.isfinite(R)
            if not nan.any(): break
            acc = np.zeros_like(R); cnt = np.zeros_like(R)
            for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                Q = np.roll(R, db, 1)
                Q = np.roll(Q, da, 0) if da else Q
                if da == 1: Q[0] = np.nan
                if da == -1: Q[-1] = np.nan
                ok = np.isfinite(Q); acc[ok] += Q[ok]; cnt[ok] += 1
            fill = nan & (cnt > 0); R[fill] = acc[fill] / cnt[fill]
        for _ in range(3):                                     # light smoothing
            R = (2 * R + np.roll(R, 1, 1) + np.roll(R, -1, 1)) / 4
            R = np.vstack([R[:1], (2 * R[1:-1] + R[:-2] + R[2:]) / 4, R[-1:]])
        return R

    def map(s, X):
        lev, th, r = s._coords(X, s.ya, s.za)
        # bilinear lookup of the ratio
        fi = np.clip((lev - s.lo) / (s.hi - s.lo) * s.NS - 0.5, 0, s.NS - 1.001); i0 = np.floor(fi).astype(int); a = fi - i0
        fj = (th + np.pi) / (2 * np.pi) * s.NT - 0.5; j0 = np.floor(fj).astype(int); b = fj - j0; j0 %= s.NT; j1 = (j0 + 1) % s.NT
        def look(R):
            return ((1 - a) * (1 - b) * R[i0, j0] + (1 - a) * b * R[i0, j1] + a * (1 - b) * R[np.minimum(i0 + 1, s.NS - 1), j0]
                    + a * b * R[np.minimum(i0 + 1, s.NS - 1), j1])
        q = look(s.ratio); ra = look(s.Ra)
        y = _unlev(lev, s.yb); zsp = np.interp(lev, np.arange(len(s.zb)), s.zb)
        # inside the torso outline the radius scales with the outline ratio; what floats beyond it (loose cloth) keeps
        # its gap scaled by that ratio but never more than EASE (a deeper Lalafell back must not puff the cloth up)
        rr = np.where(r <= ra, r * q, ra * q + (r - ra) * np.minimum(q, EASE))
        return np.c_[rr * np.sin(th), y, zsp + rr * np.cos(th)]


LIMB_SEG = {}                   # bone -> (segment bone, chain): limbs use a profile map along their segment
for s_ in 'lr':
    legc = ['j_asi_a_' + s_, 'j_asi_b_' + s_, 'j_asi_c_' + s_, 'j_asi_d_' + s_]
    armc = ['j_ude_a_' + s_, 'n_hkata_' + s_, 'j_ude_b_' + s_, 'n_hhiji_' + s_, 'n_hte_' + s_, 'j_te_' + s_]
    LIMB_SEG.update({'j_asi_a_' + s_: ('j_asi_a_' + s_, legc), 'j_asi_b_' + s_: ('j_asi_b_' + s_, legc),
                     'j_asi_c_' + s_: ('j_asi_c_' + s_, legc), 'j_asi_d_' + s_: ('j_asi_c_' + s_, legc)})
    if os.environ.get('LIMB_ARMS', '0') == '1':
        # (off: the arm maps pushed the hoodie's underarm gusset - cloth in the gap between arm and torso - deeper into
        # the narrower Lalafell gap than the affine maps; the collision's lift there then folded and was undone)
        LIMB_SEG.update({'j_ude_a_' + s_: ('j_ude_a_' + s_, armc), 'n_hkata_' + s_: ('j_ude_a_' + s_, armc),
                         'j_ude_b_' + s_: ('j_ude_b_' + s_, armc), 'n_hhiji_' + s_: ('j_ude_b_' + s_, armc),
                         'n_hte_' + s_: ('j_ude_b_' + s_, armc)})
LIMB_GAP = float(os.environ.get('LIMB_GAP', '1.0'))   # largest scale of the gap between loose cloth and a limb
LIMB_GAP_MODE = os.environ.get('LIMB_GAP_MODE', 'level')   # gap scale per level (size ratio) or per angle (q)


class LimbMap:
    """profile map of one limb segment (thigh, knee, shin, upper arm, forearm): a point at normalised position t along
    the segment, angle th around it (frame from the segment and the forward axis, built the same way on both
    skeletons) and distance r from its axis goes to the same t and th on the destination segment with r scaled by the
    ratio q of the two skins' radii there (median radius per t x th bin of the skin the limb chain carries, holes
    filled, smoothed). Beyond the skin (loose cloth) the gap is scaled by the limbs' size ratio at that t (mean radius
    over the angles), at most LIMB_GAP: a cuff stays around the ankle with its ease - the affine map (one scale per
    segment, from the middle of the shin) squeezed it into the Lalafell's relatively thicker ankle"""
    T0, T1, NTB, NA = -0.4, 1.4, 36, 24

    def __init__(s, seg, SA, SB, log):
        s.seg = seg
        s.fa = s._frame(WA, seg); s.fb = s._frame(WB, seg)
        Ra = s._prof(SA, s.fa); Rb = s._prof(SB, s.fb)
        ok = np.isfinite(Ra) & np.isfinite(Rb)
        s.Ra = s._smooth(Ra); s.Rb = s._smooth(Rb)
        s.q = s.Rb / np.maximum(s.Ra, 1e-6)
        # size ratio of the two limbs at each t (mean radius over the angles): the scale of the gap of loose cloth
        # (the per-angle ratio also carries where the bone sits inside the limb - the human tibia at the front of the
        # shin, the Lalafell's in the middle - which must move the skin, not inflate or squash the cloth's ease)
        s.Qt = s.Rb.mean(1) / np.maximum(s.Ra.mean(1), 1e-6)
        mid = slice(int(0.25 * s.NTB / 1.8 + 0.4 * s.NTB / 1.8), int(0.75 * s.NTB / 1.8 + 0.4 * s.NTB / 1.8))
        log.append('%-10s (profile) len x%.2f  radius ratio median %.2f (segment middle %.2f, range %.2f..%.2f), size ratio t=.25/.5/.75/.9 %s, bins with data %d/%d' % (
            seg, s.fb[2] / s.fa[2], np.median(s.q), np.median(s.q[mid]), np.percentile(s.q, 5), np.percentile(s.q, 95),
            '/'.join('%.2f' % np.interp(x, s.T0 + (np.arange(s.NTB) + 0.5) * (s.T1 - s.T0) / s.NTB, s.Qt) for x in (0.25, 0.5, 0.75, 0.9)), int(ok.sum()), ok.size))

    @staticmethod
    def _frame(Wm, seg):
        O, F, L = axis(Wm, seg); u = F[:, 0]
        z = np.array([0, 0, 1.0]); v = z - (z @ u) * u; v /= np.linalg.norm(v); w = np.cross(u, v)
        return O, np.stack([u, v, w], 1), L

    def _coords(s, X, fr):
        O, F, L = fr; c = (X - O) @ F
        return c[:, 0] / L, np.arctan2(c[:, 2], c[:, 1]), np.hypot(c[:, 1], c[:, 2])

    def _bins(s, t, th):
        i = np.clip(((t - s.T0) / (s.T1 - s.T0) * s.NTB).astype(int), 0, s.NTB - 1)
        j = np.clip(((th + np.pi) / (2 * np.pi) * s.NA).astype(int), 0, s.NA - 1)
        return i, j

    def _prof(s, X, fr):
        """X: dense samples of the skin the limb chain carries"""
        t, th, r = s._coords(X, fr); i, j = s._bins(t, th)
        inside = (t >= s.T0) & (t <= s.T1)
        R = np.full((s.NTB, s.NA), np.nan)
        key = i[inside] * s.NA + j[inside]; rr = r[inside]
        o = np.argsort(key, kind='stable'); key = key[o]; rr = rr[o]
        u, st, cnt = np.unique(key, return_index=True, return_counts=True)
        for kk, a0, c in zip(u, st, cnt):
            if c >= 4: R[kk // s.NA, kk % s.NA] = np.median(rr[a0:a0 + c])
        return R

    def _smooth(s, R):
        R = R.copy()
        for _ in range(400):                                   # fill holes from the neighbours (angle wraps)
            nan = ~np.isfinite(R)
            if not nan.any(): break
            acc = np.zeros_like(R); cnt = np.zeros_like(R)
            for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                Q = np.roll(R, db, 1)
                Q = np.roll(Q, da, 0) if da else Q
                if da == 1: Q[0] = np.nan
                if da == -1: Q[-1] = np.nan
                ok = np.isfinite(Q); acc[ok] += Q[ok]; cnt[ok] += 1
            fill = nan & (cnt > 0); R[fill] = acc[fill] / cnt[fill]
        for _ in range(2):                                     # light smoothing
            R = (2 * R + np.roll(R, 1, 1) + np.roll(R, -1, 1)) / 4
            R = np.vstack([R[:1], (2 * R[1:-1] + R[:-2] + R[2:]) / 4, R[-1:]])
        return R

    def _look(s, R, t, th):
        fi = np.clip((t - s.T0) / (s.T1 - s.T0) * s.NTB - 0.5, 0, s.NTB - 1.001); i0 = np.floor(fi).astype(int); a = fi - i0
        fj = (th + np.pi) / (2 * np.pi) * s.NA - 0.5; j0 = np.floor(fj).astype(int); b = fj - j0; j0 %= s.NA; j1 = (j0 + 1) % s.NA
        i1 = np.minimum(i0 + 1, s.NTB - 1)
        return (1 - a) * (1 - b) * R[i0, j0] + (1 - a) * b * R[i0, j1] + a * (1 - b) * R[i1, j0] + a * b * R[i1, j1]

    def map(s, X):
        t, th, r = s._coords(X, s.fa)
        ra = s._look(s.Ra, t, th); q = s._look(s.q, t, th)
        if LIMB_GAP_MODE == 'angle':
            g = np.minimum(q, LIMB_GAP)
        else:
            tc = s.T0 + (np.arange(s.NTB) + 0.5) * (s.T1 - s.T0) / s.NTB
            g = np.minimum(np.interp(t, tc, s.Qt), LIMB_GAP)
        rr = np.where(r <= ra, r * q, ra * q + (r - ra) * g)
        O, F, L = s.fb
        return O + np.outer(t * L, F[:, 0]) + (rr * np.cos(th))[:, None] * F[:, 1] + (rr * np.sin(th))[:, None] * F[:, 2]


FOOT_H = 0.30          # foot samples up to this fraction of the foot length above the sole (both feet cut alike)


class FootMap(LimbMap):
    """profile map of the whole foot (heel to toe tip), measured on the SKIN, not on the skeleton: NIRÆ's foot mesh
    sits 2 cm above its own joints (its bare feet carry SimpleHeels -2 cm), so joint-to-joint affine maps put the
    Lalafell toes 1.6 cm too high and the slipper sole above the sole of the foot. Axis: horizontal, heel back (t=0)
    to toe tip (t=1), at the toes' mid-height, laterally through the middle of the foot; cross-sections perpendicular
    to it, radius per t x angle as in LimbMap (skin r * q, loose cloth gap * size ratio at t)"""

    def __init__(s, side, SA, SB, log):
        s.seg = 'foot_' + side
        s.fa, SA = s._ffr(WA, side, SA); s.fb, SB = s._ffr(WB, side, SB)
        Ra = s._prof(SA, s.fa); Rb = s._prof(SB, s.fb)
        ok = np.isfinite(Ra) & np.isfinite(Rb)
        s.Ra = s._smooth(Ra); s.Rb = s._smooth(Rb)
        s.q = s.Rb / np.maximum(s.Ra, 1e-6)
        s.Qt = s.Rb.mean(1) / np.maximum(s.Ra.mean(1), 1e-6)
        tc = s.T0 + (np.arange(s.NTB) + 0.5) * (s.T1 - s.T0) / s.NTB; inn = (tc > 0.05) & (tc < 0.95)
        log.append('%-10s (foot profile) len x%.2f  axis height %.1f -> %.1f mm  radius ratio median %.2f (range %.2f..%.2f), size ratio heel/mid/toes %s, bins with data %d/%d' % (
            s.seg, s.fb[2] / s.fa[2], s.ha * 1000, s.hb * 1000, np.median(s.q[inn]), np.percentile(s.q[inn], 5), np.percentile(s.q[inn], 95),
            '/'.join('%.2f' % np.interp(x, tc, s.Qt) for x in (0.15, 0.5, 0.85)), int(ok.sum()), ok.size))

    def _ffr(s, Wm, side, S):
        u = pos(Wm, 'j_asi_e_' + side) - pos(Wm, 'j_asi_d_' + side); u[1] = 0; u /= np.linalg.norm(u)
        v = np.array([0, 1.0, 0]); w = np.cross(u, v)
        a = S @ u; b = S @ v; c = S @ w
        a0, a1 = a.min(), a.max(); L = a1 - a0; b0 = b.min()
        keep = b < b0 + FOOT_H * L
        tt = (a - a0) / L; toe = keep & (tt > 0.8) & (tt < 0.95)
        h = 0.5 * (b[toe].min() + b[toe].max()) - b0
        O = u * a0 + v * (b0 + h) + w * np.median(c[keep])
        if Wm is WA: s.ha = h
        else: s.hb = h
        return (O, np.stack([u, v, w], 1), L), S[keep]


def foot_maps(A, Wa, na, Y, log):
    out = {}
    for s_ in 'lr':
        ch = ['j_asi_d_' + s_, 'j_asi_e_' + s_]
        fm = FootMap(s_, chain_samples(A.P, A.T, Wa, na, ch), chain_samples(Y.P, Y.T, Y.W, Y.names, ch), log)
        out.update({b: fm for b in ch})
    return out


def chain_samples(X, T, W, names, chain, n=120000, seed=1):
    """area-uniform random points on the triangles whose corners the limb chain carries (> 0.6 on average)"""
    idx = [names.index(b) for b in chain if b in names]
    if not idx: return np.zeros((0, 3))
    cw = W[:, idx].sum(1)[T].mean(1); Tk = T[cw > 0.6]
    a = 0.5 * np.linalg.norm(np.cross(X[Tk[:, 1]] - X[Tk[:, 0]], X[Tk[:, 2]] - X[Tk[:, 0]]), axis=1)
    rng = np.random.default_rng(seed); f = rng.choice(len(Tk), n, p=a / a.sum())
    r1 = np.sqrt(rng.random(n)); r2 = rng.random(n)
    b0 = 1 - r1; b1 = r1 * (1 - r2); b2 = r1 * r2
    return b0[:, None] * X[Tk[f, 0]] + b1[:, None] * X[Tk[f, 1]] + b2[:, None] * X[Tk[f, 2]]


def limb_maps(XA, TA, WAs, namesA, XB, TB, WBs, namesB, log):
    segs = {}; smp = {}
    for b, (seg, chain) in LIMB_SEG.items():
        if seg in segs: continue
        ck = tuple(chain)
        if ck not in smp:
            smp[ck] = (chain_samples(XA, TA, WAs, namesA, chain), chain_samples(XB, TB, WBs, namesB, chain))
        segs[seg] = LimbMap(seg, smp[ck][0], smp[ck][1], log)
    return {b: segs[seg] for b, (seg, chain) in LIMB_SEG.items()}


def face_n(P, T, sign=None):
    n = np.cross(P[T[:, 1]] - P[T[:, 0]], P[T[:, 2]] - P[T[:, 0]])
    if sign is not None: n = n * sign[:, None]
    return n / np.maximum(np.linalg.norm(n, axis=1), 1e-15)[:, None]


def vert_n(P, T, sign, nv):
    fn = np.cross(P[T[:, 1]] - P[T[:, 0]], P[T[:, 2]] - P[T[:, 0]]) * sign[:, None]
    N = np.zeros((nv, 3))
    for k in range(3): np.add.at(N, T[:, k], fn)
    return N / np.maximum(np.linalg.norm(N, axis=1), 1e-15)[:, None]


def untangle(X, Xb, T, ref, sign, G, max_it=400):
    """open folded faces: the displacement from Xb around them is smoothed toward its neighbours' (growing region);
    folds left over from Xb itself are then opened by smoothing the positions there"""
    D = G.avg(X - Xb)
    for phase in (0, 1):
        for it in range(max_it):
            P = Xb + D[G.key]
            f = np.einsum('nd,nd->n', ref, face_n(P, T, sign)) < 0
            if not f.any(): return P, 0
            reg = np.zeros(G.n, bool); reg[np.unique(G.key[T[f]])] = True
            for _ in range(1 + it // 40): reg |= (G.A @ reg.astype(float)) > 0
            if phase == 0:
                D[reg] = 0.5 * D[reg] + 0.5 * (G.W @ D)[reg]
            else:
                W0 = G.avg(Xb) + D; Wn = G.W @ W0
                D[reg] = (0.5 * W0[reg] + 0.5 * Wn[reg]) - G.avg(Xb)[reg]
    P = Xb + D[G.key]
    return P, int((np.einsum('nd,nd->n', ref, face_n(P, T, sign)) < 0).sum())


def nicp(X0, A, Y, log, sched=(100, 60, 30, 15, 8, 4, 2, 1), its=4, dmax=0.03, max_fold=0.0005, landmarks=None):
    """smooth non-rigid fit; after every stiffness step the folds are opened (untangle); the steps stop when that
    leaves more than max_fold of the faces folded. landmarks: [(vertex index, target point, weight)] - points the
    surface alone cannot place (the nipples under FluxHD2's SFW bandeau)"""
    T = A.T; G = Graph(X0, T); X = X0.copy(); ref = face_n(A.P, T, A.fsign)
    X, nf = untangle(X, X0, T, ref, A.fsign, G)
    log.append('retarget folds left after untangle: %d' % nf)
    X0 = X.copy()
    YN = vert_n(Y.P, Y.T, Y.fsign, len(Y.P))
    Cy = Y
    for mu in sched:
        Xs = X.copy()
        for it in range(its):
            N = vert_n(X, T, A.fsign, len(X))
            t, w, q, d = Cy.closest(X); nq = np.einsum('ni,nid->nd', w, YN[Y.T[t]])
            ok = (d < dmax) & (np.einsum('nd,nd->n', N, nq) > 0.5)
            tgt = np.where(ok[:, None], q - X, 0.0); wa = ok.astype(float)
            Cx = Surf.__new__(Surf); Cx.P = X; Cx.T = T; Cx.C = cKDTree(X[T].mean(1))
            tb, wb, qb, db = Cx.closest(Y.P)
            okb = (db < dmax) & (np.einsum('nd,nd->n', YN, face_n(X, T, A.fsign)[tb]) > 0.5)
            acc = np.zeros_like(X); cnt = np.zeros(len(X))
            for k in range(3):
                v = T[tb[okb], k]; ww = wb[okb, k]
                np.add.at(acc, v, ww[:, None] * (Y.P[okb] - qb[okb])); np.add.at(cnt, v, ww)
            back = cnt > 1e-6
            tgt[back] = (wa[back, None] * tgt[back] + acc[back]) / (wa[back] + cnt[back])[:, None]; wa[back] += cnt[back]
            if landmarks:
                for vi, q_, wl in landmarks:
                    tgt[vi] = q_ - X[vi]; wa[vi] = wl
            wg = G.avg(wa) + 1e-4
            X = X + G.solve(wg, G.avg(wa[:, None] * tgt) / wg[:, None], mu=float(mu), nu=0.05 * mu)[G.key]
        folds = int((np.einsum('nd,nd->n', ref, face_n(X, T, A.fsign)) < 0).sum())
        X, nf = untangle(X, X0, T, ref, A.fsign, G)
        if nf and os.environ.get('NICP_DEBUG'):
            fl = np.einsum('nd,nd->n', ref, face_n(X, T, A.fsign)) < 0
            c = A.P[T[fl]].mean(1)
            log.append('   folds left at (NIRÆ mm): %s' % np.round(c[:10] * 1000).astype(int).tolist())
        t, w, q, d = Y.closest(X)
        log.append('nicp mu %5.1f: mean %.2f mm, p95 %.2f mm, max %.1f mm, matched %.0f%%, folds %d -> %d after untangle' % (mu, d.mean() * 1000, np.percentile(d, 95) * 1000, d.max() * 1000, 100 * ok.mean(), folds, nf))
        if nf > max_fold * len(T):
            log.append('  -> folds: back to the previous stiffness'); X = Xs; break
    return X


# FluxHD2's full body (vanilla chest): nipples; on the SFW body they lie under the bandeau, which the fit sees
# (areola centres from FluxHD2's own mask texture, channel 1 dark disc of ~10-15 mm radius - the vanilla chest is flat,
# its geometry shows no nipple)
FLUX_NIPPLES = {'vanilla': np.array([[0.0468, 0.5985, 0.0618], [-0.0468, 0.5985, 0.0618]])}
NIPPLE_W = float(os.environ.get('NIPPLE_W', '0'))      # (off: centring the human nipple on the areola left the V edge over it)


def nipple_landmarks(A, Y, fchest, log):
    """NIRÆ's nipple (front-most chest vertex per side) -> the FluxHD2 surface point over FluxHD2's own nipple: the
    bra's cups follow the real nipples, not just the bandeau's shape (they landed 6.5 mm out and 6 mm low)"""
    if NIPPLE_W <= 0 or fchest not in FLUX_NIPPLES: return None
    out = []
    for q in FLUX_NIPPLES[fchest]:
        sgn = np.sign(q[0])
        k = np.where((np.sign(A.P[:, 0]) == sgn) & (np.abs(A.P[:, 0]) > 0.03) & (A.P[:, 1] > 1.1) & (A.P[:, 1] < 1.35))[0]
        vi = k[np.argmax(A.P[k, 2])]
        t, w, qq, d = Y.closest(q[None])
        out.append((vi, qq[0], NIPPLE_W))
        log.append('nipple landmark: NIRÆ vertex %d %s mm -> FluxHD2 %s mm (over the nipple by %.1f mm)' % (vi, np.round(A.P[vi] * 1000, 1).tolist(), np.round(qq[0] * 1000, 1).tolist(), d[0] * 1000))
    return out


SLIDE_SIGMA = float(os.environ.get('SLIDE_SIGMA', '0.035'))


def slide_landmarks(A, X2, Y, landmarks, log):
    """the fit leaves a landmark off its target (the surface alone cannot place a nipple under a bandeau): the
    correspondence around it slides along the FluxHD2 surface - a smooth shift (Gaussian over the NIRÆ rest distance,
    sigma SLIDE_SIGMA) re-projected onto the surface; a pull on the landmark vertex alone only pinched the map there"""
    if not landmarks: return X2
    D = np.zeros_like(X2)
    for vi, q, w in landmarks:
        r = np.linalg.norm(A.P - A.P[vi], axis=1)
        D += np.exp(-(r / SLIDE_SIGMA) ** 2)[:, None] * (q - X2[vi])[None]
    X = X2 + D
    k = np.linalg.norm(D, axis=1) > 1e-5
    t, w, q, d = Y.closest(X[k]); X[k] = q
    for vi, q_, w_ in landmarks:
        log.append('landmark slide: vertex %d now %.1f mm from its target (was %.1f)' % (vi, np.linalg.norm(X[vi] - q_) * 1000, np.linalg.norm(X2[vi] - q_) * 1000))
    log.append('landmark slide: %d vertices moved, max %.1f mm' % (int(k.sum()), np.linalg.norm(X - X2, axis=1).max() * 1000))
    return X


# the bra must cover FluxHD2's areolas (mask texture: dark disc ~10 mm, faint edge to ~15 mm): the fit alone left the cup
# edge 13 mm inward / 14-17 mm outward of the centre (the Lalafell areola is large and high for its chest). Around each
# areola the correspondence is magnified (the human cup lands on a larger Lalafell area) and nudged to centre the cup
AREOLA_SCALE = float(os.environ.get('AREOLA_SCALE', '1.45'))
AREOLA_R0, AREOLA_R1 = 0.020, 0.045
AREOLA_SHIFT = float(os.environ.get('AREOLA_SHIFT', '0.0017'))     # toward the midline


def areola_fit(X2, Y, fchest, log):
    if AREOLA_SCALE == 1.0 and AREOLA_SHIFT == 0 or fchest not in FLUX_NIPPLES: return X2
    X = X2.copy()
    S, r0, r1 = AREOLA_SCALE, AREOLA_R0, AREOLA_R1
    def g(r):                       # monotonic radial map: slope S inside r0, back to identity at r1 (Hermite blend)
        out = r * S
        k = (r > r0) & (r < r1); t = (r[k] - r0) / (r1 - r0)
        y0, y1, m0, m1 = S * r0, r1, S * (r1 - r0), 1.0 * (r1 - r0)
        h00 = 2 * t ** 3 - 3 * t ** 2 + 1; h10 = t ** 3 - 2 * t ** 2 + t; h01 = -2 * t ** 3 + 3 * t ** 2; h11 = t ** 3 - t ** 2
        out[k] = h00 * y0 + h10 * m0 + h01 * y1 + h11 * m1
        out[r >= r1] = r[r >= r1]
        return out
    moved = np.zeros(len(X), bool)
    for c in FLUX_NIPPLES[fchest]:
        d = X - c; r = np.linalg.norm(d, axis=1); k = r < r1
        rr = g(r[k]); w = np.clip((r1 - r[k]) / (r1 - r0), 0, 1)
        X[k] = c + d[k] * (rr / np.maximum(r[k], 1e-9))[:, None] + (w * AREOLA_SHIFT)[:, None] * np.array([-np.sign(c[0]), 0, 0])
        moved |= k
    t, w_, q, dd = Y.closest(X[moved]); X[moved] = q
    rr = np.linspace(0, r1, 10); assert (np.diff(g(rr)) > 0).all()
    log.append('areola fit: correspondence magnified x%.2f within %.0f mm of each areola (back to x1 at %.0f mm), centred %.1f mm toward the midline; %d vertices, max move %.1f mm' % (
        S, r0 * 1000, r1 * 1000, AREOLA_SHIFT * 1000, int(moved.sum()), np.linalg.norm(X - X2, axis=1).max() * 1000))
    return X


# hands / feet slots: the NIRÆ part model's own skin (the glove / slipper were fitted to it) + the NIRÆ body around it
PART_SRC = {'hands': '/home/claude/pdfix/out/final/ohpd_glv_curvy_v4.mdl', 'feet': '/home/claude/pdfix/out/final/ohpd_sho_curvy_v4.mdl'}
PART_FLUX = {'hands': 'base_c1201_glv.mdl', 'feet': 'base_c1201_sho.mdl'}
PART_CHAIN = {'hands': ('j_ude_b', 'n_hhiji', 'n_hte', 'j_te'), 'feet': ('j_asi_c', 'j_asi_d', 'j_asi_e')}


def _body_region(S, chain):
    """triangles of a body surface whose corners the chain carries (> 0.5 on average), as a _surface item"""
    idx = [k for k, n in enumerate(S.names) if n.startswith(chain)]
    w = S.W[:, idx].sum(1)
    keep = w[S.T].mean(1) > 0.5
    T = S.T[keep]
    return (S.P, T, S.Nst, (S.W, list(S.names)), 0)


def nirae_part(part):
    items = [_body_region(nirae_body('earth', 'soft'), PART_CHAIN[part])]
    for m in read(PART_SRC[part])['meshes']:
        if not m['nv'] or 'bibo' not in m['mat']: continue          # skin only: nails float over it
        items.append((attr(m, 0)[0][:, :3].astype(float), tris(m), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), 1))
    return _surface(items)


def flux_part(part, chest='vanilla'):
    items = [_body_region(flux_body(chest), PART_CHAIN[part])]
    for m in read(FLUXD + PART_FLUX[part])['meshes']:
        if not m['nv'] or 'fluxhd_female' not in m['mat']: continue
        items.append((attr(m, 0)[0][:, :3].astype(float), tris(m), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), 1))
    return _surface(items)


def run_part(part, log, fit=True):
    """NIRÆ hands (+ forearms) / feet (+ lower legs) -> FluxHD2: per-bone affine maps (fingers / toes included, no
    pelvis, no torso / limb profile maps: the foot is no cylinder along the shin), then the non-rigid fit with a short
    reach (fingers lie ~1 cm apart on the Lalafell)"""
    A = nirae_part(part)
    Wa, na = collapse_w(A.W, A.names)
    Y = flux_part(part)
    maps = bone_maps(A.P, Wa, na, Y.P, Y.W, Y.names, log, pelvis=False)
    limbs = None
    if part == 'feet':
        # the shin around the slipper's high back: its profile map (the affine one squeezed the collar 1.8 cm into the
        # Lalafell's ankle); the foot itself keeps its affine map (no cylinder along the shin)
        limbs = {}
        for s_ in 'lr':
            b = 'j_asi_c_' + s_
            SA = chain_samples(A.P, A.T, Wa, na, [b]); SB = chain_samples(Y.P, Y.T, Y.W, Y.names, [b])
            limbs[b] = LimbMap(b, SA, SB, log)
        # the foot (heel to toes) from its skin profile (FOOTMAP=0: the old joint-to-joint affine maps)
        if os.environ.get('FOOTMAP', '1') == '1':
            limbs.update(foot_maps(A, Wa, na, Y, log))
    X1 = lbs(A.P, Wa, na, maps, None, limbs)
    t, w, q, d = Y.closest(X1)
    log.append('%s after retarget: mean %.1f mm, p95 %.1f mm, max %.1f mm' % (part, d.mean() * 1000, np.percentile(d, 95) * 1000, d.max() * 1000))
    X2 = nicp(X1, A, Y, log, dmax=PART_DMAX[part]) if fit else X1
    return A, Wa, na, Y, (maps, None, limbs), X1, X2


PART_DMAX = {'hands': 0.012, 'feet': 0.02}


def run(chest, belly, fchest, log, fit=True):
    A = nirae_body(chest, belly)
    Wa, na = collapse_w(A.W, A.names)
    Y = flux_body(fchest)
    maps = bone_maps(A.P, Wa, na, Y.P, Y.W, Y.names, log)
    cyl = CylMap(A.P, Wa, na, Y.P, Y.W, Y.names, log)
    limbs = limb_maps(A.P, A.T, Wa, na, Y.P, Y.T, Y.W, Y.names, log) if os.environ.get('LIMBMAP', '1') == '1' else None
    X1 = lbs(A.P, Wa, na, maps, cyl, limbs)
    t, w, q, d = Y.closest(X1)
    log.append('after retarget: mean %.1f mm, p95 %.1f mm, max %.1f mm, folds %d' % (d.mean() * 1000, np.percentile(d, 95) * 1000, d.max() * 1000, int((np.einsum('nd,nd->n', face_n(A.P, A.T, A.fsign), face_n(X1, A.T, A.fsign)) < 0).sum())))
    X2 = nicp(X1, A, Y, log) if fit else X1
    if fit: X2 = slide_landmarks(A, X2, Y, nipple_landmarks(A, Y, fchest, log), log)
    if fit: X2 = areola_fit(X2, Y, fchest, log)
    return A, Wa, na, Y, (maps, cyl, limbs), X1, X2


if __name__ == '__main__':
    log = []
    if sys.argv[1] in PART_SRC:                       # mapbody.py hands|feet OUT.npz
        out = sys.argv[2]
        A, Wa, na, Y, (maps, cyl, limbs), X1, X2 = run_part(sys.argv[1], log)
    else:
        chest, belly, fchest, out = sys.argv[1:5]
        A, Wa, na, Y, (maps, cyl, limbs), X1, X2 = run(chest, belly, fchest, log)
    print('\n'.join(log))
    t, w, Q, d = Y.closest(X2)
    np.savez_compressed(out, P=A.P, T=A.T, N=A.Nst, fsign=A.fsign, part=A.part, W=Wa, names=np.array(na), X1=X1, X2=X2, Q=Q, d=d,
                        maps=np.array([maps[b] for b in sorted(maps)]), mapnames=np.array(sorted(maps)))
    print('saved', out)
