"""Clothing-piece toggles: tag the triangles of a model's cloth with attributes (atrx_...) so a Penumbra Atr switch can
hide each piece. Triangles are regrouped inside each mesh (index buffer reordered, one sub-mesh per (old attributes,
new tag) group, bone map kept), vertices untouched.

tag(M, rules): rules = [(mesh_pred(mesh) -> bool, tri_pred(P, T, comp_of_tri, comp_info, mesh) -> bool[ntri], attribute
  [, sub_pred(existing sub attributes) -> bool]), ...]
  applied in order; a triangle may receive several attributes. comp_info[c] = dict(n=tris, lo=xyz min, hi=xyz max, c=centre)
  of its connected piece (corners welded at 50 um).
components(P, T) -> per-triangle component label, comp_info.
auto_pieces(M, slot) -> suggested pieces for any outfit (one per material; big separate parts get their own)."""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components


def tris_of(m):
    idx = np.frombuffer(m['idx'], np.uint16).astype(np.int64)
    out = []
    for k, s in enumerate(m['subs']):
        if s['cnt']:
            out.append((k, idx[s['off']:s['off'] + s['cnt']].reshape(-1, 3)))
    return out


def components(P, T):
    if not len(T):
        return np.zeros(0, int), {}
    key = np.unique(np.round(P / 5e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    n = key.max() + 1; Tk = key[T]
    r = np.concatenate([Tk[:, 0], Tk[:, 1], Tk[:, 2]]); c = np.concatenate([Tk[:, 1], Tk[:, 2], Tk[:, 0]])
    _, lab = connected_components(coo_matrix((np.ones(len(r)), (r, c)), shape=(n, n)), directed=False)
    lt = lab[Tk[:, 0]]
    info = {}
    for cl in np.unique(lt):
        v = np.unique(T[lt == cl]); Q = P[v]
        info[int(cl)] = dict(n=int((lt == cl).sum()), lo=Q.min(0), hi=Q.max(0), c=Q.mean(0))
    return lt, info


def tag(M, rules, pos_of):
    """pos_of(mesh) -> (nv, 3) positions. Returns {attribute: triangles tagged}."""
    rep = {}
    for m in M['meshes']:
        if not m['nv']:
            continue
        hits = [tuple(r) + ((lambda attrs: True),) * (4 - len(r)) for r in rules if r[0](m)]
        if not hits:
            continue
        assert not m.get('shapes'), 'mesh %s has shape keys: index reorder would break them' % m['mat']
        P = pos_of(m)
        groups = []                                   # (attrs tuple, sbm, tri array)
        for k, T in tris_of(m):
            s = m['subs'][k]
            lt, info = components(P, T)
            extra = [[] for _ in range(len(T))]
            for mp, tp, a, sp in hits:
                if not sp(s['attr']):
                    continue
                sel = np.asarray(tp(P, T, lt, info, m), bool)
                for i in np.nonzero(sel)[0]:
                    if a not in extra[i]: extra[i].append(a)
                rep[a] = rep.get(a, 0) + int(sel.sum())
            keys = {}
            for i, e in enumerate(extra):
                keys.setdefault(tuple(s['attr']) + tuple(x for x in e if x not in s['attr']), []).append(i)
            for ak, ii in keys.items():
                groups.append((list(ak), list(s.get('sbm', [])), T[np.array(ii)]))
        idx = []; subs = []; off = 0
        for ak, sbm, T in groups:
            idx.append(T.ravel()); subs.append(dict(off=off, cnt=T.size, attr=ak, sbm=sbm)); off += T.size
        m['idx'] = np.concatenate(idx).astype(np.uint16).tobytes()
        m['subs'] = subs
    return rep


def mat_is(*names):
    return lambda m: any(m['mat'].endswith(n) for n in names)


def all_tris(P, T, lt, info, m=None):
    return np.ones(len(T), bool)


def comp_where(f):
    """triangles whose connected piece satisfies f(info) (info: n, lo, hi, c)"""
    return lambda P, T, lt, info, m=None: np.array([f(info[int(c)]) for c in lt], bool) if len(T) else np.zeros(0, bool)


def uv_lookup(ref, tol=0.02):
    """triangles whose UV centre lies on a reference piece: ref = (uv centres (n,2), bool flags (n,)) from a model already
    tagged (same UV layout: e.g. the Lalafell port of the same outfit); a triangle takes the flag of the nearest reference
    triangle within tol in UV space"""
    from scipy.spatial import cKDTree
    tree = cKDTree(ref[0]); flags = np.asarray(ref[1], bool)
    def f(P, T, lt, info, m=None):
        if not len(T): return np.zeros(0, bool)
        from lib import attr as _attr
        UV = _attr(m, 4)[0][:, :2]
        d, j = tree.query(UV[T].mean(1))
        return flags[j] & (d < tol)
    return f
