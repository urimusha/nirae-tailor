"""skeleton bind poses (world matrices) for the human c0201 (NIRAE) and Lalafell c1201 (FluxHD2 IVCS) skeletons"""
import numpy as np, sys
import os
import sklbv5, sklb2
SRC = os.environ.get('LP_SKEL_TALL', '/mnt/user-data/uploads/FFXIVMods/NIRÆ Body/files/skl_c0201b0001_crimson_v3.sklb')
DST = os.environ.get('LP_SKEL_LALA', '/mnt/user-data/uploads/FFXIVMods/_crimson_work/fluxhd2_src/skl_c1201b0001_flux.sklb')


def qmat(q):
    x, y, z, w = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def load(path):
    n, p, T, Q, S = sklbv5.parse(path)
    WP, WQ = sklb2.world(n, p, T, Q)
    W = {}
    for k, b in enumerate(n):
        M = np.eye(4); M[:3, :3] = qmat(WQ[k]); M[:3, 3] = WP[k]; W[b] = M
    par = {b: (n[p[k]] if p[k] >= 0 else None) for k, b in enumerate(n)}
    return n, par, W
