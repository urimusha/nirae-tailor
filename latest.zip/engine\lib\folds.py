"""geometric folds of a port vs its source: interior edges whose two faces were < 60 deg apart in the source and are
> 120 deg apart now (a sheet folding back on itself), and faces whose stored normal disagrees with the geometry"""
import sys, re, numpy as np
pass
from surf import read, attr
import lalaport as TR


def fn(P, T):
    n = np.cross(P[T[:, 1]] - P[T[:, 0]], P[T[:, 2]] - P[T[:, 0]]); return n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-15)


def edge_pairs(T, P):
    key = np.unique(np.round(P / 2e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    Tk = key[T]; E = np.concatenate([Tk[:, [0, 1]], Tk[:, [1, 2]], Tk[:, [2, 0]]]); F = np.tile(np.arange(len(T)), 3)
    E = np.sort(E, 1); o = np.lexsort((E[:, 1], E[:, 0])); E = E[o]; F = F[o]
    same = (E[1:] == E[:-1]).all(1)
    return np.c_[F[:-1][same], F[1:][same]]


def check(slot, path, verbose=True):
    M = read(TR.SRC[slot]); items = TR.cloth_items(M)
    O = read(path); cloth = [m for m in O['meshes'] if m['nv'] and 'ohpd' in m['mat']]
    out = []
    for it, m in zip(items, cloth):
        T = it['I']; P = attr(m, 0)[0][:, :3].astype(float); V0 = it['V0']
        pr = edge_pairs(T, V0)
        a0 = np.einsum('nd,nd->n', fn(V0, T)[pr[:, 0]], fn(V0, T)[pr[:, 1]])
        a1 = np.einsum('nd,nd->n', fn(P, T)[pr[:, 0]], fn(P, T)[pr[:, 1]])
        bad = (a0 > 0.5) & (a1 < -0.5)
        c = P[T[pr[bad, 0]]].mean(1)
        out.append((it['mat'].split('/')[-1], int(bad.sum()), c))
        if verbose:
            print('%-4s %-24s fold edges %4d' % (slot, it['mat'].split('/')[-1], bad.sum()), ('at y %.3f..%.3f |x| %.3f..%.3f z %.3f..%.3f' % (c[:, 1].min(), c[:, 1].max(), np.abs(c[:, 0]).min(), np.abs(c[:, 0]).max(), c[:, 2].min(), c[:, 2].max())) if bad.any() else '')
    return out


if __name__ == '__main__':
    check(sys.argv[1], sys.argv[2])
