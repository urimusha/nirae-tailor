"""The game's own (vanilla) body as an author body for vanilla gear: vanilla has its own UV layout, so the outfit
cannot be matched to NIRÆ through shared UVs. Instead one NIRÆ body (Bibo UVs) is morphed onto the vanilla
smallclothes body (skin + underwear, which hugs the breasts and hips) and stored as a surface (P, T, UV, part):
port4 reads it as `author_body_npz`, so every vanilla piece fits like an outfit made for that body.
Morph: repeated closest-point pulls (only where the normals agree), each one solved smooth over the body's own mesh,
from stiff to soft. Regions vanilla lacks (hands, feet) just follow their neighbours."""
import numpy as np
from mdlio import read
from lib import attr


def _surface(models, keep):
    from surf import Surf, tris, vnorm
    Ps, Ts, o = [], [], 0
    for M in models:
        for m in M['meshes']:
            if not m['nv'] or not keep(m['mat']): continue
            P = attr(m, 0)[0][:, :3].astype(float); T = tris(m)
            Ps.append(P); Ts.append(T + o); o += len(P)
    P = np.concatenate(Ps); T = np.concatenate(Ts)
    S = Surf(P, T, np.zeros((len(P), 2)), np.zeros(len(P), int))
    return S


def build(vtop, vdwn, out_npz, log=None, iters=14):
    import port4 as P4
    from surf import Surf, vnorm
    keep = lambda mat: ('b0001' in mat) or ('e0000' in mat)          # skin + smallclothes underwear
    V = _surface([read(vtop), read(vdwn)], keep)
    VN = vnorm(V.P, V.T)
    R = P4.our_surface('curvy', 'medium')
    G = P4.Graph(R.P, R.T)
    D = np.zeros_like(R.P)
    for k in range(iters):
        X = R.P + D
        N = vnorm(X, R.T)
        t, w, q, d = V.closest(X)
        n = np.einsum('ni,nid->nd', w, VN[V.T[t]]); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
        ok = (d < 0.06) & (np.einsum('nd,nd->n', N, n) > 0.3)
        wa = G.avg(ok.astype(float)) + 1e-4
        tg = G.avg(np.where(ok[:, None], q - X, 0.0)) / wa[:, None]
        s = max(0.05, 1.0 * (0.6 ** k))                              # stiff first, then follow the detail
        dD = G.solve(wa, tg, mu=s, nu=s * 0.2)[G.key]
        D += dD
        if log is not None:
            log.append('vanilla body morph %d: matched %.0f%%, distance median %.1f p95 %.1f mm, step max %.1f mm'
                       % (k, ok.mean() * 100, np.median(d[ok]) * 1000, np.percentile(d[ok], 95) * 1000, np.abs(dD).max() * 1000))
    np.savez(out_npz, P=R.P + D, T=R.T, UV=R.UV, part=R.part)
    return out_npz
