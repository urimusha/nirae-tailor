"""Full phyb reader/writer (layout from VFXEditor PhybFormat; offsets relative to sim section start + 4)."""
import struct

def pstr(b):
    return b.split(b'\0')[0].decode('latin-1')

def wstr(s, n=32, pad=0xFE):
    if s == '':
        return b'\0' * n
    b = s.encode('latin-1') + b'\0'
    assert len(b) <= n, s
    return b + bytes([pad]) * (n - len(b))

CAPS = struct.Struct('<32s32s32s3f3ff')          # 124
ELLI = struct.Struct('<32s32s3f3f3f3ff')         # 116
NPLN = struct.Struct('<32s32s3f3ff')             # 92
TPLN = struct.Struct('<32s32s4f4f4f4f3f3f3ff')   # 164
SPHR = struct.Struct('<32s32s3ff')               # 80
SIMH = struct.Struct('<8B3f3fhhBB2s8I')          # 72
CHAIN = struct.Struct('<HH5f3fIII')              # 48
NODE = struct.Struct('<32s5f3f3fII')             # 84
CDAT = struct.Struct('<32sI')                    # 36
CONN = struct.Struct('<hhhh4fII')                # 32
ATTR = struct.Struct('<32s3fhhf')                # 52
PIN = struct.Struct('<32s3fhh')                  # 48
SPRG = struct.Struct('<hhhh2f')                  # 16
POST = struct.Struct('<32shh')                   # 36


def read(d):
    ver, typ, coff, soff = struct.unpack_from('<4I', d, 0)
    out = dict(version=ver, type=typ, capsules=[], ellipsoids=[], nplanes=[], tplanes=[], spheres=[], sims=[])
    if coff != soff:
        nc, ne, nn, nt, ns = struct.unpack_from('<5B', d, coff)
        o = coff + 8
        for _ in range(nc):
            v = CAPS.unpack_from(d, o); o += CAPS.size
            out['capsules'].append(dict(name=pstr(v[0]), start=pstr(v[1]), end=pstr(v[2]), soff=v[3:6], eoff=v[6:9], radius=v[9]))
        for _ in range(ne):
            v = ELLI.unpack_from(d, o); o += ELLI.size; out['ellipsoids'].append(v)
        for _ in range(nn):
            v = NPLN.unpack_from(d, o); o += NPLN.size; out['nplanes'].append(v)
        for _ in range(nt):
            v = TPLN.unpack_from(d, o); o += TPLN.size; out['tplanes'].append(v)
        for _ in range(ns):
            v = SPHR.unpack_from(d, o); o += SPHR.size
            out['spheres'].append(dict(name=pstr(v[0]), bone=pstr(v[1]), off=v[2:5], thickness=v[5]))
    B = soff + 4
    nsim = struct.unpack_from('<I', d, soff)[0] if soff < len(d) else 0
    for i in range(nsim):
        v = SIMH.unpack_from(d, soff + 4 + 72 * i)
        cnt = v[0:8]; offs = v[19:27]
        sim = dict(gravity=v[8:11], wind=v[11:14], cloop=v[14], colloop=v[15], flags=v[16], group=v[17], pad=v[18],
                   coll=[], collconn=[], chains=[], connectors=[], attracts=[], pins=[], springs=[], posts=[])
        def lst(k, S, off):
            r = []
            for j in range(cnt[k]):
                r.append(S.unpack_from(d, B + off + S.size * j))
            return r
        sim['coll'] = [dict(name=pstr(x[0]), type=x[1]) for x in lst(0, CDAT, offs[0])]
        sim['collconn'] = [dict(name=pstr(x[0]), type=x[1]) for x in lst(1, CDAT, offs[1])]
        for x in lst(2, CHAIN, offs[2]):
            nc, nn = x[0], x[1]
            ch = dict(damping=x[2], maxspeed=x[3], friction=x[4], colldamping=x[5], repulsion=x[6], last=x[7:10], type=x[10],
                      coll=[], nodes=[])
            for j in range(nc):
                y = CDAT.unpack_from(d, B + x[11] + 36 * j); ch['coll'].append(dict(name=pstr(y[0]), type=y[1]))
            for j in range(nn):
                y = NODE.unpack_from(d, B + x[12] + 84 * j)
                ch['nodes'].append(dict(bone=pstr(y[0]), radius=y[1], attract=y[2], wind=y[3], gravity=y[4], cone=y[5],
                                        axis=y[6:9], plane=y[9:12], cflag=y[12], ccflag=y[13]))
            sim['chains'].append(ch)
        sim['connectors'] = [dict(c1=x[0], c2=x[1], n1=x[2], n2=x[3], radius=x[4], friction=x[5], damping=x[6], repulsion=x[7], cflag=x[8], ccflag=x[9]) for x in lst(3, CONN, offs[3])]
        sim['attracts'] = [dict(bone=pstr(x[0]), off=x[1:4], chain=x[4], node=x[5], k=x[6]) for x in lst(4, ATTR, offs[4])]
        sim['pins'] = [dict(bone=pstr(x[0]), off=x[1:4], chain=x[4], node=x[5]) for x in lst(5, PIN, offs[5])]
        sim['springs'] = [dict(c1=x[0], c2=x[1], n1=x[2], n2=x[3], stretch=x[4], compress=x[5]) for x in lst(6, SPRG, offs[6])]
        sim['posts'] = [dict(name=pstr(x[0]), chain=x[1], node=x[2]) for x in lst(7, POST, offs[7] if offs[7] != 0xCCCCCCCC else 0)]
        out['sims'].append(sim)
    return out


def write(P):
    """mirror of VFXEditor's writer: header, collision section, sim headers, collision data lists, chain collision
    data, collconn, chains, connectors, attracts, pins, springs, posts, then all node lists (extra block)."""
    coll = b''
    if any(P[k] for k in ('capsules', 'ellipsoids', 'nplanes', 'tplanes', 'spheres')):
        coll = bytes([len(P['capsules']), len(P['ellipsoids']), len(P['nplanes']), len(P['tplanes']), len(P['spheres']), 0xCC, 0xCC, 0xCC])
        for c in P['capsules']:
            coll += CAPS.pack(wstr(c['name']), wstr(c['start']), wstr(c['end']), *c['soff'], *c['eoff'], c['radius'])
        for v in P['ellipsoids']:
            coll += ELLI.pack(*v)
        for v in P['nplanes']:
            coll += NPLN.pack(*v)
        for v in P['tplanes']:
            coll += TPLN.pack(*v)
        for s in P['spheres']:
            coll += SPHR.pack(wstr(s['name']), wstr(s['bone']), *s['off'], s['thickness'])
    coff = 16; soff = coff + len(coll)
    sims = P['sims']
    main = bytearray(struct.pack('<I', len(sims)))
    hdr_pos = []
    for s in sims:
        hdr_pos.append(len(main)); main += b'\0' * 72
    offs = [[0] * 8 for _ in sims]
    def put(items, enc, empty=0):
        if not items:
            return empty
        o = len(main) - 4
        for it in items:
            main.extend(enc(it))
        return o
    cd = lambda c: CDAT.pack(wstr(c['name']), c['type'])
    for i, s in enumerate(sims):
        offs[i][0] = put(s['coll'], cd)
    chain_coll = []
    for s in sims:
        for ch in s['chains']:
            chain_coll.append(len(main) - 4 if ch['coll'] else 0)
            for c in ch['coll']:
                main.extend(cd(c))
    for i, s in enumerate(sims):
        offs[i][1] = put(s['collconn'], cd)
    # chains: node offsets point into the extra block appended after everything else
    chain_fix = []        # (pos of node-offset field in main, offset inside extra)
    extra = bytearray()
    k = 0
    for i, s in enumerate(sims):
        if not s['chains']:
            offs[i][2] = 0; continue
        offs[i][2] = len(main) - 4
        for ch in s['chains']:
            pos = len(main)
            main += CHAIN.pack(len(ch['coll']), len(ch['nodes']), ch['damping'], ch['maxspeed'], ch['friction'], ch['colldamping'],
                               ch['repulsion'], *ch['last'], ch['type'], chain_coll[k], 0)
            k += 1
            if ch['nodes']:
                chain_fix.append((pos + 44, len(extra)))
            for n in ch['nodes']:
                extra += NODE.pack(wstr(n['bone']), n['radius'], n['attract'], n['wind'], n['gravity'], n['cone'], *n['axis'],
                                   *n['plane'], n['cflag'], n['ccflag'])
    for i, s in enumerate(sims):
        offs[i][3] = put(s['connectors'], lambda c: CONN.pack(c['c1'], c['c2'], c['n1'], c['n2'], c['radius'], c['friction'], c['damping'], c['repulsion'], c['cflag'], c['ccflag']))
    for i, s in enumerate(sims):
        offs[i][4] = put(s['attracts'], lambda a: ATTR.pack(wstr(a['bone']), *a['off'], a['chain'], a['node'], a['k']))
    for i, s in enumerate(sims):
        offs[i][5] = put(s['pins'], lambda a: PIN.pack(wstr(a['bone']), *a['off'], a['chain'], a['node']))
    for i, s in enumerate(sims):
        offs[i][6] = put(s['springs'], lambda a: SPRG.pack(a['c1'], a['c2'], a['n1'], a['n2'], a['stretch'], a['compress']))
    for i, s in enumerate(sims):
        offs[i][7] = put(s['posts'], lambda a: POST.pack(wstr(a['name']), a['chain'], a['node']), empty=0xCCCCCCCC)
    base = len(main)
    for pos, eo in chain_fix:
        struct.pack_into('<I', main, pos, base + eo - 4)
    for i, s in enumerate(sims):
        c = [len(s['coll']), len(s['collconn']), len(s['chains']), len(s['connectors']), len(s['attracts']), len(s['pins']),
             len(s['springs']), len(s['posts'])]
        SIMH.pack_into(main, hdr_pos[i], *c, *s['gravity'], *s['wind'], s['cloop'], s['colloop'], s['flags'], s['group'],
                       b'\xcc\xcc' if s.get('pad') is None else s['pad'], *offs[i])
    return struct.pack('<4I', P['version'], P['type'], coff, soff) + coll + bytes(main) + bytes(extra)
