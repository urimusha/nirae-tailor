import sys,struct,numpy as np
pass
from mdlio import read,write
from scipy.spatial import cKDTree
U='/mnt/user-data/uploads/FFXIVMods/Belly & Thigh Jiggle v4 (Rue+ Yiggle)/files/'
def el(m): return [(m['decl'][i*8],m['decl'][i*8+1],m['decl'][i*8+2],m['decl'][i*8+3]) for i in range(17) if m['decl'][i*8]!=255]
def attr(m,unit):
    e=[x for x in el(m) if x[3]==unit][0]; s,o,t,_=e; st=m['strides'][s]; buf=m['streams'][s]
    fmt={2:'<3f',3:'<4f',1:'<2f',13:'<4e',14:'<4e'}.get(t)
    if fmt is None: raise ValueError(t)
    return np.array([struct.unpack_from(fmt,buf,v*st+o) for v in range(m['nv'])]),e
def setpos(m,P):
    e=[x for x in el(m) if x[3]==0][0]; s,o,t,_=e; st=m['strides'][s]; buf=bytearray(m['streams'][s])
    fmt={2:'<3f',3:'<4f'}[t]
    for v in range(m['nv']):
        if t==3:
            w=struct.unpack_from('<4f',buf,v*st+o)[3]; struct.pack_into('<4f',buf,v*st+o,*P[v],w)
        else: struct.pack_into('<3f',buf,v*st+o,*P[v])
    m['streams'][s]=bytes(buf)
def bibo(f):
    X=read(f); i=[k for k,m in enumerate(X['meshes']) if m.get('mat','').endswith('bibo.mtrl')][0]; return X,i
def transfer(base_m,var_m):
    """positions of var on base topology, matching by UV then position"""
    Pb,_=attr(base_m,0); Ub,_=attr(base_m,4); Pv,_=attr(var_m,0); Uv,_=attr(var_m,4)
    Pb=Pb[:,:3]; Pv=Pv[:,:3]; Ub=Ub[:,:2]; Uv=Uv[:,:2]
    t=cKDTree(Uv); d,c=t.query(Ub,k=4)
    best=c[np.arange(len(Ub)),np.argmin(np.where(d<1e-4,np.linalg.norm(Pv[c]-Pb[:,None],axis=2),9)+d*0,axis=1)]
    out=Pv[best].copy(); bad=d[:,0]>1e-4
    return out,bad
