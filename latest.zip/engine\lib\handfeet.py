"""Gloves / shoes -> NIRÆ's own hands / feet: one fit for every build (NIRÆ has one hands and one feet model).
The author's hands / feet skin is matched to NIRÆ's through the shared (Bibo) UVs like port4 does for the body: cloth
on the skin keeps its exact height over the same skin spot, cloth further out follows the skin's move smoothly; then
the collision lift, the automatic repair (crumples) and a final clear against the skin. Weights: the skin's weights at
the same spot near it, the author's own further out (port4.body_weights). The output model is NIRÆ's hands / feet model
(skin, nails) plus the fitted cloth, each sub-mesh keeping its attributes.
For the game's own gear (vanilla=True) the author skin is the game's hands / feet morphed from NIRÆ's (vanillabody)."""
import copy
import numpy as np
from scipy.spatial import cKDTree
from mdlio import read, write, bonebbox_map
from lib import attr
import surf as S
import port4 as P4


def _skin(M, want_w=False):
    """the biggest bibo-skin mesh of a hands / feet model as a surface (UV tiles folded like author_surface)"""
    sk = max([m for m in M['meshes'] if 'b0001' in m['mat'] and m['nv']], key=lambda m: m['nv'])
    P = attr(sk, 0)[0][:, :3].astype(float); T = S.tris(sk); UV = attr(sk, 4)[0][:, :2].copy(); UV -= np.floor(UV.mean(0))
    u, inv = np.unique(T, return_inverse=True)
    W = S.dense_w(sk)[u] if want_w else None
    return S.Surf(P[u], inv.reshape(-1, 3), UV[u], np.zeros(len(u), int), W, list(sk['table']) if want_w else None)


def morph_onto(R, V, iters=12):
    """NIRÆ part R morphed onto the game's own part V (closest-point pulls solved smooth over R, stiff to soft)"""
    G = P4.Graph(R.P, R.T); D = np.zeros_like(R.P); VN = S.vnorm(V.P, V.T)
    for k in range(iters):
        X = R.P + D; N = S.vnorm(X, R.T)
        t, w, q, d = V.closest(X)
        n = np.einsum('ni,nid->nd', w, VN[V.T[t]]); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
        ok = (d < 0.04) & (np.einsum('nd,nd->n', N, n) > 0.3)
        wa = G.avg(ok.astype(float)) + 1e-4
        tg = G.avg(np.where(ok[:, None], q - X, 0.0)) / wa[:, None]
        s = max(0.05, 0.6 ** k)
        D += G.solve(wa, tg, mu=s, nu=s * 0.2)[G.key]
    return S.Surf(R.P + D, R.T, R.UV, R.part)


def hide_covered(m, Ps, items, log, slot, reach=0.03):
    """skin enclosed by the glove / shoe is left out (a tight toe cap showed the toes through it, and hidden skin only
    flickers): a skin vertex is covered when cloth lies right over it along its normal; a triangle goes only when it and
    every triangle around it are covered, so open parts (sandals, gaps between straps) keep their skin"""
    if 'b0001' not in m['mat']: return m
    P = attr(m, 0)[0][:, :3].astype(float); Nn = attr(m, 3)[0][:, :3].astype(float); Nn /= np.maximum(np.linalg.norm(Nn, axis=1), 1e-9)[:, None]
    C = S.Surf.__new__(S.Surf); C.P = np.concatenate(Ps); o = 0; T_ = []
    for P_, it in zip(Ps, items): T_.append(it['I'] + o); o += len(P_)
    C.T = np.concatenate(T_); C.C = cKDTree(C.P[C.T].mean(1))
    # along the normal: the cloth point closest to a sample 6 mm out must be outside the skin and near the normal line
    probe = P + Nn * 0.006
    t, w, q, d = C.closest(probe)
    v = q - P; along = np.einsum('nd,nd->n', v, Nn); lat = np.linalg.norm(v - along[:, None] * Nn, axis=1)
    cov = (along > -0.0005) & (along < reach) & (lat < 0.004)
    idx = np.frombuffer(m['idx'], np.uint16).astype(int)
    key = np.unique(P.round(5), axis=0, return_inverse=True)[1].ravel()
    covk = np.ones(key.max() + 1, bool); np.logical_and.at(covk, key, cov)
    subs = []; new = []; off = 0; removed = 0
    for sb in m['subs']:
        T = idx[sb['off']:sb['off'] + sb['cnt']].reshape(-1, 3)
        tc = covk[key[T]].all(1)
        # erode: a covered triangle stays when any triangle sharing a vertex with it is not covered
        bad = np.zeros(key.max() + 1, bool); bad[key[T[~tc]].ravel()] = True
        drop = tc & ~bad[key[T]].any(1)
        keep = T[~drop]; removed += int(drop.sum())
        subs.append(dict(sb, off=off, cnt=keep.size)); new.append(keep.ravel()); off += keep.size
    if not removed: return m
    m = dict(m); m['subs'] = subs; m['idx'] = np.concatenate(new).astype(np.uint16).tobytes(); m['ic'] = off
    log.append('%s: %d skin triangles enclosed by the cloth left out (%s)' % (slot, removed, m['mat'].split('/')[-1]))
    return m


def keep_contact(Ps, items, B, log, slot, full=0.004, none=0.008, down_only=False):
    """cloth that touched the author's skin (sandal straps, the sole under the foot, a glove's palm) goes back to the
    same height over NIRÆ's skin: the smooth field alone left straps hovering over a slimmer foot. The correction is
    spread smoothly over each piece (no kinks); cloth further than `none` from the author's skin is left as it is."""
    out = []; moved = []
    for P_, it in zip(Ps, items):
        a = np.clip((none - np.abs(it['off'])) / (none - full), 0, 1)
        if not (a > 0).any():
            out.append(P_); continue
        G = it['G']; X = P_.copy(); tgt_h = np.maximum(it['off'], P4.GAP + 0.0005)
        for k in range(3):
            t, w, q, d = B.closest(X); n = B.nrm(t, w)
            cur = np.einsum('nd,nd->n', X - q, n)
            dh = tgt_h - cur
            if down_only:
                dh = np.minimum(dh, 0.0)        # only straps hovering above their height come down
            corr = n * (dh * a)[:, None]
            wa = G.avg(a) + 1e-4
            tg = G.avg(corr) / wa[:, None]
            X = X + G.solve(wa, tg, mu=0.05, nu=0.01)[G.key]
        moved.append(np.linalg.norm(X - P_, axis=1)[a > 0])
        out.append(X)
    if moved:
        mv = np.concatenate(moved)
        log.append('%s: cloth that touched the author\'s skin put back on NIRÆ\'s (%d verts, moved median %.1f max %.1f mm)' % (slot, len(mv), np.median(mv) * 1000, mv.max() * 1000))
    return out


CLOSED_COVER = 0.85


def coverage(A, X, log):
    """how much of the author's foot the shoe covers (area share of skin with shoe cloth right over it)"""
    cl = [m for m in X['meshes'] if m['nv'] and not S.is_skin(m)]
    if not cl:
        return 0.0
    Ps = []; Ts = []; o = 0
    for m in cl:
        P_ = attr(m, 0)[0][:, :3].astype(float); Ps.append(P_); Ts.append(S.tris(m) + o); o += len(P_)
    C = np.concatenate(Ps)
    CS = S.Surf.__new__(S.Surf); CS.P = C; CS.T = np.concatenate(Ts); CS.C = cKDTree(C[CS.T].mean(1))
    N = S.vnorm(A.P, A.T)
    if np.mean(np.einsum('nd,nd->n', N, A.P - A.P.mean(0))) < 0:
        N = -N                               # outward
    low = A.P[:, 1] < np.percentile(C[:, 1], 99.5) - 0.01   # only the part of the foot below the shoe's top edge
    hit = np.zeros(len(A.P), bool)
    for k in range(1, 31):                   # does the outward normal run into the shoe within 6 cm?
        d = CS.closest(A.P + N * 0.002 * k)[3]
        hit |= d < 0.0025
    ar = np.linalg.norm(np.cross(A.P[A.T[:, 1]] - A.P[A.T[:, 0]], A.P[A.T[:, 2]] - A.P[A.T[:, 0]]), axis=1)
    va = np.zeros(len(A.P)); np.add.at(va, A.T.ravel(), np.repeat(ar, 3))
    va = va * low
    cov = float((va * hit).sum() / max(va.sum(), 1e-12))
    log.append('sho: the shoe covers %.0f %% of the foot' % (cov * 100))
    return cov


def closed_shoe(X, N, log, out, cov):
    """a closed shoe stays exactly as its author made it (shape and weights); NIRÆ's foot (skin and nails) under
    it is left out, so nothing can poke through and the shoe is not reshaped"""
    cl = [m for m in X['meshes'] if m['nv'] > 0 and not S.is_skin(m)]
    C = np.concatenate([attr(m, 0)[0][:, :3].astype(float) for m in cl]); tree = cKDTree(C)
    top = np.percentile(C[:, 1], 99.5)
    body = []; gone = 0
    for m in N['meshes']:
        if m['nv'] == 0:
            continue
        P = attr(m, 0)[0][:, :3].astype(float); d, _ = tree.query(P)
        hide = (d < 0.03) & (P[:, 1] < top - 0.003)
        idx = np.frombuffer(m['idx'], np.uint16).astype(int); subs = []; new = []; off = 0
        for sb in m['subs']:
            T = idx[sb['off']:sb['off'] + sb['cnt']].reshape(-1, 3); keep = T[~hide[T].all(1)]; gone += len(T) - len(keep)
            subs.append(dict(sb, off=off, cnt=keep.size)); new.append(keep.ravel()); off += keep.size
        if off:
            mm = dict(m); mm['subs'] = subs; mm['idx'] = np.concatenate(new).astype(np.uint16).tobytes(); mm['ic'] = off
            body.append(mm)
    log.append('sho: closed shoe (%.0f %% covered): kept as made, %d NIRÆ foot triangles under it left out' % (cov * 100, gone))
    Y = copy.copy(X); Y['meshes'] = body + cl
    bb = bonebbox_map(X); bb.update(bonebbox_map(N)); Y['bonebbox_by_name'] = bb
    Y['attrs'] = list(dict.fromkeys(list(X['attrs']) + list(N['attrs'])))
    Y['mats'] = []; Y['bones'] = []
    write(Y, out)
    return dict(meshes=len(Y['meshes']), cloth_vertices=int(sum(m['nv'] for m in cl)), closed=True, covered=round(cov, 3))


def port(slot, src, author, nirae_part, out, log, vanilla=False):
    P4.CFG = P4.CFG if isinstance(P4.CFG, dict) else {}
    S.CFG = S.CFG if isinstance(S.CFG, dict) else P4.CFG
    X = read(src)
    X['meshes'] = [S.upgrade_layout(m) for m in X['meshes'] if m['nv'] > 0]
    N = read(nirae_part)
    B = _skin(N, want_w=True)
    if vanilla:
        V = _skin(read(author)); A = morph_onto(B, V)
        log.append('%s: the game\'s own %s from NIRÆ\'s (morphed)' % (slot, 'hands' if slot == 'glv' else 'feet'))
    else:
        A = _skin(read(author))
    # the author's skin -> NIRÆ's: closest points, smoothed over 25 mm (gloves and shoes are mostly stiff: they move
    # with the hand / foot as a whole instead of copying every small difference of the skin under them)
    if vanilla:
        # the game's own part was shaped from NIRÆ's (same vertices): every point knows its NIRÆ point exactly (toes too)
        D = B.P - A.P; d0 = np.linalg.norm(D, axis=1); ok = np.ones(len(D), bool)
    else:
        t0, w0, q0, d0 = B.closest(A.P)
        D = q0 - A.P; ok = d0 < 0.03
    tree = cKDTree(A.P[ok]); Dk = D[ok]; sig = 0.025
    def field(X):
        nb = tree.query_ball_point(X, 2.5 * sig); out = np.zeros((len(X), 3))
        for i, js in enumerate(nb):
            if js:
                wj = np.exp(-np.sum((A.P[ok][js] - X[i]) ** 2, 1) / (2 * sig * sig)); out[i] = (wj[:, None] * Dk[js]).sum(0) / wj.sum()
        return out
    log.append('%s: author skin -> NIRÆ: moved median %.1f p95 %.1f mm' % (slot, np.median(d0) * 1000, np.percentile(d0, 95) * 1000))
    if slot == 'sho':
        cov = coverage(A, X, log)
        if cov >= CLOSED_COVER:
            return closed_shoe(X, N, log, out, cov)
    items = []; cloth = [i for i, m in enumerate(X['meshes']) if not S.is_skin(m)]
    for mi in cloth:
        m = X['meshes'][mi]
        V0, N0, T0, I = P4.cloth_data(m); G = P4.Graph(V0, I)
        t, bw, sp, dist = A.closest(V0); sn = A.nrm(t, bw)
        off = np.einsum('nd,nd->n', V0 - sp, sn)
        # every vertex moves by the smooth field (sampled on a coarse grid of the cloth and interpolated: fast)
        key = np.unique(np.round(V0 / 0.004).astype(int), axis=0, return_inverse=True)[1].ravel()
        nk = key.max() + 1; C = np.zeros((nk, 3)); np.add.at(C, key, V0); C /= np.bincount(key, minlength=nk)[:, None]
        Dv = field(C)[key]
        wa = G.avg(np.ones(len(V0))); tgt = G.avg(Dv)
        items.append(dict(mi=mi, G=G, V0=V0, I=I, wa=wa, tgt=tgt, off=off, sn=sn, mat=m['mat'], loose=False, lw=np.zeros(len(V0))))
    if not items:
        raise ValueError('no cloth in the %s model' % slot)
    Ps = [it['V0'] + it['G'].solve(it['wa'], it['tgt'])[it['G'].key] for it in items]
    if slot == 'sho':
        Ps = keep_contact(Ps, items, B, log, slot)
    Ps, lf = P4.lift(Ps, B, iters=4)
    parts = [{'stiff': [], 'rigid': []} for _ in items]
    Ps = P4.auto_fix(Ps, items, parts, B, log, slot)
    Ps = P4.final_clear(Ps, items, B, log, slot)
    # the lifts above spread over 6 mm: straps next to a spot that had to come out of a thicker ankle / heel were
    # pushed off the foot with it; they come back down to their height (never into the skin), then one last check
    if slot == 'sho':
        Ps = keep_contact(Ps, items, B, log, slot, down_only=True)
        Ps = P4.final_clear(Ps, items, B, log, slot)
    log.append('%s: lift max %.1f mm' % (slot, lf.max() * 1000))
    # pieces: one per sub-mesh (keeps its attributes), weights from NIRÆ's skin near it
    pieces = []
    for P_, it in zip(Ps, items):
        m = X['meshes'][it['mi']]
        Wc = S.dense_w(m)
        W, names, _ = P4.body_weights(P_, B, list(m['table']), Wc)
        Nn = S.vnorm(P_, it['I'])
        Tn = P4.cloth_data(m)[2]
        idx = np.frombuffer(m['idx'], np.uint16).astype(int)
        for sb in m['subs']:
            if not sb['cnt']: continue
            Tsel = idx[sb['off']:sb['off'] + sb['cnt']].reshape(-1, 3)
            mm = dict(m); mm['subs'] = [sb]
            pieces.append(P4.make_piece(mm, Tsel, P_, Nn, Tn, W, names, []))
    cloth_meshes = P4.merge(pieces)
    body_meshes = [hide_covered(mm, Ps, items, log, slot) for mm in N['meshes'] if mm['nv'] > 0]
    Y = copy.copy(X); Y['meshes'] = body_meshes + cloth_meshes
    bb = bonebbox_map(X); bb.update(bonebbox_map(N)); Y['bonebbox_by_name'] = bb
    Y['attrs'] = list(dict.fromkeys(list(X['attrs']) + list(N['attrs'])))
    Y['mats'] = []; Y['bones'] = []
    assert max(len(mm['table']) for mm in Y['meshes']) <= 64
    write(Y, out)
    return dict(meshes=len(Y['meshes']), cloth_vertices=int(sum(mm['nv'] for mm in cloth_meshes)))
