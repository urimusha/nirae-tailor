"""Gloves / shoes -> NIRÆ's own hands / feet: one fit for every build (NIRÆ has one hands and one feet model).
The author's hands / feet skin is matched to NIRÆ's through the shared (Bibo) UVs like port4 does for the body: cloth
on the skin keeps its exact height over the same skin spot, cloth further out follows the skin's move smoothly; then
the collision lift, the automatic repair (crumples) and a final clear against the skin. Weights: the skin's weights at
the same spot near it, the author's own further out (port4.body_weights). The output model is NIRÆ's hands / feet model
(skin, nails) plus the fitted cloth, each sub-mesh keeping its attributes.
For the game's own gear (vanilla=True) the author skin is the game's hands / feet morphed from NIRÆ's (vanillabody)."""
import copy
import numpy as np
from scipy.spatial import cKDTree
from mdlio import read, write, bonebbox_map
from lib import attr
import surf as S
import port4 as P4


def _skin(M, want_w=False):
    """the biggest bibo-skin mesh of a hands / feet model as a surface (UV tiles folded like author_surface)"""
    sk = max([m for m in M['meshes'] if 'b0001' in m['mat'] and m['nv']], key=lambda m: m['nv'])
    P = attr(sk, 0)[0][:, :3].astype(float); T = S.tris(sk); UV = attr(sk, 4)[0][:, :2].copy(); UV -= np.floor(UV.mean(0))
    u, inv = np.unique(T, return_inverse=True)
    W = S.dense_w(sk)[u] if want_w else None
    return S.Surf(P[u], inv.reshape(-1, 3), UV[u], np.zeros(len(u), int), W, list(sk['table']) if want_w else None)


def morph_onto(R, V, iters=12):
    """NIRÆ part R morphed onto the game's own part V (closest-point pulls solved smooth over R, stiff to soft)"""
    G = P4.Graph(R.P, R.T); D = np.zeros_like(R.P); VN = S.vnorm(V.P, V.T)
    for k in range(iters):
        X = R.P + D; N = S.vnorm(X, R.T)
        t, w, q, d = V.closest(X)
        n = np.einsum('ni,nid->nd', w, VN[V.T[t]]); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
        ok = (d < 0.04) & (np.einsum('nd,nd->n', N, n) > 0.3)
        wa = G.avg(ok.astype(float)) + 1e-4
        tg = G.avg(np.where(ok[:, None], q - X, 0.0)) / wa[:, None]
        s = max(0.05, 0.6 ** k)
        D += G.solve(wa, tg, mu=s, nu=s * 0.2)[G.key]
    return S.Surf(R.P + D, R.T, R.UV, R.part)


def port(slot, src, author, nirae_part, out, log, vanilla=False):
    P4.CFG = P4.CFG if isinstance(P4.CFG, dict) else {}
    S.CFG = S.CFG if isinstance(S.CFG, dict) else P4.CFG
    X = read(src)
    X['meshes'] = [S.upgrade_layout(m) for m in X['meshes'] if m['nv'] > 0]
    N = read(nirae_part)
    B = _skin(N, want_w=True)
    if vanilla:
        V = _skin(read(author)); A = morph_onto(B, V)
        log.append('%s: the game\'s own %s from NIRÆ\'s (morphed)' % (slot, 'hands' if slot == 'glv' else 'feet'))
    else:
        A = _skin(read(author))
    # the author's skin -> NIRÆ's: closest points, smoothed over 25 mm (gloves and shoes are mostly stiff: they move
    # with the hand / foot as a whole instead of copying every small difference of the skin under them)
    t0, w0, q0, d0 = B.closest(A.P)
    D = q0 - A.P; ok = d0 < 0.03
    tree = cKDTree(A.P[ok]); Dk = D[ok]; sig = 0.025
    def field(X):
        nb = tree.query_ball_point(X, 2.5 * sig); out = np.zeros((len(X), 3))
        for i, js in enumerate(nb):
            if js:
                wj = np.exp(-np.sum((A.P[ok][js] - X[i]) ** 2, 1) / (2 * sig * sig)); out[i] = (wj[:, None] * Dk[js]).sum(0) / wj.sum()
        return out
    log.append('%s: author skin -> NIRÆ (closest points): median %.1f p95 %.1f mm' % (slot, np.median(d0) * 1000, np.percentile(d0, 95) * 1000))
    items = []; cloth = [i for i, m in enumerate(X['meshes']) if not S.is_skin(m)]
    for mi in cloth:
        m = X['meshes'][mi]
        V0, N0, T0, I = P4.cloth_data(m); G = P4.Graph(V0, I)
        t, bw, sp, dist = A.closest(V0); sn = A.nrm(t, bw)
        off = np.einsum('nd,nd->n', V0 - sp, sn)
        # every vertex moves by the smooth field (sampled on a coarse grid of the cloth and interpolated: fast)
        key = np.unique(np.round(V0 / 0.004).astype(int), axis=0, return_inverse=True)[1].ravel()
        nk = key.max() + 1; C = np.zeros((nk, 3)); np.add.at(C, key, V0); C /= np.bincount(key, minlength=nk)[:, None]
        Dv = field(C)[key]
        wa = G.avg(np.ones(len(V0))); tgt = G.avg(Dv)
        items.append(dict(mi=mi, G=G, V0=V0, I=I, wa=wa, tgt=tgt, off=off, sn=sn, mat=m['mat'], loose=False, lw=np.zeros(len(V0))))
    if not items:
        raise ValueError('no cloth in the %s model' % slot)
    Ps = [it['V0'] + it['G'].solve(it['wa'], it['tgt'])[it['G'].key] for it in items]
    Ps, lf = P4.lift(Ps, B, iters=4)
    parts = [{'stiff': [], 'rigid': []} for _ in items]
    Ps = P4.auto_fix(Ps, items, parts, B, log, slot)
    Ps = P4.final_clear(Ps, items, B, log, slot)
    log.append('%s: lift max %.1f mm' % (slot, lf.max() * 1000))
    # pieces: one per sub-mesh (keeps its attributes), weights from NIRÆ's skin near it
    pieces = []
    for P_, it in zip(Ps, items):
        m = X['meshes'][it['mi']]
        Wc = S.dense_w(m)
        W, names, _ = P4.body_weights(P_, B, list(m['table']), Wc)
        Nn = S.vnorm(P_, it['I'])
        Tn = P4.cloth_data(m)[2]
        idx = np.frombuffer(m['idx'], np.uint16).astype(int)
        for sb in m['subs']:
            if not sb['cnt']: continue
            Tsel = idx[sb['off']:sb['off'] + sb['cnt']].reshape(-1, 3)
            mm = dict(m); mm['subs'] = [sb]
            pieces.append(P4.make_piece(mm, Tsel, P_, Nn, Tn, W, names, []))
    cloth_meshes = P4.merge(pieces)
    body_meshes = [mm for mm in N['meshes'] if mm['nv'] > 0]
    Y = copy.copy(X); Y['meshes'] = body_meshes + cloth_meshes
    bb = bonebbox_map(X); bb.update(bonebbox_map(N)); Y['bonebbox_by_name'] = bb
    Y['attrs'] = list(dict.fromkeys(list(X['attrs']) + list(N['attrs'])))
    Y['mats'] = []; Y['bones'] = []
    assert max(len(mm['table']) for mm in Y['meshes']) <= 64
    write(Y, out)
    return dict(meshes=len(Y['meshes']), cloth_vertices=int(sum(mm['nv'] for mm in cloth_meshes)))
