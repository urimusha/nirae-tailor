"""Extra (EST) skeletons of NIRÆ outfits on the FluxHD2 Lalafell: the outfit's own physics bones (Bonebound's wrist
chains, skirt chains...) keep working after the port instead of being folded onto the bone they hang from.

* bone_fits: every extra bone gets the best similarity (rotation + one scale) that takes the source cloth corners it
  carries (weight >= 0.5) onto their ported positions; bones without enough corners inherit their parent's.
* lala_world: the extra bones' bind pose on the Lalafell = that similarity applied to their source pose; the roots
  (n_hte_l, j_kosi...) are the Lalafell base skeleton's own bones.
* write_sklb: the source EST file with the new reference pose, the Lalafell race id and connect ids (the root bones'
  indices in the Lalafell base skeleton; FluxHD2 keeps the vanilla order: n_hte_l 74, n_hte_r 75, j_kosi 3).
* adapt_phyb: same simulation; node axes = the segment's rest direction in the parent bone's frame (recomputed from
  the new pose, the format's convention: checked against Bonebound's file to 3 decimals), chain node radii and the
  last segment scaled like their bones; collision shapes on the Lalafell body: offsets along a bone scaled by the bone
  length ratio, across it and the radius by the ratio of the skin's distance from the shape (NIRÆ skin vs the same
  skin spots mapped onto FluxHD2), so a capsule keeps its place relative to the skin."""
import struct
import numpy as np
from scipy.spatial.transform import Rotation as Rot
import sklinfo
import phyb_io
from tagfile_anim import Tagfile


def polar(A):
    U, s, Vt = np.linalg.svd(A)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1; R = U @ Vt
    return R


def sim_fit(X, Y, w):
    """weighted similarity X -> Y: (R, s, t) with Y ~ s R X + t"""
    w = w / w.sum()
    mx = (w[:, None] * X).sum(0); my = (w[:, None] * Y).sum(0)
    A = (w[:, None] * (Y - my)).T @ (X - mx)
    U, S, Vt = np.linalg.svd(A)
    D = np.diag([1, 1, np.sign(np.linalg.det(U @ Vt))])
    R = U @ D @ Vt
    vx = (w * ((X - mx) ** 2).sum(1)).sum()
    s = (S * np.diag(D)).sum() / max(vx, 1e-12)
    return R, s, my - s * R @ mx


def extra_bones(path):
    """(sklinfo dict, names of the non-root bones)"""
    S = sklinfo.read(path)
    return S, [n for n, p in zip(S['names'], S['par']) if p >= 0]


def bone_fits(items, bones, min_verts=6):
    """per extra bone: (R, s, t, corners) from the cloth items' source corners (V0) and ported ones (P), weights from
    their (uncollapsed) cloth weights Wc / wnames"""
    V0 = []; P = []; Wb = {b: [] for b in bones}
    for it in items:
        if it.get('shell'): continue
        V0.append(it['V0']); P.append(it['P'])
        for b in bones:
            Wb[b].append(it['Wc'][:, it['wnames'].index(b)] if b in it['wnames'] else np.zeros(len(it['V0'])))
    if not V0: return {}
    V0 = np.concatenate(V0); P = np.concatenate(P)
    out = {}
    for b in bones:
        w = np.concatenate(Wb[b]); k = w >= 0.5
        if k.sum() < min_verts: continue
        X = V0[k]
        if np.linalg.matrix_rank(X - X.mean(0), tol=1e-4) < 2: continue
        R, s, t = sim_fit(X, P[k], w[k])
        out[b] = (R, s, t, int(k.sum()))
    return out


def lala_world(S, fits, base_lala):
    """world matrices (dict) of every bone of the source EST skeleton S on the Lalafell; base_lala: name -> 4x4 world
    matrix of the Lalafell base skeleton (roots). Returns (world, scale per bone, source of each bone's pose)"""
    names, par = S['names'], S['par']
    Ws = {n: S['W'][i] for i, n in enumerate(names)}
    out = {}; scale = {}; how = {}
    for i, n in enumerate(names):
        p = par[i]
        if p < 0:
            if n not in base_lala:
                raise ValueError('root bone %s is not in the Lalafell skeleton' % n)
            out[n] = base_lala[n].copy(); scale[n] = 1.0; how[n] = 'base'
            continue
        pn = names[p]
        if n in fits:
            R, s, t, _ = fits[n]
            M = np.eye(4); M[:3, :3] = R @ polar(Ws[n][:3, :3]); M[:3, 3] = s * R @ Ws[n][:3, 3] + t
            out[n] = M; scale[n] = s; how[n] = 'fit'
        else:
            # the source offset from the parent, scaled like the parent and turned with it
            loc = np.linalg.inv(Ws[pn]) @ Ws[n]
            s = scale.get(pn, 1.0) if how.get(pn) == 'fit' else _nearest_scale(n, names, par, fits)
            Rp = out[pn][:3, :3] @ polar(Ws[pn][:3, :3]).T
            M = np.eye(4); M[:3, :3] = Rp @ polar(Ws[n][:3, :3])
            M[:3, 3] = out[pn][:3, 3] + Rp @ (Ws[n][:3, 3] - Ws[pn][:3, 3]) * s
            out[n] = M; scale[n] = s; how[n] = 'parent'
    return out, scale, how


def _nearest_scale(n, names, par, fits):
    """scale of the closest fitted bone below n (its chain), else the mean of all fits, else 1"""
    kids = [names[i] for i, p in enumerate(par) if p >= 0 and names[p] == n]
    for k in kids:
        if k in fits: return fits[k][1]
    if fits: return float(np.mean([f[1] for f in fits.values()]))
    return 1.0


def write_sklb(src_path, world, race, base_names, out):
    """the source EST file with the new reference pose (local = parent^-1 world), race id and connect ids"""
    d = open(src_path, 'rb').read()
    H = struct.unpack_from('<I', d, 12)[0]
    t = Tagfile(); t.load(d[H:])
    if t.save() != d[H:]:
        raise ValueError('%s does not round-trip' % src_path)
    sk = [o for o in t.objs if o.cls == 'hkaSkeleton'][0]
    names = [b.f['name'][1] for b in sk.f['bones'][3]]
    parents = list(sk.f['parentIndices'][3])
    old = [tuple(r) for r in sk.f['referencePose'][3]]
    rp = []
    for i, n in enumerate(names):
        W = world[n] if parents[i] < 0 else np.linalg.inv(world[names[parents[i]]]) @ world[n]
        R = polar(W[:3, :3])
        q = Rot.from_matrix(R).as_quat()
        o = old[i]
        rp.append((float(W[0, 3]), float(W[1, 3]), float(W[2, 3]), o[3], float(q[0]), float(q[1]), float(q[2]), float(q[3]),
                   o[8], o[9], o[10], o[11]))
    k2, bt2, pre2, _ = sk.f['referencePose']
    sk.f['referencePose'] = (k2, bt2, pre2, rp)
    hav = t.save()
    hdr = bytearray(d[:H])
    struct.pack_into('<I', hdr, 20, race)
    if hdr[:8] == b'blks1031':
        roots = [names[i] for i, p in enumerate(parents) if p < 0]
        old_ids = struct.unpack_from('<4H', hdr, 40)
        ids = []
        for k in range(4):
            if k < len(roots) and old_ids[k] != 0xFFFF:
                ids.append(base_names.index(roots[k]) if roots[k] in base_names else old_ids[k])
            else:
                ids.append(old_ids[k])
        struct.pack_into('<4H', hdr, 40, *ids)
    elif hdr[:8] == b'blks0031':
        c = struct.unpack_from('<H', hdr, 16)[0]
        roots = [names[i] for i, p in enumerate(parents) if p < 0]
        if c != 0xFFFF and roots and roots[0] in base_names:
            struct.pack_into('<H', hdr, 16, base_names.index(roots[0]))
    data = bytes(hdr) + hav
    open(out, 'wb').write(data)
    back = sklinfo.read(out)
    err = max(float(np.abs(back['W'][i] - world[n]).max()) for i, n in enumerate(back['names']))
    return dict(bytes=len(data), names=len(names), max_world_err=err, header=back['hdr'])


def _limb_child(b, names, par):
    """the base skeleton child that continues b's limb (the farthest standard child)"""
    return [names[i] for i, p in enumerate(par) if p >= 0 and names[p] == b]


def adapt_phyb(data, src_skel, lala_skel, src_extra, lala_extra, scale, ext_parent, skin=None, log=None):
    """phyb of the source EST for the Lalafell.
    src_skel / lala_skel: (names, parents, world 4x4 array) of the two BASE skeletons; src_extra / lala_extra: dict
    name -> world of the EST bones (source / Lalafell); scale: EST bone -> fit scale; skin: (P_src, Q_lala, W, wnames)
    corresponding skin points (NIRÆ skin and its spots on FluxHD2) with their bone weights, for collision radii"""
    log = log if log is not None else []
    P = phyb_io.read(data)
    sn, sp, sW = src_skel; ln, lp, lW = lala_skel

    def world_src(b):
        if b in src_extra: return src_extra[b]
        return sW[sn.index(b)]

    def world_lala(b):
        if b in lala_extra: return lala_extra[b]
        return lW[ln.index(b)]

    def bone_len(b, names, par, W):
        kids = [i for i, p in enumerate(par) if p >= 0 and names[p] == b]
        if not kids: return None
        i = names.index(b)
        return max(float(np.linalg.norm(W[k][:3, 3] - W[i][:3, 3])) for k in kids)

    def len_ratio(b):
        if b in src_extra: return scale.get(b, 1.0)
        if b not in sn or b not in ln: return 1.0
        a = bone_len(b, sn, sp, sW); c = bone_len(b, ln, lp, lW)
        return c / a if a and c else 1.0

    def thick_ratio(points_src, points_lala, bones):
        """skin distance ratio around a segment / point (median over the skin spots the bones carry)"""
        if skin is None: return None
        Ps, Ql, Wk, wn = skin
        cols = [wn.index(b) for b in bones if b in wn]
        if not cols: return None
        k = Wk[:, cols].sum(1) >= 0.5
        if k.sum() < 20: return None
        a0, b0 = points_src; a1, b1 = points_lala

        def dist(X, a, b):
            ab = b - a; t = np.clip((X - a) @ ab / max(ab @ ab, 1e-12), 0, 1)
            return np.linalg.norm(X - (a + t[:, None] * ab), axis=1), t
        d0, t0 = dist(Ps[k], a0, b0); d1, _ = dist(Ql[k], a1, b1)
        inner = (t0 > 0.05) & (t0 < 0.95) if np.linalg.norm(b0 - a0) > 1e-4 else np.ones(len(t0), bool)
        if inner.sum() < 10: inner = np.ones(len(t0), bool)
        r = np.median(d1[inner]) / max(np.median(d0[inner]), 1e-6)
        return float(np.clip(r, 0.3, 1.5))

    def scale_off(off, b, tr):
        lr = len_ratio(b); tr = tr if tr is not None else lr
        return (off[0] * lr, off[1] * tr, off[2] * tr)

    caps = []
    for c in P['capsules']:
        a0 = (world_src(c['start']) @ np.r_[c['soff'], 1])[:3]; b0 = (world_src(c['end']) @ np.r_[c['eoff'], 1])[:3]
        so = scale_off(c['soff'], c['start'], None); eo = scale_off(c['eoff'], c['end'], None)
        a1 = (world_lala(c['start']) @ np.r_[so, 1])[:3]; b1 = (world_lala(c['end']) @ np.r_[eo, 1])[:3]
        tr = thick_ratio((a0, b0), (a1, b1), [c['start'], c['end']])
        if tr is None: tr = float(np.mean([len_ratio(c['start']), len_ratio(c['end'])]))
        so = scale_off(c['soff'], c['start'], tr); eo = scale_off(c['eoff'], c['end'], tr)
        caps.append(dict(c, soff=tuple(float(x) for x in so), eoff=tuple(float(x) for x in eo), radius=float(c['radius'] * tr)))
        log.append('  collision %-16s radius %.1f -> %.1f mm' % (c['name'], c['radius'] * 1000, c['radius'] * tr * 1000))
    P['capsules'] = caps
    sph = []
    for s_ in P['spheres']:
        p0 = (world_src(s_['bone']) @ np.r_[s_['off'], 1])[:3]
        o = scale_off(s_['off'], s_['bone'], None)
        p1 = (world_lala(s_['bone']) @ np.r_[o, 1])[:3]
        tr = thick_ratio((p0, p0), (p1, p1), [s_['bone']]) or len_ratio(s_['bone'])
        sph.append(dict(s_, off=tuple(float(x) for x in scale_off(s_['off'], s_['bone'], tr)), thickness=float(s_['thickness'] * tr)))
    P['spheres'] = sph
    if P['ellipsoids'] or P['nplanes'] or P['tplanes']:
        log.append('  ellipsoid / plane collisions kept as they are (%d / %d / %d)' % (len(P['ellipsoids']), len(P['nplanes']), len(P['tplanes'])))
    # chains: node axes from the new rest pose, radii and the last segment scaled like their bones
    def parent_of(b):
        if b in ext_parent: return ext_parent[b]
        if b in ln:
            p = lp[ln.index(b)]
            return ln[p] if p >= 0 else None
        return None
    for si, s in enumerate(P['sims']):
        for ch in s['chains']:
            bones = [nd['bone'] for nd in ch['nodes']]
            named = [b for b in bones if b]
            if not named: continue
            last_b = named[-1]
            last_s = scale.get(last_b, len_ratio(last_b))
            ch['last'] = tuple(float(x) * last_s for x in ch['last'])
            tip = (world_lala(last_b) @ np.r_[ch['last'], 1])[:3]
            pts = [world_lala(b)[:3, 3] for b in named] + [tip]
            for k, nd in enumerate(ch['nodes']):
                b = nd['bone']
                if not b: continue
                j = named.index(b)
                d = pts[j + 1] - pts[j]
                if np.linalg.norm(d) < 1e-9: continue
                d = d / np.linalg.norm(d)
                pb = parent_of(b)
                Rp = polar(world_lala(pb)[:3, :3]) if pb else np.eye(3)
                nd['axis'] = tuple(float(x) for x in Rp.T @ d)
                nd['radius'] = float(nd['radius'] * scale.get(b, len_ratio(b)))
            # the tip node (no bone) keeps its axis; its radius follows the last bone
            for nd in ch['nodes']:
                if not nd['bone']: nd['radius'] = float(nd['radius'] * last_s)
    return phyb_io.write(P), P

