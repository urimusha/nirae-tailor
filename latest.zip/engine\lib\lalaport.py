"""Sleepy Panda (NIRÆ 1.2.0 port: Curvy, medium hips, chest 'earth', belly soft) -> FluxHD2 SFW female, Vanilla chest
(Lalafell c1201). One slot model per run (top or dwn).
1. source: the option's visible cloth triangles of the NIRÆ model (NIRÆ switches applied like the game, piercings off),
   bones collapsed onto standard bones (no squish / jiggle / IVCS bones), the bra's toggle attribute removed
2. base field: every cloth vertex moves with the NIRÆ skin spot under it (linear blend of the retarget maps with that
   spot's weights, torso through the profile map) + the fit's residual at that spot, faded out 2 -> 4 cm off the skin and
   filled smoothly over the cloth
3. glue: cloth within 1.6 cm of the NIRÆ skin goes to the same (mapped) skin spot on FluxHD2 at its own height there
   (heights up to 3 mm exact, above that scaled with the local map), filled smoothly
4. collision against FluxHD2's skin + smallclothes (one smooth lift along the averaged skin normal, every layer at a
   spot together) and the NIRÆ port's own layer order (outer pieces stay outer)
5. normals / tangents turned with the local deformation; weights = FluxHD2's own standard-bone weights at the same spot
   (faded 8 -> 20 mm off the skin into the source cloth's collapsed weights, arm rigging kept near the arms)
6. FluxHD2 SFW skin (+ armpit layer, + the smallclothes as hole covers) carried as the body pieces
usage: transfer.py top|dwn MAP.npz OUT.mdl"""
import sys, os, re, json, copy, numpy as np
pass
import surf as S
from surf import read, attr, Surf, tris, dense_w, vnorm, cKDTree
from mdlio import write, bonebbox_map
import vtx
import port4 as P4
from port4 import Graph, frames, quant
from refit import is_skin_mesh
import mapbody as MB

SEL = dict(chest='earth', cg='s', belly='soft', waist='std', nip='soft', vulva='closed')
SRC = {'top': '/home/claude/rf/final/ohpd_top_curvy_medium.mdl', 'dwn': '/home/claude/rf/final/ohpd_dwn_curvy_medium.mdl',
       'glv': MB.PART_SRC['hands'], 'sho': MB.PART_SRC['feet']}
PART = {'glv': 'hands', 'sho': 'feet'}
FLUX = dict(zip(('top', 'dwn'), MB.flux_files('vanilla')))
FLUX.update(glv=MB.FLUXD + MB.PART_FLUX['hands'], sho=MB.FLUXD + MB.PART_FLUX['feet'])
SMALLCLOTHES_FULL = {'/mt_c1201e0000_top_a.mtrl': 'chara/equipment/e0000/material/v0001/mt_c1201e0000_top_a.mtrl',
                     '/mt_c1201e0000_dwn_a.mtrl': 'chara/equipment/e0000/material/v0001/mt_c1201e0000_dwn_a.mtrl'}
GAP = float(os.environ.get('GAP', '0.0015'))
WSMOOTH = int(os.environ.get('WSMOOTH', '12'))
# the fit's correction of the skin under a cloth vertex is followed in full up to RNEAR off the skin, fading out at RFAR
# (a rounder Lalafell belly must carry the hoodie trim hanging 3-6 cm in front of it)
RNEAR, RFAR = 0.05, 0.10
KEEP_EXTRA = set()        # extra-skeleton bones the port keeps (their skeleton is ported for the Lalafell too)
LAYER_GLUE = os.environ.get('LP_LAYER_GLUE', '1') == '1'
SOFT_PARTS = os.environ.get('LP_SOFT_PARTS', '1') == '1'
ASSEMBLE = os.environ.get('LP_ASSEMBLE', '1') == '1'
ASSEMBLE_GAP = 0.003     # solid parts this close ...
ASSEMBLE_FRAC = 0.3      # ... over this share of one part's corners move as one
SOLID_SMALL = 0.025      # solid parts smaller than this stay solid even on cloth (buckles, rivets)
SOLID_ON_CLOTH = 0.005   # a part whose median distance to the cloth under it is below this lies on that cloth
ANCHOR = float(os.environ.get('LP_ANCHOR', '0.01'))   # a solid part this close to other cloth sits on it
ACC_EXT = 0.12          # parts smaller than this (source size) that float off the body move as solid objects
POKE_DIR = os.environ.get('POKE_DIR', '1') == '1'
POKE_SRC_TOL = float(os.environ.get('POKE_SRC_TOL', '0'))
P4.CFG = {}
# seam twins of the NIRÆ parts lie up to ~50 um apart (the glove's finger rims): weld them like the QA counts them
P4.weld_key.__defaults__ = (5e-5,)


def sel_ok(attrs):
    for a in attrs:
        if a.startswith('atrx_cb_') and '_' in a[8:]:
            k, v = a[8:].split('_', 1)
            if k in ('chest', 'cg', 'belly', 'hips', 'nip', 'vulva') and SEL.get(k) != v: return False
            if k == 'waist' and SEL.get('waist', 'std') != v: return False
            if k == 'pierce': return False
    return True


DROP_ATTRS = {'atrx_ohpd_bra'}       # the Panda port had no bra switch; the engine keeps every outfit attribute


def keep_attrs(attrs):
    return tuple(sorted(a for a in attrs if not a.startswith('atrx_cb_') and a not in DROP_ATTRS))


def cloth_items(M):
    out = []
    for mi, m in enumerate(M['meshes']):
        if not m['nv'] or is_skin_mesh(m) or 'nail' in m['mat']: continue
        idx = np.frombuffer(m['idx'], np.uint16).astype(int)
        Ts = []; ta = []
        for sb in m['subs']:
            if not sb['cnt'] or not sel_ok(sb['attr']): continue
            T = idx[sb['off']:sb['off'] + sb['cnt']].reshape(-1, 3); Ts.append(T); ta += [keep_attrs(sb['attr'])] * len(T)
        if not Ts: continue
        T = np.concatenate(Ts); u, inv = np.unique(T, return_inverse=True)
        data = vtx.decode(m, sel=u)
        W = dense_w(m)[u]
        Wc, names = MB.collapse_w(W, m['table'])
        tg = data[(6, 0)][1][:, :3].astype(float) / 255 * 2 - 1
        out.append(dict(mi=mi, m=m, u=u, I=inv.reshape(-1, 3), tattr=ta, data=data, V0=data[(0, 0)][1][:, :3].astype(float),
                        N0=data[(3, 0)][1][:, :3].astype(float), T0=tg, Wc=Wc, wnames=names, mat=m['mat'],
                        shell=bool(re.search(r'_fur\d\.mtrl$', m['mat']))))
    return out


def surf_of(P, T, N=None):
    s = Surf(P, T, None, np.zeros(len(P), int))
    if N is not None: s.Nst = N / np.maximum(np.linalg.norm(N, axis=1), 1e-12)[:, None]
    return s


def unit(v): return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12)


def smooth_fill(G, P_base, a, tgt, wb=0.002, mu=0.6, nu=0.02):
    """displacement field over one cloth piece: target tgt where a>0, otherwise smooth (and pulled weakly to 0)"""
    wa = G.avg(a) + wb
    t = G.avg(a[:, None] * tgt) / wa[:, None]
    return P_base + G.solve(wa, t, mu=mu, nu=nu)[G.key]


def flux_collider(slot='top'):
    """FluxHD2 SFW body for collision: skin + smallclothes + its own hands and feet (closes the wrist / ankle openings);
    open boundary corners (the neck) are marked: cloth whose closest skin point lies at the open neck edge is not
    tested for inside / too close (the head is not part of it)"""
    items = []; skinP = []; skinN = []
    for k, f in enumerate((FLUX['top'], FLUX['dwn'], MB.FLUXD + 'base_c1201_glv.mdl', MB.FLUXD + 'base_c1201_sho.mdl')):
        for m in read(f)['meshes']:
            if not m['nv'] or not any(x in m['mat'] for x in MB.FLUX_SKIN): continue
            items.append((attr(m, 0)[0][:, :3].astype(float), tris(m), attr(m, 3)[0][:, :3].astype(float), (dense_w(m), m['table']), k, m['mat']))
            if 'fluxhd_female' in m['mat']:
                skinP.append(attr(m, 0)[0][:, :3].astype(float)); skinN.append(attr(m, 3)[0][:, :3].astype(float))
    # the smallclothes are thin garments with an inner surface (faces toward the body, some double-sided copies): only
    # their outward faces are kept (normal not against the skin's around it), or cloth outside reads as inside
    skinP = np.concatenate(skinP); skinN = unit(np.concatenate(skinN)); st = cKDTree(skinP)
    out = []; dropped = 0
    for P_, T_, N_, W_, k, mat in items:
        if 'fluxhd_female' not in mat:
            fc = P_[T_].mean(1); fnrm = unit(N_[T_].sum(1))
            dd, jj = st.query(fc, k=12)
            sn_ = unit((skinN[jj] / np.maximum(dd, 1e-3)[..., None]).sum(1))
            keep = np.einsum('nd,nd->n', fnrm, sn_) > -0.3
            dropped += int((~keep).sum()); T_ = T_[keep]
        out.append((P_, T_, N_, W_, k))
    C = MB._surface(out)
    C.dropped_inner = dropped
    # parts that push cloth: the body; hands / feet only for their own slot (elsewhere they just close the openings)
    C.push = np.array({'glv': [0, 1, 2], 'sho': [0, 1, 3]}.get(slot, [0, 1]))
    nb = cKDTree(C.P).query_ball_point(C.P, 0.015)
    C.Ns = unit(np.array([C.Nst[j].sum(0) for j in nb]))
    # weld corners closer than 50 um (rounding to a grid split a few of the waist seam's twins: false open edges)
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    pr = cKDTree(C.P).query_pairs(5e-5, output_type='ndarray')
    key = connected_components(coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(C.P),) * 2), directed=False)[1]
    Tk = key[C.T]; E = np.sort(np.concatenate([Tk[:, [0, 1]], Tk[:, [1, 2]], Tk[:, [2, 0]]]), 1)
    u, c = np.unique(E, axis=0, return_counts=True); bk = np.unique(u[c == 1])
    C.bnd_pts = np.array([C.P[key == b][0] for b in bk]) if len(bk) else np.zeros((0, 3))
    C.bnd_tree = cKDTree(C.bnd_pts) if len(bk) else None
    return C


def at_open_edge(B, q, tol=0.004):
    if B.bnd_tree is None: return np.zeros(len(q), bool)
    return B.bnd_tree.query(q, distance_upper_bound=tol)[0] < tol


def needs2(P, I, B, gap, pairs=None, reach=0.02, hidden=None, skip=None):
    """port4.needs on one welded cloth: rise needed per vertex (too close / inside the skin, skin poking through a cloth
    triangle) and per layer pair; nothing at the open neck edge. skip: triangles the skin already pokes through in the
    source (the author's own coarse panels through the ankle): not tested for pokes"""
    t, w, q, d = B.closest(P); n = B.nrm(t, w)
    sd = np.einsum('nd,nd->n', P - q, n)
    ns = unit(B.at(t, w, B.Ns))
    need = np.where(((d < reach) & (sd < gap)) | ((d < 0.06) & (sd < 0)), gap - sd, 0.0)
    need[at_open_edge(B, q)] = 0
    need[~np.isin(B.part[B.T[t, 0]], B.push)] = 0     # hands / feet push only in their own slot
    if hidden is not None: need[hidden] = 0
    C = Surf.__new__(Surf); C.P = P; C.T = I; C.C = cKDTree(P[I].mean(1))
    if not hasattr(B, 'rim'): B.rim = at_open_edge(B, B.P)      # skin corners at an open edge (neck, smallclothes rims)
    # near a cloth vertex, or the middle / an edge of a big triangle (low-poly gear: skin poking through a triangle's
    # middle was more than 2 cm from every corner)
    Mid = np.r_[P, P[I].mean(1), 0.5 * (P[I[:, 0]] + P[I[:, 1]]), 0.5 * (P[I[:, 1]] + P[I[:, 2]]), 0.5 * (P[I[:, 2]] + P[I[:, 0]])]
    near = (cKDTree(Mid).query(B.P, distance_upper_bound=0.02)[0] < 0.02) & np.isin(B.part, B.push) & ~B.rim
    sp = np.where(near)[0]
    if len(sp):
        tt, ww, qq, dd = C.closest(B.P[sp], k=8)
        dv = qq - B.P[sp]; h = np.einsum('nd,nd->n', dv, B.N[sp]); lat = np.linalg.norm(dv - h[:, None] * B.N[sp], axis=1)
        bad = (dd < 0.02) & (lat < 0.003) & (h < gap)
        if hidden is not None: bad &= ~hidden[I[tt]].any(1)
        if skip is not None: bad &= ~skip[tt]
        # a poked triangle moves along the poking skin's normal: its corners' own skin normals can point to different
        # sides of a limb (a big cuff panel spanning the ankle), and lifting them apart never clears the panel
        vneed = need.copy(); pneed = np.zeros(len(P)); pdir = np.zeros_like(P)
        for k in range(3):
            v = I[tt[bad], k]; np.maximum.at(need, v, gap - h[bad]); np.maximum.at(pneed, v, gap - h[bad])
            np.add.at(pdir, v, (gap - h[bad])[:, None] * B.N[sp[bad]])
        use = (pneed > 0) & (pneed > vneed) & (np.linalg.norm(pdir, axis=1) > 1e-9)
        if POKE_DIR and use.any(): ns[use] = unit(pdir[use])
    needL = np.zeros(len(P))
    if pairs is not None and len(pairs[0]):
        v, tv, w_, da = pairs
        hq = np.einsum('ni,ni->n', w_, sd[tv]); dob = sd[v] - hq
        up = da > 0; tgt = np.clip(0.8 * np.abs(da), 0.0006, 0.003)
        np.maximum.at(needL, v[up], np.maximum(tgt[up] - dob[up], 0))
        miss = np.maximum(tgt[~up] + dob[~up], 0)
        for k in range(3): np.maximum.at(needL, tv[~up, k], miss)
    return need, ns, needL, sd


def source_pokes(V0, I, As, hidden, gap=None):
    """the poke test of needs2 on the source (NIRÆ skin vs the NIRÆ port's cloth), with POKE_SRC_TOL more clearance:
    triangles it flags there lie on or through the human skin in the author's own design (coarse cuff panels through
    the ankle, hidden under the fur shells) - lifting them on FluxHD2 only inflated the cuffs (the skin keeps poking
    through a big panel's middle while its corners rise); they and their neighbours get no poke test.
    NIRÆ's open edges excluded"""
    gap = (GAP if gap is None else gap) + POKE_SRC_TOL
    key = np.unique(np.round(As.P / 2e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    Tk = key[As.T]; E = np.sort(np.concatenate([Tk[:, [0, 1]], Tk[:, [1, 2]], Tk[:, [2, 0]]]), 1)
    u, c = np.unique(E, axis=0, return_counts=True); bk = np.unique(u[c == 1])
    rim = np.zeros(len(As.P), bool)
    if len(bk):
        first = np.full(key.max() + 1, -1); first[key[::-1]] = np.arange(len(key))[::-1]
        rim = cKDTree(As.P[first[bk]]).query(As.P)[0] < 0.004
    C = Surf.__new__(Surf); C.P = V0; C.T = I; C.C = cKDTree(V0[I].mean(1))
    near = (cKDTree(V0).query(As.P, distance_upper_bound=0.02)[0] < 0.02) & ~rim
    sp = np.where(near)[0]; skip = np.zeros(len(I), bool)
    if len(sp):
        tt, ww, qq, dd = C.closest(As.P[sp], k=8)
        Ns = As.Nst[sp]
        dv = qq - As.P[sp]; h = np.einsum('nd,nd->n', dv, Ns); lat = np.linalg.norm(dv - h[:, None] * Ns, axis=1)
        bad = (dd < 0.02) & (lat < 0.003) & (h < gap) & ~hidden[I[tt]].any(1)
        skip[tt[bad]] = True
    if skip.any():                                       # + the triangles sharing a corner with them
        vs = np.zeros(len(V0), bool); vs[I[skip].ravel()] = True
        key = np.unique(np.round(V0 / 2e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
        kv = np.zeros(key.max() + 1, bool); kv[key[vs]] = True
        skip |= kv[key[I]].any(1)
    return skip


def edge_len(P, I):
    """mean length of the edges at each vertex"""
    E = np.concatenate([I[:, [0, 1]], I[:, [1, 2]], I[:, [2, 0]]]); L = np.linalg.norm(P[E[:, 0]] - P[E[:, 1]], axis=1)
    S = np.zeros(len(P)); C = np.zeros(len(P))
    for k in (0, 1): np.add.at(S, E[:, k], L); np.add.at(C, E[:, k], 1)
    return S / np.maximum(C, 1)


def bumps(P, need, pid=None, needL=None, rmin=0.004, rmax=0.04, k=3.0, elen=None):
    """rise per vertex from the needs around it: every needing vertex j lifts its neighbourhood with a smooth bump of
    radius R = clip(k * need_j, rmin, rmax) (a 2.6 cm correction becomes a gentle ~8 cm bulge, not a kink); layer needs
    only within the same piece"""
    L = np.zeros(len(P)); tree = cKDTree(P)
    for nd, same in ((need, False), (needL, True)):
        if nd is None: continue
        js = np.where(nd > 0)[0]
        if not len(js): continue
        R = np.clip(k * nd[js], rmin, rmax)
        if elen is not None: R = np.maximum(R, np.minimum(1.5 * elen[js], rmax))   # coarse parts (big faces) move whole
        for j, Rj, nj in zip(js, R, nd[js]):
            vs = np.asarray(tree.query_ball_point(P[j], Rj))
            if same and pid is not None: vs = vs[pid[vs] == pid[j]]
            s_ = np.linalg.norm(P[vs] - P[j], axis=1) / Rj
            np.maximum.at(L, vs, nj * (1 - s_ ** 2) ** 2)
    return L


def rigidify(L, n, comp, rigid):
    """a solid part rises as a whole: its largest lift, along its mean push direction"""
    if rigid is None or not rigid.any(): return L, n
    L = L.copy(); n = n.copy()
    for c in np.unique(comp[rigid & (L > 0)]):
        k = comp == c; m = k & (L > 0)
        d = n[m].mean(0); d /= max(np.linalg.norm(d), 1e-12)
        L[k] = L[m].max(); n[k] = d
    return L, n


def collide(G, I, pid, base, B, pairs, log, iters=20, r=0.004, hidden=None, comp=None, rigid=None, skip=None):
    """smooth lift inside the welded cloth: vertices that need to rise get a target along the averaged skin normal,
    spread over r (every layer at a spot together; layer needs only within the outer piece), solved with the cloth's
    smoothness; seam corners of different pieces are one node, so seams cannot open"""
    cw = np.zeros(G.n); ct = np.zeros((G.n, 3))
    for k in range(iters):
        P = base + G.solve(1.0 + cw, (cw[:, None] * ct) / (1.0 + cw)[:, None], mu=0.6, nu=0.02)[G.key]
        if k == 0 and len(pairs[0]):
            t0, w0, q0, d0 = B.closest(P); h0 = np.einsum('nd,nd->n', P - q0, B.nrm(t0, w0))
            v_, tv_, w_, da_ = pairs; dob0 = h0[v_] - np.einsum('ni,ni->n', w_, h0[tv_])
            keep = np.where(da_ > 0, -dob0, dob0) < 0.006
            pairs = (v_[keep], tv_[keep], w_[keep], da_[keep])
            log.append('  layer pairs kept %d, structural crossings dropped %d' % (int(keep.sum()), int((~keep).sum())))
        need, n, needL, sd = needs2(P, I, B, GAP, pairs, hidden=hidden, skip=skip)
        if max(need.max(), needL.max()) < 5e-5:
            log.append('  collide iter %d: clean' % k); break
        L = bumps(P, need, pid, needL, elen=edge_len(P, I))
        L, n = rigidify(L, n, comp, rigid)
        Lw = np.zeros(G.n); np.maximum.at(Lw, G.key, L)
        Dcur = G.avg(P - base); nw = unit(G.avg(n)); m = Lw > 0
        ct[m] = Dcur[m] + (Lw[m] * 1.15)[:, None] * nw[m]; cw[m] = 20.0
        if k in (0, iters - 1) or k % 5 == 4:
            log.append('  collide iter %d: max need %.2f mm (skin) / %.2f mm (layers), verts %d' % (k, need.max() * 1000, needL.max() * 1000, int(((need > 0) | (needL > 0)).sum())))
    return P, pairs


def lift2(P, I, B, log, iters=4, r=0.004, hidden=None, comp=None, rigid=None, skip=None, pairs=None, pid=None):
    """last clearance pass: smooth rise along the averaged skin normal, all layers at a spot together; with pairs the
    port's layer order too (the outer piece rises over the inner one)"""
    tot = np.zeros(len(P))
    for k in range(iters):
        need, n, needL, sd = needs2(P, I, B, GAP, pairs, hidden=hidden, skip=skip)
        if max(need.max(), needL.max()) < 2e-5: break
        L = np.maximum(bumps(P, need, pid, needL, elen=edge_len(P, I)), np.maximum(need, needL))
        L, n = rigidify(L, n, comp, rigid)
        P = P + L[:, None] * n; tot += L
    log.append('  final lift: %d verts, max %.2f mm' % (int((tot > 1e-6).sum()), tot.max() * 1000))
    return P


def repair_crumples(P, V0, G, keep, log, thr=0.3, sigma=0.009, rounds=3):
    """where the port made the cloth much bumpier than the source (umbrella Laplacian vs the source's, over the mean
    edge), its move is replaced by the gaussian-smoothed move there (sigma 9 mm: the Lalafell is about half as big),
    blended in over 1 cm; solid parts / hidden cloth untouched. None when nothing needed it"""
    Vw = G.avg(V0); keepw = np.zeros(G.n, bool)
    if keep is not None and np.any(keep): np.logical_or.at(keepw, G.key, np.asarray(keep, bool))
    A_ = G.A.tocoo(); el = np.zeros(G.n); np.add.at(el, A_.row, np.linalg.norm(Vw[A_.row] - Vw[A_.col], axis=1)); el /= np.maximum(G.deg, 1)
    lap = lambda Z: np.linalg.norm(Z - G.W @ Z, axis=1)
    tree = cKDTree(Vw); fixed = 0; X = P.copy()
    for _ in range(rounds):
        Pw = G.avg(X); ex = lap(Pw) - lap(Vw); rel = ex / np.maximum(el, 1e-4)
        bad = (rel > thr) & (ex > 0.0007) & ~keepw
        if not bad.any(): break
        db = cKDTree(Vw[bad]).query(Vw, distance_upper_bound=0.012)[0]
        wgt = np.clip((0.012 - db) / 0.008, 0, 1) * ~keepw; reg = np.where(wgt > 0)[0]
        D = Pw - Vw; Ds = np.zeros((len(reg), 3))
        for c0 in range(0, len(reg), 400):       # in batches: the neighbour lists of dense detail (lace) took several GB at once
            rg = reg[c0:c0 + 400]; nb = tree.query_ball_point(Vw[rg], 2.5 * sigma)
            Ds[c0:c0 + 400] = np.array([(np.exp(-np.sum((Vw[j] - Vw[i]) ** 2, 1) / (2 * sigma ** 2))[:, None] * D[j]).sum(0)
                                        / np.exp(-np.sum((Vw[j] - Vw[i]) ** 2, 1) / (2 * sigma ** 2)).sum() for i, j in zip(rg, nb)])
        Dn = D.copy(); Dn[reg] = D[reg] + wgt[reg, None] * (Ds - D[reg])
        X = V0 + Dn[G.key]; fixed = max(fixed, int(bad.sum()))
    if not fixed: return None
    log.append('  repair: %d crumpled verts smoothed' % fixed)
    return X


MAP_TRUST = os.environ.get('LP_MAP_TRUST', '1') == '1'
PINCH = os.environ.get('LP_PINCH', '1') == '1'
MIDWRAP = os.environ.get('LP_MIDWRAP', '1') == '1'
PINCH_X = float(os.environ.get('LP_PINCH_X', '0.006'))      # walls within 12 mm of each other: touching thighs, not a thigh gap


def map_squeeze(Xa, Xb, T):
    """per triangle: the smallest stretch factor of the in-plane deformation Xa -> Xb (1 = unchanged, 0 = collapsed)"""
    def fr(P):
        e1 = P[T[:, 1]] - P[T[:, 0]]; e2 = P[T[:, 2]] - P[T[:, 0]]
        u = unit(e1); n = unit(np.cross(e1, e2)); v = np.cross(n, u)
        return np.stack([np.stack([(e1 * u).sum(1), (e2 * u).sum(1)], 1), np.stack([(e1 * v).sum(1), (e2 * v).sum(1)], 1)], 1)
    Fa = fr(Xa); Fb = fr(Xb)
    ok = np.abs(np.linalg.det(Fa)) > 1e-14
    J = np.zeros_like(Fa); J[ok] = Fb[ok] @ np.linalg.inv(Fa[ok])
    s = np.ones(len(T)); s[ok] = np.linalg.svd(J[ok], compute_uv=False)[:, 1]
    return s


def _nmin(G, x):
    """minimum over each node's neighbours (and itself)"""
    A = G.A.tocoo(); out = x.copy(); np.minimum.at(out, A.row, x[A.col]); return out


def crotch_hole(A, sp, tol=0.0012):
    """closest skin points sp that lie ON the rim of the crotch hole of the NIRÆ fit body (open edges across the
    midline between the legs): the cloth there is over the hole, not on skin"""
    P, T = A.P, A.T
    key = np.unique(np.round(P / 2e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    first = np.zeros(key.max() + 1, int); first[key] = np.arange(len(key))
    E = np.sort(np.concatenate([key[T[:, [0, 1]]], key[T[:, [1, 2]]], key[T[:, [2, 0]]]]), 1)
    u, c = np.unique(E, axis=0, return_counts=True); b = P[first[u[c == 1]]]
    k = (np.abs(b[:, :, 0]).max(1) < 0.03) & (b[:, :, 1].max(1) < 1.0) & (b[:, :, 1].min(1) > 0.75)
    if not k.any(): return np.zeros(len(sp), bool)
    b = b[k]; t_ = np.linspace(0, 1, 9)[None, :, None]
    pts = (b[:, None, 0] * (1 - t_) + b[:, None, 1] * t_).reshape(-1, 3)
    return cKDTree(pts).query(sp, distance_upper_bound=tol)[0] < tol


def cloth_supports(V0, I, sn, key, maxgap=0.02, mingap=3e-4, rad=0.025, chunk=3000):
    """for every cloth vertex the cloth right below it toward the skin (the ray along -sn, gap mingap..maxgap):
    (triangle index or -1, barycentric weights, gap). Triangles at the vertex's own welded node are skipped"""
    C = V0[I].mean(1); tree = cKDTree(C)
    n = len(V0); J = np.full(n, -1); BW = np.zeros((n, 3)); G0 = np.zeros(n)
    # batches by the number of vertex-triangle pairs (not by vertices): dense detail (lace, bows: thousands of triangles
    # within 2.5 cm of every vertex) made one 3000-vertex batch hold > 10 million pairs and several GB (Gothkini)
    cnt_all = tree.query_ball_point(V0, rad, return_length=True)
    cuts = [0]; acc = 0
    for i_, c_ in enumerate(cnt_all):
        acc += int(c_)
        if acc > 1500000 or i_ + 1 - cuts[-1] >= chunk: cuts.append(i_ + 1); acc = 0
    if cuts[-1] != n: cuts.append(n)
    for c0, c1 in zip(cuts[:-1], cuts[1:]):
        idx = np.arange(c0, c1)
        lists = tree.query_ball_point(V0[idx], rad)
        cnt = np.array([len(l) for l in lists])
        if not cnt.sum(): continue
        vi = np.repeat(idx, cnt); ti = np.concatenate([np.asarray(l, int) for l in lists if len(l)])
        own = (key[I[ti]] == key[vi][:, None]).any(1); vi = vi[~own]; ti = ti[~own]
        d = -sn[vi]; A_ = V0[I[ti, 0]]; e1 = V0[I[ti, 1]] - A_; e2 = V0[I[ti, 2]] - A_
        pv = np.cross(d, e2); det = np.einsum('nd,nd->n', e1, pv)
        ok = np.abs(det) > 1e-14; inv = np.where(ok, 1.0 / np.where(ok, det, 1.0), 0.0)
        tv = V0[vi] - A_; u = np.einsum('nd,nd->n', tv, pv) * inv
        qv = np.cross(tv, e1); w_ = np.einsum('nd,nd->n', d, qv) * inv; tt = np.einsum('nd,nd->n', e2, qv) * inv
        hit = ok & (u >= -1e-6) & (w_ >= -1e-6) & (u + w_ <= 1 + 1e-6) & (tt > mingap) & (tt < maxgap)
        if not hit.any(): continue
        vi, ti, u, w_, tt = vi[hit], ti[hit], u[hit], w_[hit], tt[hit]
        o = np.lexsort((tt, vi)); vi, ti, u, w_, tt = vi[o], ti[o], u[o], w_[o], tt[o]
        f = np.r_[True, vi[1:] != vi[:-1]]
        J[vi[f]] = ti[f]; G0[vi[f]] = tt[f]; BW[vi[f]] = np.c_[1 - u[f] - w_[f], u[f], w_[f]]
    return J, BW, G0


def run(slot, mapf, out, log):
    """slot / out: one slot and its output, or lists of slots fitted TOGETHER as one cloth (top + dwn share the body map:
    their pieces keep their layer order across the slots, like the pieces inside one model). Returns (rep, items, Y)
    for one slot, ({slot: rep}, items, Y) for a list (each item carries its 'slot')"""
    multi = isinstance(slot, (list, tuple))
    slots = list(slot) if multi else [slot]; outs = list(out) if multi else [out]
    assert len({s_ in PART for s_ in slots}) == 1 and (len(slots) == 1 or slots[0] not in PART), 'only top + dwn fit together'
    slot = slots[0]
    Z = np.load(mapf, allow_pickle=True)
    log_ = []
    if slot in PART:
        A, Wa, na, Y, (maps, cyl, limbs), X1, X2u = MB.run_part(PART[slot], log_, fit=False)
    else:
        A, Wa, na, Y, (maps, cyl, limbs), X1, X2u = MB.run(SEL['chest'], SEL['belly'], 'vanilla', log_, fit=False)
    assert np.allclose(A.P, Z['P']) and np.allclose(X1, Z['X1'], atol=1e-6), 'mapping file does not match this source'
    X2 = Z['X2']
    As = surf_of(A.P, A.T, A.Nst)
    B = flux_collider(slot)
    # mapped spot of every NIRÆ skin vertex on the FluxHD2 body (the mapping's own target: no hands / feet)
    ty, wy, Q, dq = Y.closest(X2); QN = unit(np.einsum('ni,nid->nd', wy, Y.Nst[Y.T[ty]]))
    R = X2 - X1
    Ms = {}; items = []
    for s_ in slots:
        Ms[s_] = read(SRC[s_]); its = cloth_items(Ms[s_])
        for it in its: it['slot'] = s_
        items += its
        log.append('%s: %d cloth pieces (%d shells) from %s' % (s_, len(its), sum(it['shell'] for it in its), os.path.basename(SRC[s_])))
    col = [it for it in items if not it['shell']]
    # one welded cloth: seam corners shared by pieces are one node in every solve
    offs = np.cumsum([0] + [len(it['V0']) for it in col])
    V0 = np.concatenate([it['V0'] for it in col]); I = np.concatenate([it['I'] + o for it, o in zip(col, offs)])
    pid = np.concatenate([np.full(len(it['V0']), k) for k, it in enumerate(col)])
    N0 = np.concatenate([it['N0'] for it in col]); T0 = np.concatenate([it['T0'] for it in col])
    names = sorted({n for it in col for n in it['wnames']})
    Wc = np.concatenate([_expand(it['Wc'], it['wnames'], names) for it in col])
    G = Graph(V0, I)
    log.append('  welded cloth: %d verts, %d nodes, %d pieces' % (len(V0), G.n, len(col)))
    t, bw, sp, dist = As.closest(V0)
    sn = unit(np.einsum('ni,nid->nd', bw, As.Nst[A.T[t]]))
    off = np.einsum('nd,nd->n', V0 - sp, sn)
    # hidden in the source (inside the NIRÆ body by > 1 mm): left where the map puts it, never pushed out
    hidden = off < -0.001
    # cloth over the hole in the fit's NIRÆ body (the vulva is not part of it: a 2 cm wide gap from the mons to the
    # perineum): its nearest 'skin' is the hole's rim, which says nothing about where it belongs. It is not glued and
    # does not follow the rim's correction - it is filled in smoothly from the cloth around it that lies on real skin
    # (a thong's crotch strip glued to the rim came out crumpled and hanging: Gothkini)
    over_hole = crotch_hole(A, sp) if (slot not in PART and os.environ.get('LP_HOLE', '1') == '1') else np.zeros(len(V0), bool)
    hidden &= ~over_hole
    if over_hole.any(): log.append('  over the crotch gap of the fit body (filled from the cloth around): %d verts' % int(over_hole.sum()))
    # where the surface fit squeezes the skin under the cloth flat (the groin: NIRÆ's inner thighs stand 2 cm apart
    # where the Lalafell's meet, the fit's correction collapses those triangles to under a third of their width) the
    # mapped spot is not a place for cloth: glued there, a thong's panel bunched up into lumps. Such cloth is trusted
    # less (none below x0.3, fully from x0.5 of the narrowest stretch of the correction, spread 2 rings and smoothed
    # over the cloth) and follows the smooth base field and its glued neighbours instead; the collision clears it.
    trust = np.ones(len(V0))
    if MAP_TRUST and slot not in PART:
        # (the legs' skin only: on the chest the fit's nipple level compresses the map on purpose)
        smin = np.where(A.part[A.T[t, 0]] == 1, map_squeeze(X1, X2, A.T)[t], 1.0)
        tr_ = np.clip((smin - 0.3) / 0.2, 0, 1); tn = G.avg(tr_)
        for _ in range(2): tn = np.minimum(tn, G.nmin(tn)) if hasattr(G, 'nmin') else np.minimum(tn, _nmin(G, tn))
        for _ in range(6): tn = 0.5 * tn + 0.5 * np.minimum(tn, G.W @ tn)
        trust = np.where(over_hole, 0.0, tn[G.key])
        # layers lying on each other share it (the lacing on a panel was glued while the panel under it was not: its
        # ends stuck out of the panel's edge): the lowest trust of the cloth within 6 mm in the source
        dn_, jn_ = cKDTree(V0).query(V0, k=24, distance_upper_bound=0.006)
        trust = np.where(np.isfinite(dn_), trust[np.minimum(jn_, len(V0) - 1)], 1.0).min(1)
        log.append('  squeezed by the fit (not glued there): %d verts' % int((trust < 0.5).sum()))
    log.append('  hidden in the source (inside NIRÆ): %d verts' % int(hidden.sum()))
    # 2. base field: retarget with blend weights from the skin AROUND each cloth vertex (inverse-square distance over
    # the nearest 48 skin corners within 8 cm), so cloth in the gap between arm and torso blends both maps and stays in
    # the (narrower) Lalafell gap; then diffused over the cloth
    dk, jk = cKDTree(A.P).query(V0, k=48, distance_upper_bound=0.08)
    ok = np.isfinite(dk); jk = np.where(ok, jk, 0)
    wk = np.where(ok, 1.0 / np.maximum(dk, 0.002) ** 2, 0.0)
    Wspot = np.einsum('ni,nij->nj', bw, Wa[A.T[t]])
    Wnb = np.einsum('nk,nkj->nj', wk, Wa[jk]) / np.maximum(wk.sum(1), 1e-12)[:, None]
    Wsk = np.where(ok.any(1)[:, None], Wnb, Wspot)
    Wg = G.avg(Wsk)
    for _ in range(WSMOOTH): Wg = 0.5 * Wg + 0.5 * (G.W @ Wg)
    Pl = MB.lbs(V0, Wg[G.key], na, maps, cyl, limbs)
    X1s = np.einsum('ni,nid->nd', bw, X1[A.T[t]]); Rs = np.einsum('ni,nid->nd', bw, R[A.T[t]])
    Pa = smooth_fill(G, Pl, np.where(over_hole, 0.0, trust * np.clip((RFAR - dist) / (RFAR - RNEAR), 0, 1)), Rs, wb=0.01)
    Pa, f0, f1 = untangle_cloth(Pa, Pl, I, V0, G)
    log.append('  base field folds %d -> %d' % (f0, f1))
    # 3. glue: same mapped skin spot, own height (<= 3 mm exact, beyond scaled like the map scales the offset)
    Qs = np.einsum('ni,nid->nd', bw, Q[A.T[t]]); Qn = unit(np.einsum('ni,nid->nd', bw, QN[A.T[t]]))
    r = np.clip(np.linalg.norm(Pl - X1s, axis=1) / np.maximum(np.abs(off), 1e-4), 0.5, 1.2)
    ht = np.sign(off) * (np.minimum(np.abs(off), 0.003) + np.maximum(np.abs(off) - 0.003, 0) * r)
    ag = np.where(over_hole, 0.0, trust * np.clip((0.016 - dist) / 0.006, 0, 1))
    tgt = Qs + ht[:, None] * Qn
    # a narrow strip running under the crotch (a thong's string and the tip of its panel: no cloth beside it in the
    # source) that the fit cannot place (over the gap / squeezed skin above). On NIRÆ it runs through a 2 cm gap between
    # the thighs; the Lalafell's thighs meet there. Pushed out of both thighs it hung 1.5 cm under the body as a
    # stretched tube; left where the base put it, it sat inside the body in ragged bits. It is laid on the Lalafell's
    # own skin along the body's midline instead - the faces between the thighs / buttocks that do not face sideways
    # (mons, perineum, the bottom of the cleft) - 2 mm off it plus its own height in the source (up to 4 mm), at half
    # its width (that skin is narrow; the closest point keeps it on it), and is not pushed again by the thighs.
    wrap = np.zeros(len(V0), bool)
    if MIDWRAP and slot not in PART:
        cy_ = np.floor(V0[:, 1] / 0.005).astype(np.int64); cz_ = np.floor(V0[:, 2] / 0.005).astype(np.int64)
        wid = {}
        for a_, b_, x_ in zip(cy_.tolist(), cz_.tolist(), np.abs(V0[:, 0]).tolist()):
            if x_ > wid.get((a_, b_), 0.0): wid[(a_, b_)] = x_
        halfw = np.array([max(wid.get((a_ + i_, b_ + j_), 0.0) for i_ in (-1, 0, 1) for j_ in (-1, 0, 1)) for a_, b_ in zip(cy_.tolist(), cz_.tolist())])
        cand = halfw < 0.022
        if cand.sum() >= 8:
            # the Lalafell's skin around the crotch as a height map: its radius from a sideways axis through the pelvis,
            # by angle around that axis (0 = straight down, + = front) and by sideways position x, found with rays
            # from the axis (the last time a ray leaves the body within 7 cm; a ray still inside by then is in a thigh:
            # no skin for cloth there). The strip keeps the shape the base field gave it - its angle and x - and is put
            # on that skin, 2 mm off plus its own height in the source (up to 4 mm). Where the skin between the thighs
            # is narrower than the strip, the strip is narrowed to it (soft limit), nowhere else.
            ylo = Pa[cand, 1].min()
            kb = (np.abs(B.P[B.T][:, :, 0]).min(1) < 0.05) & (B.P[B.T][:, :, 1].max(1) > ylo - 0.06) & (B.P[B.T][:, :, 1].min(1) < ylo + 0.14)
            tri = B.P[B.T[kb]]
            if len(tri) >= 20:
                mid = tri[(np.abs(tri[:, :, 0]).min(1) < 0.004)].reshape(-1, 3)
                c0 = np.array([0.0, mid[:, 1].min() + 0.05, 0.5 * (mid[mid[:, 1] < mid[:, 1].min() + 0.03, 2].min() + mid[mid[:, 1] < mid[:, 1].min() + 0.03, 2].max())])
                NA, NX, RMAX, XM = 180, 33, 0.10, 0.032
                th_ = (np.arange(NA) + 0.5) / NA * 2 * np.pi - np.pi; xs_ = np.linspace(-XM, XM, NX) + 0.00037      # (off the mirror plane: its rays run along the skin's seam edges)
                TH, XX = np.meshgrid(th_, xs_, indexing='ij')
                O = np.stack([XX.ravel(), np.full(XX.size, c0[1]), np.full(XX.size, c0[2])], 1)
                Dr = np.stack([np.zeros(XX.size), -np.cos(TH.ravel()), np.sin(TH.ravel())], 1)
                e1 = tri[:, 1] - tri[:, 0]; e2 = tri[:, 2] - tri[:, 0]
                last = np.full(len(O), np.nan); cnt = np.zeros(len(O), int)
                for c_ in range(0, len(O), 400):
                    o_ = O[c_:c_ + 400, None]; d_ = Dr[c_:c_ + 400, None]
                    pv = np.cross(d_, e2[None]); det = np.einsum('rtd,td->rt', pv, e1); ok_ = np.abs(det) > 1e-12
                    inv = np.where(ok_, 1.0 / np.where(ok_, det, 1.0), 0.0); tv = o_ - tri[None, :, 0]
                    u_ = np.einsum('rtd,rtd->rt', tv, pv) * inv; qv = np.cross(tv, e1[None]); v_ = np.einsum('rtd,rtd->rt', np.broadcast_to(d_, qv.shape), qv) * inv
                    t_ = np.einsum('rtd,td->rt', qv, e2) * inv
                    hit = ok_ & (u_ >= -1e-6) & (v_ >= -1e-6) & (u_ + v_ <= 1 + 1e-6) & (t_ > 1e-5) & (t_ < RMAX)
                    cnt[c_:c_ + 400] = hit.sum(1); tm = np.where(hit, t_, -1.0).max(1); last[c_:c_ + 400] = np.where(tm > 0, tm, np.nan)
                Rm = np.where(cnt % 2 == 1, last, np.nan).reshape(NA, NX); val = ~np.isnan(Rm); ic = NX // 2
                # usable half-width by angle: the valid run around x = 0
                wv = np.zeros(NA)
                for a_i in range(NA):
                    if not val[a_i, ic]: continue
                    j = 0
                    while (ic + j + 1 < NX and val[a_i, ic + j + 1] and val[a_i, ic - j - 1]
                           and abs(Rm[a_i, ic + j + 1] - Rm[a_i, ic + j]) < 0.008 and abs(Rm[a_i, ic - j - 1] - Rm[a_i, ic - j]) < 0.008): j += 1
                    wv[a_i] = xs_[ic + j]
                    Rm[a_i, :ic - j] = Rm[a_i, ic - j]; Rm[a_i, ic + j + 1:] = Rm[a_i, ic + j]
                okA = wv > 0
                log.append('  crotch height map: %d triangles, rays leaving the body %d of %d, angles with skin at the midline %d of %d' % (len(tri), int(val.sum()), val.size, int(okA.sum()), NA))
                if okA.sum() >= 20:
                    ia_ = np.where(okA)[0]
                    for j_ in range(NX): Rm[:, j_] = np.interp(np.arange(NA), ia_, Rm[ia_, j_], period=NA)
                    wv = np.interp(np.arange(NA), ia_, wv[ia_], period=NA)
                    ka = np.exp(-0.5 * (np.arange(-9, 10) / 3.0) ** 2); ka /= ka.sum(); kx = np.exp(-0.5 * (np.arange(-3, 4) / 1.5) ** 2); kx /= kx.sum()
                    Rm = np.apply_along_axis(lambda v: np.convolve(np.r_[v[-9:], v, v[:9]], ka, mode='valid'), 0, Rm)
                    Rm = np.apply_along_axis(lambda v: np.convolve(np.r_[[v[0]] * 3, v, [v[-1]] * 3], kx, mode='valid'), 1, Rm)
                    wv = np.maximum(np.convolve(np.r_[wv[-9:], wv, wv[:9]], ka, mode='valid') - 0.001, 0.003)
                    ci = np.where(cand)[0]; a_ = np.arctan2(Pa[ci, 2] - c0[2], -(Pa[ci, 1] - c0[1]))
                    fa = (a_ + np.pi) / (2 * np.pi) * NA - 0.5; a0 = np.floor(fa).astype(int); ta = fa - a0
                    w_ = (1 - ta) * wv[a0 % NA] + ta * wv[(a0 + 1) % NA]
                    # the strip's own half-width at that angle (the widest of its vertices there, smoothed)
                    ab_ = np.clip(np.round(fa).astype(int) % NA, 0, NA - 1); ws_ = np.zeros(NA); np.maximum.at(ws_, ab_, np.abs(Pa[ci, 0]))
                    ws_ = np.maximum.reduce([np.roll(ws_, s_) for s_ in (-2, -1, 0, 1, 2)]); w_strip = ws_[ab_]
                    # the strip keeps its own width wherever the skin is wide enough for it (in front: the mons) and is
                    # narrowed, softly, only to the width of skin there is (under the crotch, between the buttocks);
                    # everywhere it lies on the skin under it, 2 mm off plus its own height in the source (up to 4 mm)
                    # (scaled evenly across its width - squeezing only its edges piled the lace there up in ridges)
                    xt = Pa[ci, 0] * np.minimum(1.0, w_ / np.maximum(w_strip, 1e-6))
                    fx = np.clip((xt + XM) / (2 * XM) * (NX - 1), 0, NX - 1 - 1e-6); x0 = np.floor(fx).astype(int); tx = fx - x0
                    r_s = ((1 - ta) * (1 - tx) * Rm[a0 % NA, x0] + (1 - ta) * tx * Rm[a0 % NA, x0 + 1] + ta * (1 - tx) * Rm[(a0 + 1) % NA, x0] + ta * tx * Rm[(a0 + 1) % NA, x0 + 1])
                    # where it is narrowed its layers are flattened with it (a quarter of their height, order kept): the
                    # lacing on a panel squeezed to a third of its width stood up in ridges
                    sq_ = np.clip((w_strip - w_) / np.maximum(w_strip, 1e-6), 0, 1)        # 0 = the strip fits the skin there
                    hf_ = 1 - 0.75 * np.clip(sq_ / 0.4, 0, 1)
                    r_t = r_s + 0.002 - 0.0005 * (1 - hf_) / 0.75 + hf_ * np.minimum(np.abs(off[ci]), 0.004)
                    wz = (1 - trust[ci]) * np.clip((np.radians(110) - np.abs(a_)) / np.radians(20), 0, 1)
                    tw = np.stack([xt, c0[1] - r_t * np.cos(a_), c0[2] + r_t * np.sin(a_)], 1)
                    tgt[ci] = (1 - wz)[:, None] * tgt[ci] + wz[:, None] * tw
                    ag[ci] = np.maximum(ag[ci], wz); wrap[ci] = wz > 0.5
                    log.append('  narrow strip under the crotch laid on the skin height map: %d verts; skin half-width under the crotch %.1f mm, in front %.1f mm' % (
                        int(wrap.sum()), wv[NA // 2] * 1000, wv[int(NA * (0.5 + 60 / 360.0))] * 1000))
    Pb = smooth_fill(G, Pa, ag, tgt - Pa, wb=0.002)
    Pb, f0, f1 = untangle_cloth(Pb, Pa, I, V0, G)
    log.append('  glued %d of %d, glue folds %d -> %d, base->glue max %.1f mm' % (int((ag > 0.5).sum()), len(V0), f0, f1, np.linalg.norm(Pb - Pa, axis=1).max() * 1000))
    # 3b. solid accessories (pouches, grenade, rings, buckles, the tail ball): small floating non-fur parts keep their
    # shape - best similarity (rotation + one scale) to where the map put them
    comp = G.comp[G.key]; rigid = np.zeros(len(V0), bool); racc = []
    fur = np.array(['_fur' in col[p]['mat'] for p in pid])
    for c in np.unique(comp):
        k = comp == c
        if k.sum() < 8 or fur[k].any() or np.ptp(V0[k], axis=0).max() > ACC_EXT or np.median(off[k]) < 0.008: continue
        rigid[k] = True; racc.append(c)
    # a big part lying on other cloth (a lapel panel, a pocket, a strap over a coat) is cloth, not a solid object: it
    # bends with the cloth under it (layered glue below); small hardware on cloth (buckles, rivets) and parts in the
    # air (chain links, cuffs, pendants) stay solid
    if racc and (~rigid).any() and SOFT_PARTS:
        Sb0 = surf_of(V0, I[~rigid[I].any(1)])
        soft = []
        for c in racc:
            k = comp == c
            if np.ptp(V0[k], axis=0).max() < SOLID_SMALL: continue
            if np.median(Sb0.closest(V0[k])[3]) < SOLID_ON_CLOTH: soft.append(c)
        for c in soft: rigid[comp == c] = False
        racc = [c for c in racc if c not in soft]
        if soft: log.append('  parts on other cloth that bend with it: %d' % len(soft))
    # 3a. layers: cloth lying on other cloth keeps its own spacing to that cloth (the skin glue alone let a pocket on
    # Bonebound's coat, 2 cm off the skin, sink under the coat it sits on: 11% of the cloth over other cloth flipped)
    if LAYER_GLUE:
        Jsup, BWs, g0 = cloth_supports(V0, I, sn, G.key)
        sup = (Jsup >= 0) & ~rigid & ~hidden
        sup[sup] &= ~rigid[I[Jsup[sup]]].any(1)
        g1 = np.minimum(g0, 0.003) + np.maximum(g0 - 0.003, 0) * r              # spacing scaled like the skin heights
        # close to the skin the skin glue already keeps the layers (same skin spot, own heights): only cloth standing off
        # the skin (> 4 mm, fully from 8 mm) follows the cloth under it - on tight gloves the layered glue added folds
        a_s = np.where(sup, np.clip((0.016 - g0) / 0.008, 0, 1) * np.clip((off - 0.004) / 0.004, 0, 1), 0.0)
        sup &= a_s > 0
        Pb0 = Pb.copy()
        for _ in range(3):                                                         # layers on layers settle outward
            spt = np.einsum('ni,nid->nd', BWs[sup], Pb[I[Jsup[sup]]])
            tg = np.zeros_like(Pb); tg[sup] = spt + g1[sup, None] * Qn[sup] - Pb[sup]
            a_ = np.where(sup, a_s, ag)                                            # the rest keeps its skin glue
            Pb = smooth_fill(G, Pb, a_, tg, wb=0.002)
        Pb, f0, f1 = untangle_cloth(Pb, Pb0, I, V0, G, new_only=True)
        log.append('  layered glue: %d verts on other cloth, moved max %.1f mm, folds %d -> %d' % (
            int((a_s > 0.5).sum()), np.linalg.norm(Pb - Pb0, axis=1).max() * 1000, f0, f1))
    # parts lying on other cloth (straps, buckles, chains on a coat) follow that cloth: each corner's target is the same
    # spot of the cloth under it (as glued / mapped) with its source offset turned like that cloth's triangle; parts
    # in the air keep following the map. Fitted to the map alone, the straps on Bonebound's back band turned and spread
    # into flaps where the band narrows
    baseT = I[~rigid[I].any(1)]
    anch = 0
    if len(racc) and len(baseT):
        Sb = surf_of(V0, baseT)
        def frame(X, T_):
            e1 = unit(X[T_[:, 1]] - X[T_[:, 0]]); n_ = unit(np.cross(X[T_[:, 1]] - X[T_[:, 0]], X[T_[:, 2]] - X[T_[:, 0]]))
            return np.stack([e1, np.cross(n_, e1), n_], axis=-1)       # columns: e1, e2, n
    # solid assemblies: solid parts lying on each other (a pouch's flap on its body, a strap round a cuff ring) move
    # as one, or each one's own fit shifts them through each other; interlocked chain links touch only a little
    # and stay separate
    groups = {c: [c] for c in racc}
    if len(racc) > 1 and ASSEMBLE:
        rv = np.where(rigid)[0]; rtree = cKDTree(V0[rv]); par_ = {c: c for c in racc}
        def find(c):
            while par_[c] != c: par_[c] = par_[par_[c]]; c = par_[c]
            return c
        for c in racc:
            k = np.where(comp == c)[0]
            d_, j_ = rtree.query(V0[k], k=6, distance_upper_bound=ASSEMBLE_GAP)
            near = np.isfinite(d_); oc = np.where(near, comp[rv[np.minimum(j_, len(rv) - 1)]], -1)
            for o in np.unique(oc[(oc >= 0) & (oc != c)]):
                if (oc == o).any(1).sum() >= ASSEMBLE_FRAC * len(k): par_[find(o)] = find(c)
        groups = {}
        for c in racc: groups.setdefault(find(c), []).append(c)
        merged = {g: m for g, m in groups.items() if np.ptp(V0[np.isin(comp, m)], axis=0).max() <= 1.5 * ACC_EXT}
        groups = {**{c: [c] for g, m in groups.items() if g not in merged for c in m}, **merged}
        nm = sum(len(m) > 1 for m in groups.values())
        if nm: log.append('  solid assemblies: %d (%d parts)' % (nm, sum(len(m) for m in groups.values() if len(m) > 1)))
    for c, members in groups.items():
        k = np.where(np.isin(comp, members))[0]
        tgt = Pb[k]
        if len(baseT):
            tb, wb_, qb, db = Sb.closest(V0[k])
            if np.median(db) < ANCHOR:
                Tk = baseT[tb]
                F0 = frame(V0, Tk); F1 = frame(Pb, Tk)
                q1 = np.einsum('ni,nid->nd', wb_, Pb[Tk])
                o0 = np.einsum('ndc,nd->nc', F0, V0[k] - qb)                # source offset in the source triangle frame
                tgt = q1 + np.einsum('ndc,nc->nd', F1, o0); anch += 1
        a0 = V0[k] - V0[k].mean(0); b0 = tgt - tgt.mean(0)
        U, S_, Vt = np.linalg.svd(b0.T @ a0); Dm = np.diag([1, 1, np.sign(np.linalg.det(U @ Vt))]); Rm = U @ Dm @ Vt
        sc = (S_ * np.diag(Dm)).sum() / max((a0 ** 2).sum(), 1e-12)
        Pb[k] = tgt.mean(0) + sc * a0 @ Rm.T
    log.append('  solid accessories: %d parts, %d verts (%d on other cloth)' % (len(racc), int(rigid.sum()), anch))
    Pglue = Pb.copy()
    # cloth between skin walls that face each other across the body's midline (the Lalafell's thighs and buttocks
    # meet where NIRÆ has a 2 cm gap): it is tucked in there, out of sight. Pushing it out of both walls at once made
    # the lumps under a thong's panel; it stays where the fit put it, like cloth hidden in the source
    if PINCH and slot not in PART:
        t_, w_, q_, d_ = B.closest(Pb); n_ = B.nrm(t_, w_); sd_ = np.einsum('nd,nd->n', Pb - q_, n_)
        pinch = (n_[:, 0] * np.sign(q_[:, 0]) < -0.6) & (np.abs(q_[:, 0]) < PINCH_X) & (sd_ < 0.004) & (d_ < 0.03) & ~rigid
        pinch |= wrap & ~rigid
        if pinch.any():
            # ... and the layers lying on it (within 4 mm in the source) with it
            dn_, jn_ = cKDTree(V0).query(V0, k=24, distance_upper_bound=0.004)
            pinch = (np.isfinite(dn_) & pinch[np.minimum(jn_, len(V0) - 1)]).any(1) & ~rigid
            hidden = hidden | pinch
            log.append('  tucked between the thighs / buttocks (not pushed out): %d verts' % int(pinch.sum()))
    # 4. collision + the port's own layer order
    src = [dict(V0=it['V0'], I=it['I'], off=off[o:o + len(it['V0'])], sn=sn[o:o + len(it['V0'])], G=Graph(it['V0'], it['I']), mat=it['mat'])
           for it, o in zip(col, offs)]
    pairs = P4.layer_pairs(src)
    skip = source_pokes(V0, I, As, hidden)
    log.append('  triangles the NIRÆ skin already pokes through (no poke test): %d' % int(skip.sum()))
    P, pairs = collide(G, I, pid, Pb, B, pairs, log, hidden=hidden, comp=comp, rigid=rigid, skip=skip)
    Pcol = P.copy()
    # every candidate state is scored (skin poking through, in mm summed over the vertices, + half a point per fold
    # edge against the source); the best one is kept: on Bonebound the rounds below traded 8 inside vertices (5 mm)
    # for 73 (22 mm) at the shorts' groin, and 13 coat folds for 126 on the chest
    from folds import fn as _fn, edge_pairs as _edge_pairs
    _pr = _edge_pairs(I, V0); _n0 = _fn(V0, I)
    _pr = _pr[np.einsum('nd,nd->n', _n0[_pr[:, 0]], _n0[_pr[:, 1]]) > 0.5]

    def fold_edges(X):
        n = _fn(X, I); return _pr[np.einsum('nd,nd->n', n[_pr[:, 0]], n[_pr[:, 1]]) < -0.5]

    def score(X):
        nd = needs2(X, I, B, GAP, hidden=hidden, skip=skip)[0]
        ins = nd > GAP + 2e-4
        fe = len(fold_edges(X))
        return dict(score=((nd - GAP) * ins).sum() * 1000 + 0.5 * fe, inside=int(ins.sum()), deepest=max(0.0, nd.max() - GAP) * 1000,
                    inside_mm=((nd - GAP) * ins).sum() * 1000, folds=fe)

    cands = [('collision', P.copy(), score(P))]
    # fast path: the fold opening that keeps the clearance, straight from the collision result. On Bonebound it gave
    # the kept state (0 inside, 14 fold edges) while the lift rounds below only made worse ones (92 s -> 31 s); the
    # rounds run only when this is not clean (anything inside the skin, or more fold edges than a few)
    sc0 = cands[0][2]
    if sc0['folds'] or sc0['inside']:
        X = untangle_clear(P, Pb, I, G, B, fold_edges, hidden=hidden, skip=skip, comp=comp, rigid=rigid)
        cands.append(('clear untangle', X, score(X)))
    fast = min(cands, key=lambda c: c[2]['score'])
    # a few shallow spots left (<= 12 verts, < 6 mm) are cleared by the repair / final clear below: no rounds either
    few = fast[2]['inside'] <= 12 and fast[2]['deepest'] < 6.0
    rounds = 0 if (few and fast[2]['folds'] <= max(120, len(I) // 1000)) else int(os.environ.get('LP_ROUNDS', '3'))
    if not rounds: log.append('  fast path clean: the lift rounds are skipped')
    # lift and fold opening alternate; the last word is the fold opening (no folds), what it leaves is measured
    for rnd in range(rounds):
        # layer order in the rounds' lift: gloves / slippers only (the glove-under-fur cuffs flipped without it); on
        # the hoodie it pulled an armpit fur vertex 13 mm into the skin (v31), v30 had no pairs here and is clean
        P = lift2(P, I, B, log, hidden=hidden, comp=comp, rigid=rigid, skip=skip, pairs=pairs if slot in PART else None, pid=pid)
        Pl_ = P
        P, f0, f1 = untangle_cloth(Pl_, Pb, I, V0, G, phase1=False, new_only=True)
        if f1:      # folds the displacement relaxation cannot open: also smooth the positions there (2 rings, 40 its)
            P, f0, f1 = untangle_cloth(Pl_, Pb, I, V0, G, phase1=True, new_only=True)
            log.append('  round %d: folds left by the relaxation -> position smoothing too' % rnd)
        need, _, _, sdv = needs2(P, I, B, GAP, hidden=hidden, skip=skip)
        inside = (need > GAP + 2e-4)
        log.append('  round %d: lift, then folds %d -> %d; max need %.2f mm, inside the skin %d verts (deepest %.2f mm)' % (
            rnd, f0, f1, need.max() * 1000, int(inside.sum()), max(0.0, (need.max() - GAP)) * 1000))
        cands.append(('round %d' % rnd, P.copy(), score(P)))
        if f0 == 0 and need.max() < 2e-4: break
    # fold opening that keeps the clearance: from the best state so far, small smoothing steps of the move around the
    # folds (from the glue result) alternate with pushing whatever went into the skin straight back out
    best = min(cands, key=lambda c: c[2]['score'])
    if rounds and best[0] != 'clear untangle' and (best[2]['folds'] or best[2]['inside']):
        X = untangle_clear(best[1], Pb, I, G, B, fold_edges, hidden=hidden, skip=skip, comp=comp, rigid=rigid)
        cands.append(('clear untangle (rounds)', X, score(X)))
    for nm, _, sc in cands:
        log.append('  state %-14s score %7.1f: inside %d verts (deepest %.1f mm, sum %.0f mm), fold edges %d' % (nm, sc['score'], sc['inside'], sc['deepest'], sc['inside_mm'], sc['folds']))
    best = min(cands, key=lambda c: c[2]['score'])
    # automatic repair (crumples, pulled-apart details: the move there replaced by its smooth version) and a final
    # clear against the skin; each kept only when the score gets better
    if os.environ.get('LP_REPAIR', '1') == '1':
        X = repair_crumples(best[1], V0, G, rigid | (hidden if hidden is not None else False), log)
        if X is not None:
            X = lift2(X, I, B, log, hidden=hidden, comp=comp, rigid=rigid, skip=skip)
            cands.append(('repaired', X, score(X)))
            log.append('  state %-14s score %7.1f: inside %d verts (deepest %.1f mm, sum %.0f mm), fold edges %d' % (
                'repaired', cands[-1][2]['score'], cands[-1][2]['inside'], cands[-1][2]['deepest'], cands[-1][2]['inside_mm'], cands[-1][2]['folds']))
        b2 = min(cands, key=lambda c: c[2]['score'])
        if b2[2]['inside']:
            X = lift2(b2[1], I, B, log, iters=8, hidden=hidden, comp=comp, rigid=rigid, skip=skip)
            sc_ = score(X)
            if sc_['folds'] > b2[2]['folds']:
                X2, f0_, f1_ = untangle_cloth(X, Pb, I, V0, G, phase1=False, new_only=True); sc2 = score(X2)
                if sc2['score'] < sc_['score']: X, sc_ = X2, sc2
            cands.append(('final clear', X, sc_))
            log.append('  state %-14s score %7.1f: inside %d verts (deepest %.1f mm, sum %.0f mm), fold edges %d' % (
                'final clear', sc_['score'], sc_['inside'], sc_['deepest'], sc_['inside_mm'], sc_['folds']))
    best = min(cands, key=lambda c: c[2]['score'])
    log.append('  kept: %s' % best[0])
    P = best[1]
    qual = dict(state=best[0], inside=best[2]['inside'], deepest_mm=round(best[2]['deepest'], 1), folds=best[2]['folds'])
    if os.environ.get('LP_DUMP'):
        np.savez(os.environ['LP_DUMP'], V0=V0, I=I, pid=pid, Pl=Pl, Pa=Pa, Pglue=Pglue, Pcol=Pcol, P=P, BP=B.P, BT=B.T, AP=A.P, AT=A.T, X2=X2, over=over_hole, dist=dist, off=off, Qs=Qs, Qn=Qn, trust=trust, ag=ag, wrap=wrap, hidden=hidden, Pb0=tgt)
    # corners that coincide in the source are one node: the same position (the position smoothing of a stubborn fold
    # moved a few by 0.4 mm apart)
    P = G.avg(P)[G.key]
    # 5. normals, tangents, weights (one set per welded node)
    N1, T1 = frames(G, V0, P, N0, T0); N1 = unit(N1); T1 = unit(T1)
    F, fnames, tt = P4.body_weights(P, Y, names, Wc)
    if KEEP_EXTRA:
        # cloth rigged to the outfit's own physics bones (chains on an extra skeleton that is ported too) keeps its
        # source rig exactly: no body weights, no body jiggle mixed into a swinging chain
        ek = [names.index(b_) for b_ in KEEP_EXTRA if b_ in names]
        if ek:
            own = Wc[:, ek].sum(1) > 0.01
            if own.any():
                Fo = np.zeros((int(own.sum()), len(fnames))); Fo[:, [fnames.index(n_) for n_ in names]] = Wc[own]
                F[own] = Fo / np.maximum(Fo.sum(1, keepdims=True), 1e-9)
                log.append('  own physics bones kept on %d verts' % int(own.sum()))
    F = G.avg(F)[G.key]
    for k, it in enumerate(col):
        s_ = slice(offs[k], offs[k + 1])
        it.update(P=P[s_], N1=N1[s_], T1=T1[s_], F=F[s_], fnames=fnames, dist=dist[s_], off=off[s_], sn=sn[s_], Pl=Pl[s_], Pglue=Pglue[s_], ag=ag[s_], Pcol=Pcol[s_], rigid=rigid[s_])
    # shells: their base's move (rebuilt exactly from the base afterwards), same normals / weights
    for it in items:
        if not it['shell']: continue
        stem = re.sub(r'\d\.mtrl$', '.mtrl', it['mat'])
        cand = [b for b in col if b['slot'] == it['slot'] and b['mat'] == stem and b['mi'] < it['mi'] and len(b['V0']) == len(it['V0'])]
        assert cand, 'no base for shell %s' % it['mat']
        b = max(cand, key=lambda b: b['mi'])
        it.update(P=it['V0'] + (b['P'] - b['V0']), N1=b['N1'], T1=b['T1'], F=b['F'], fnames=b['fnames'], Pl=b['Pl'], Pglue=b['Pglue'], dist=b['dist'], off=b['off'], sn=b['sn'], ag=b['ag'], Pcol=b['Pcol'], rigid=b['rigid'])
    bb = {}
    for f in (FLUX['top'], FLUX['dwn'], MB.FLUXD + 'base_c1201_glv.mdl', MB.FLUXD + 'base_c1201_sho.mdl'):
        bb.update(bonebbox_map(read(f)))
    import finalize3_shim as FB
    reps = {}
    for s_, o_ in zip(slots, outs):
        meshes = flux_pieces(s_) + [cloth_mesh(it) for it in items if it['slot'] == s_]
        Mo = copy.copy(Ms[s_]); Mo['meshes'] = meshes; Mo['attrs'] = []; Mo['mats'] = []; Mo['bones'] = []
        Mo['bonebbox_by_name'] = bb
        FB.fix_bbox(Mo)
        Pall = np.concatenate([attr(mm, 0)[0][:, :3].astype(float) for mm in meshes if mm['nv']])
        mh = list(Mo['mh']); mh[0] = float(np.linalg.norm(Pall, axis=1).max()); Mo['mh'] = mh
        vb = sum(len(s) for mm in meshes for s in mm['streams'])
        q_ = dict(qual)
        if len(slots) > 1:                                 # this slot's own share of the problems
            k_ = np.concatenate([np.full(len(it['V0']), it['slot'] == s_) for it in col])
            nd_ = needs2(P, I, B, GAP, hidden=hidden, skip=skip)[0]; ins_ = (nd_ > GAP + 2e-4) & k_
            fe_ = fold_edges(P); fk_ = k_[I[fe_[:, 0], 0]] if len(fe_) else np.zeros(0, bool)
            q_.update(inside=int(ins_.sum()), deepest_mm=round(max(0.0, (nd_[k_].max() - GAP) * 1000), 1), folds=int(fk_.sum()))
        rep = dict(vb_mb=round(vb / 2 ** 20, 2), meshes=len(meshes), max_nv=max(mm['nv'] for mm in meshes),
                   max_table=max(len(mm['table']) for mm in meshes), attrs=sorted({a for mm in meshes for s in mm['subs'] for a in s['attr']}),
                   bones=sorted({b for mm in meshes for b in mm['table']}), quality=q_)
        assert vb < 15.5 * 2 ** 20 and rep['max_table'] <= 64 and len(rep['attrs']) <= 32
        write(Mo, o_)
        reps[s_] = rep
    return (reps if multi else reps[slot]), items, Y


def _expand(F, names, allnames):
    out = np.zeros((len(F), len(allnames)))
    out[:, [allnames.index(n) for n in names]] = F
    return out


def untangle_clear(P, Pref, I, G, B, fold_edges, hidden=None, skip=None, comp=None, rigid=None, steps=80, every=4):
    """open folds without giving up the clearance: the move from Pref is smoothed around the fold edges (2 rings, growing
    slowly), and every few steps the vertices that went into the skin are pushed straight back out along the averaged
    skin normal; the state with the fewest problems (inside mm + half a point per fold edge) is returned"""
    D = G.avg(P - Pref); R0 = G.avg(Pref)
    def cur():
        return R0[G.key] + D[G.key]
    def sc(X):
        nd = needs2(X, I, B, GAP, hidden=hidden, skip=skip)[0]; ins = nd > GAP + 2e-4
        return ((nd - GAP) * ins).sum() * 1000 + 0.5 * len(fold_edges(X))
    X = cur(); best = (sc(X), X)
    for it in range(steps):
        fe = fold_edges(X)
        if len(fe):
            reg = np.zeros(G.n, bool); reg[np.unique(G.key[I[np.unique(fe.ravel())]])] = True
            for _ in range(2 + it // 20): reg |= (G.A @ reg.astype(float)) > 0
            D[reg] = 0.5 * D[reg] + 0.5 * (G.W @ D)[reg]
            X = cur()
        if it % every == every - 1 or not len(fe):
            need, n, _, _ = needs2(X, I, B, GAP, hidden=hidden, skip=skip)
            if need.max() > 2e-5:
                L = np.where(need > 0, need, 0.0)
                L, n = rigidify(L, n, comp, rigid)
                Lw = np.zeros(G.n); np.maximum.at(Lw, G.key, L)
                D += Lw[:, None] * unit(G.avg(n))
                X = cur()
            s_ = sc(X)
            if s_ < best[0]: best = (s_, X)
            if s_ == 0: break
    return best[1]


def untangle_cloth(P, Pb, T, V0, G, max_it=300, phase0=True, count_only=False, phase1=True, new_only=False):
    """open folds (a sheet folded back on itself: two faces < 60 deg apart in the source, > 120 deg now) by relaxing
    the move from Pb around them; folds already in Pb are opened by smoothing the positions there"""
    from folds import fn, edge_pairs
    pr = edge_pairs(T, V0)
    n0 = fn(V0, T); cand = np.einsum('nd,nd->n', n0[pr[:, 0]], n0[pr[:, 1]]) > 0.5; pr = pr[cand]
    if new_only:                          # folds already present in Pb are not this step's to open
        nb_ = fn(Pb, T); pr = pr[np.einsum('nd,nd->n', nb_[pr[:, 0]], nb_[pr[:, 1]]) >= -0.5]
    def bad(X):
        n = fn(X, T); b = np.einsum('nd,nd->n', n[pr[:, 0]], n[pr[:, 1]]) < -0.5
        return np.unique(pr[b].ravel())
    f = bad(P); nf0 = len(f)
    if count_only: return nf0
    if not nf0: return P, 0, 0
    D = G.avg(P - Pb); B0 = G.avg(Pb)
    phases = ((0,) if phase0 else ()) + ((1,) if phase1 else ())
    for phase in phases:
        for it in range(max_it if phase == 0 else 40):
            X = B0[G.key] + D[G.key]; f = bad(X)
            if not len(f): return X, nf0, 0
            reg = np.zeros(G.n, bool); reg[np.unique(G.key[T[f]])] = True
            for _ in range((1 + it // 40) if phase == 0 else 2): reg |= (G.A @ reg.astype(float)) > 0
            if phase == 0:
                D[reg] = 0.5 * D[reg] + 0.5 * (G.W @ D)[reg]
            else:
                W0 = B0 + D; D[reg] = (0.5 * W0[reg] + 0.5 * (G.W @ W0)[reg]) - B0[reg]
    X = B0[G.key] + D[G.key]
    return X, nf0, len(bad(X))


def cloth_mesh(it):
    m = it['m']; data = dict(it['data']); nv = len(it['u'])
    t, a = data[(0, 0)]; a = a.copy(); a[:, :3] = it['P']; data[(0, 0)] = (t, a)
    t, a = data[(3, 0)]; a = a.copy(); a[:, :3] = it['N1']; data[(3, 0)] = (t, a)
    t, a = data[(6, 0)]; a = a.copy(); a[:, :3] = np.clip(np.round((it['T1'] + 1) / 2 * 255), 0, 255).astype(np.uint8); data[(6, 0)] = (t, a)
    q8, order, tbl = quant(it['F'], it['fnames'])
    data[(1, 0)] = (data[(1, 0)][0], q8[:, :data[(1, 0)][1].shape[1]].copy())
    data[(2, 0)] = (data[(2, 0)][0], order[:, :data[(2, 0)][1].shape[1]].copy())
    mm = dict(m); mm['nv'] = nv; mm['streams'] = vtx.encode_into(m, data, nv); mm['table'] = tbl; mm['shapes'] = {}
    # triangles grouped by their attribute set -> sub-meshes
    keys = sorted(set(it['tattr'])); I = it['I']; ta = np.array([keys.index(k) for k in it['tattr']])
    order_t = np.argsort(ta, kind='stable'); I = I[order_t]; ta = ta[order_t]
    subs = []; off = 0
    for k, key in enumerate(keys):
        c = int((ta == k).sum()) * 3
        subs.append({'off': off, 'cnt': c, 'attr': list(key), 'sbm': list(range(len(tbl)))}); off += c
    mm['idx'] = I.astype(np.uint16).tobytes(); mm['ic'] = I.size; mm['subs'] = subs
    return mm


def flux_pieces(slot):
    """the FluxHD2 body pieces of this slot: skin (+ armpit layer) - with the SFW body also the smallclothes (cover the
    skin's holes; their material given by its full path, a relative name would resolve under this outfit's item).
    The full body's pubic hair layer (fpl) stays out: the trousers cover it"""
    F = read(FLUX[slot]); out = []
    for m in F['meshes']:
        if not m['nv'] or 'fluxhd_fpl' in m['mat']: continue
        mm = dict(m)
        if mm['mat'] in SMALLCLOTHES_FULL: mm['mat'] = SMALLCLOTHES_FULL[mm['mat']]
        out.append(mm)
    return out


if __name__ == '__main__':
    slot, mapf, out = sys.argv[1:4]
    log = []
    rep, items, Y = run(slot, mapf, out, log)
    print('\n'.join(log))
    np.savez_compressed(out.replace('.mdl', '_dbg.npz'), **{('%s_%d' % (k, i)): it[k] for i, it in enumerate(items) for k in ('V0', 'Pl', 'Pglue', 'Pcol', 'P', 'dist', 'off', 'ag', 'rigid') if k in it},
                        mats=np.array([it['mat'] for it in items]))
    print(json.dumps(rep))
    print('wrote', out)
