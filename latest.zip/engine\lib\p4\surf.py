import sys, os
import numpy as np, json
from mdlio import read, write, bonebbox_map
from lib import attr
from scipy.spatial import cKDTree
from unfold import _closest_on_tris
U=os.environ.get('LP_MODS', '/mnt/user-data/uploads/FFXIVMods/')
CB=os.environ.get('LP_NIRAE_STANDALONE', U+'NIRÆ Body/files/standalone/')
# NIRÆ 0.9.102: one top per build, one dwn per build AND hips (the hips are separate files now, no shpx_cb_hips_* keys)
# NIRÆ 0.9.120 (2026-11-05): new vulva (own mesh 4, Open / Closed by attribute), Rue+ waist belly option
# (shpx_cb_waist_r_full), squish tops -> tops curvy v70 / others v64, dwn v95 (thick v96)
# NIRÆ 0.9.124-0.9.128 (2026-11-06): dwn v97 every build x hips (Open vulva rows; 0.9.128 changed only squish tops)
DWNV={'curvy':97,'thick':97,'athletic':97,'slim':97}
BUILDS={b:('c0201e0000_top_crimson_%s_v%d.mdl'%(b,70 if b=='curvy' else 64),'c0201e0000_dwn_crimson_%s_medium_v%d.mdl'%(b,DWNV[b])) for b in ('curvy','thick','athletic','slim')}
HIPSF={b:{h:'c0201e0000_dwn_crimson_%s_%s_v%d.mdl'%(b,h,DWNV[b]) for h in ('small','medium','large')} for b in BUILDS}
if os.environ.get('LP_NIRAE_BUILDS'):
    _NB=json.loads(os.environ['LP_NIRAE_BUILDS']); BUILDS={b:tuple(v) for b,v in _NB['builds'].items()}; HIPSF=_NB['hips']
# the previous body (0.9.112: hips rework -> tops curvy v68 / others v63, dwn v67), for refitting existing ports (refit.py)
BUILDS_OLD={'curvy':('c0201e0000_top_crimson_curvy_v68.mdl','c0201e0000_dwn_crimson_curvy_medium_v67.mdl'),
        'thick':('c0201e0000_top_crimson_thick_v63.mdl','c0201e0000_dwn_crimson_thick_medium_v67.mdl'),
        'athletic':('c0201e0000_top_crimson_athletic_v63.mdl','c0201e0000_dwn_crimson_athletic_medium_v67.mdl'),
        'slim':('c0201e0000_top_crimson_slim_v63.mdl','c0201e0000_dwn_crimson_slim_medium_v67.mdl')}
HIPSF_OLD={b:{h:'c0201e0000_dwn_crimson_%s_%s_v67.mdl'%(b,h) for h in ('small','medium','large')} for b in BUILDS}
import os as _os
if _os.environ.get('NIRAE_OLD') == '0.9.104':      # the OH ports (Sleepy Panda / Bonebound, port4n) were fitted to 0.9.104
    BUILDS_OLD={b:('c0201e0000_top_crimson_%s_v%d.mdl'%(b,64 if b=='curvy' else 62),'c0201e0000_dwn_crimson_%s_medium_v66.mdl'%b) for b in ('curvy','thick','athletic','slim')}
    HIPSF_OLD={b:{h:'c0201e0000_dwn_crimson_%s_%s_v66.mdl'%(b,h) for h in ('small','medium','large')} for b in BUILDS}
OUT=U+"Bloodrake [NeoLithe]/model/"
AUTH={'xs':OUT+"xs/chara/equipment/e6125/model/c0201e6125_top.mdl",'s':OUT+"s/chara/equipment/e6125/model/c0201e6125_top.mdl"}
NEOTOP={'xs':U+"Neolithe [ALL IN ONE]/DEFAULT CHEST - SmallClothes/SFW XS.mdl",'s':U+"Neolithe [ALL IN ONE]/DEFAULT CHEST - SmallClothes/SFW S.mdl"}
NEOLEGS=U+"Neolithe [ALL IN ONE]/DEFAULT LEGS - SmallClothes/SFW Medium.mdl"
CH=['flat','small','champs','smallperky','medium','large','saggy','perky','earth','mireya']
CGOF={'flat':'s','small':'s','champs':'s','smallperky':'s','medium':'s','earth':'s','large':'l','saggy':'l','perky':'l','mireya':'l'}   # Crimson chest groups (atrx_cb_cg_*)
def optsel(ch,be,hi,nip='soft'):
    """cloth attribute selection for a body option: belly 'vnone' = None · vanilla waist (atrx_cb_belly_none + atrx_cb_waist_v),
    'rfull' = Full · Rue+ waist (atrx_cb_belly_full + atrx_cb_waist_r), every other belly = waist std (refit5 waist variants)"""
    return dict(chest=ch,belly={'vnone':'none','rfull':'full'}.get(be,be),hips=hi,waist={'vnone':'v','rfull':'r'}.get(be,'std'),nip=nip,cg=CGOF.get(ch))
def is_skin(m): return 'c0201b0001' in m['mat'] or 'c0101b0001' in m['mat']
def tris(m,subs=None,shapes=()):
    idx=np.frombuffer(m['idx'],np.uint16).astype(int).copy()
    for sh in shapes:
        for io,rv in m['shapes'].get(sh,[]): idx[io]=rv
    ss=m['subs'] if subs is None else subs
    return np.concatenate([idx[s['off']:s['off']+s['cnt']] for s in ss if s['cnt']]).reshape(-1,3)
def vnorm(P,T):
    fn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]])
    key=np.unique(P.round(5),axis=0,return_inverse=True)[1].ravel(); NW=np.zeros((key.max()+1,3))
    for i in range(3): np.add.at(NW,key[T[:,i]],fn)
    N=NW[key]; return N/np.maximum(np.linalg.norm(N,axis=1),1e-12)[:,None]
def compact(P,T,*extra):
    u,inv=np.unique(T,return_inverse=True); return (P[u],inv.reshape(-1,3))+tuple(e[u] for e in extra)
class Surf:
    """a triangle surface; part[] tags which body piece each vertex comes from (0 torso/chest, 1 legs)"""
    def __init__(s,P,T,UV,part,W=None,names=None):
        s.P=P.astype(float); s.T=T; s.UV=UV; s.part=part; s.N=vnorm(s.P,T); s.W=W; s.names=names
        s.C=cKDTree(s.P[T].mean(1))
    def closest(s,Q,k=16):
        _,cand=s.C.query(Q,k=k); best=np.full(len(Q),np.inf); bt=np.zeros(len(Q),int); bq=Q.copy()
        P,T=s.P,s.T
        for j in range(k):
            t=cand[:,j]; c=_closest_on_tris(Q,P[T[t,0]],P[T[t,1]],P[T[t,2]]); d=np.linalg.norm(c-Q,axis=1)
            b=d<best; best[b]=d[b]; bt[b]=t[b]; bq[b]=c[b]
        return bt,bary(bq,P[T[bt]]),bq,best
    def at(s,t,w,X=None):
        X=s.P if X is None else X; return np.einsum('ni,ni...->n...',w,X[s.T[t]])
    def nrm(s,t,w):
        n=s.at(t,w,s.N); return n/np.maximum(np.linalg.norm(n,axis=1),1e-12)[:,None]
def bary(q,tri):
    a,b,c=tri[:,0],tri[:,1],tri[:,2]; v0,v1,v2=b-a,c-a,q-a
    d00=(v0*v0).sum(1);d01=(v0*v1).sum(1);d11=(v1*v1).sum(1);d20=(v2*v0).sum(1);d21=(v2*v1).sum(1)
    den=np.maximum(d00*d11-d01*d01,1e-24); y=(d11*d20-d01*d21)/den; z=(d00*d21-d01*d20)/den
    return np.stack([1-y-z,y,z],1)
def dense_w(m):
    A=np.frombuffer(m['streams'][0],np.uint8).reshape(m['nv'],-1)
    # blend weights at byte 12 (unit 1), indices at 20 (unit 2) for 28-byte stride; generic via decl
    from lib import el
    e={x[3]:x for x in el(m)}; s,o,t,_=e[1]; s2,o2,t2,_=e[2]
    Ab=np.frombuffer(m['streams'][s],np.uint8).reshape(m['nv'],-1); Ai=np.frombuffer(m['streams'][s2],np.uint8).reshape(m['nv'],-1)
    W=Ab[:,o:o+4].astype(float)/255 if t==8 else Ab[:,o:o+8].astype(float)/255
    I=Ai[:,o2:o2+W.shape[1]].astype(int)
    D=np.zeros((m['nv'],len(m['table'])))
    for k in range(W.shape[1]): np.add.at(D,(np.arange(m['nv']),I[:,k]),W[:,k])
    return D
def merge_w(parts):
    names=sorted({n for D,tab in parts for n in tab}); out=[]
    for D,tab in parts:
        F=np.zeros((len(D),len(names))); F[:,[names.index(n) for n in tab]]=D; out.append(F)
    return np.concatenate(out),names

PARTID={'feet':2,'hands':4}
def extra_meshes(spec_list,with_w=True):
    """extra body pieces (feet, hands) from other model files: [{path, part}] -> list of (P,T,UV,part,W)"""
    out=[]
    for sp in spec_list or []:
        M=read(sp['path'])
        for m in M['meshes']:
            if m['mat']!='/mt_c0201b0001_bibo.mtrl' or m['nv']==0: continue
            P=attr(m,0)[0][:,:3].astype(float); T=tris(m); UV=attr(m,4)[0][:,:2].copy(); UV-=np.floor(UV.mean(0))
            u,inv=np.unique(T,return_inverse=True); P=P[u]; UV=UV[u]; T=inv.reshape(-1,3)
            part=PARTID[sp['part']]+(P[:,0]<0).astype(int)     # left/right pieces share mirrored UVs: keep them apart
            # triangles crossing sides (none for feet/hands) keep the side of their first vertex
            W=(dense_w(m)[u],m['table']) if with_w else None
            out.append((P,T,UV,part,W))
    return out
_DWN={}
def _hips_disp(dm,dh):
    """per vertex of every bibo mesh of the medium dwn: displacement to the same UV spot of the other hips file"""
    out={}
    for mi,(a,b) in enumerate(zip(dm['meshes'],dh['meshes'])):
        if a['mat']!='/mt_c0201b0001_bibo.mtrl': continue
        assert b['mat']==a['mat']
        PA=attr(a,0)[0][:,:3].astype(float); UA=attr(a,4)[0][:,:2].astype(float)
        PB=attr(b,0)[0][:,:3].astype(float); UB=attr(b,4)[0][:,:2].astype(float); TB=tris(b)
        C=UB[TB].mean(1); _,cand=cKDTree(C).query(UA,k=16)
        best=np.full(len(PA),np.inf); Q=PA.copy(); q3=np.c_[UA,np.zeros(len(UA))]
        for j in range(cand.shape[1]):
            t=cand[:,j]; tr=np.dstack([UB[TB[t]],np.zeros((len(t),3,1))])
            c=_closest_on_tris(q3,tr[:,0],tr[:,1],tr[:,2]); du=np.linalg.norm(c-q3,axis=1)
            w=np.clip(bary(c,tr),0,1); w/=w.sum(1,keepdims=True); X=np.einsum('ni,nij->nj',w,PB[TB[t]])
            score=du*50+np.linalg.norm(X-PA,axis=1)      # same UV first, then the 3D-closest of overlapping UV copies
            bt=score<best; best[bt]=score[bt]; Q[bt]=X[bt]
        D=Q-PA; idx=np.frombuffer(a['idx'],np.uint16).astype(int)
        for sh in a['shapes'].values():          # shape replacement vertices move with the vertex they replace
            for io,rv in sh: D[rv]=D[idx[io]]
        out[mi]=D
    return out
def read_dwn(build):
    """the medium-hips dwn of a build, carrying '_hipsD' {hips: {mesh index: per-vertex displacement}}"""
    if build not in _DWN:
        d=read(CB+HIPSF[build]['medium']); d['_hipsD']={'medium':None}
        for h in ('small','large'): d['_hipsD'][h]=_hips_disp(d,read(CB+HIPSF[build][h]))
        _DWN[build]=d
    return _DWN[build]
_DWNX={}
def read_dwn_exact(build,hips):
    """the build's own legs file of that hips option, as the game loads it (its own belly / waist shapes); our_surface_from
    adds no hips displacement to it. read_dwn's medium file + per-vertex hips displacement is off by up to 5 mm at the
    waist for the vanilla-waist shape on Small / Large hips (the shape's vertices do not get the hips move)"""
    if (build,hips) not in _DWNX:
        d=read(CB+HIPSF[build][hips]); d['_hipsD']={h:([0.0]*len(d['meshes']) if h!='medium' else None) for h in ('small','medium','large')}
        _DWNX[(build,hips)]=d
    return _DWNX[(build,hips)]
VULVA=None   # 'closed' / 'open': only that vulva variant of the legs skin goes into the surface (port4 fits against Closed)
def is_inner(m):
    """NIRÆ 0.9.120+ legs: the inner vulva (canal) mesh - every sub-mesh is a vulva variant and ~80 % of it lies inside
    the body (down to 23 mm). Never part of the fitting / collision surface: crotch cloth pushed out of its walls ended
    up hanging 3 cm under the crotch (Gothkini panties). The model still carries it (body pieces are copied as they are)"""
    subs=[s for s in m['subs'] if s['cnt']]
    return bool(subs) and all(any(a.startswith('atrx_cb_vulva_') for a in s['attr']) for s in subs)
def our_surface(build,chest,belly='full',hips='medium',with_w=False):
    top,dwn=read(CB+BUILDS[build][0]),read_dwn(build)
    return our_surface_from(top,dwn,chest,belly,hips,with_w)
def our_surface_from(top,dwn,chest,belly='full',hips='medium',with_w=False,nip='soft'):
    # belly 'vnone' = NIRÆ 'None · vanilla waist' (cloth: atrx_cb_belly_none, body: shpx_cb_waist_v_none)
    # belly 'rfull' = NIRÆ 'Full · Rue+ waist' (0.9.120; cloth: atrx_cb_belly_full, body: shpx_cb_waist_r_full)
    shp=[x for x in ('shpx_cb_waist_v_none' if belly=='vnone' else ('shpx_cb_waist_r_full' if belly=='rfull' else 'shpx_cb_belly_'+belly),'shpx_cb_hips_'+hips)]
    Ps=[];Ts=[];UVs=[];parts=[];Ws=[];vul=[];o=0
    for m in top['meshes']:
        if not is_skin(m) or 'b0001_bibo' not in m['mat']: continue
        at=[a for s in m['subs'] for a in s['attr'] if a.startswith('atrx_cb_chest_')]
        if at and 'atrx_cb_chest_'+chest not in at: continue
        subs=[s for s in m['subs'] if not any(a.startswith('atrx_cb_nip_') and a!='atrx_cb_nip_'+nip for a in s['attr'])]   # nipple option (soft = the fit's)
        P=attr(m,0)[0][:,:3]; T=tris(m,subs,shp); P,T,UV=compact(P,T,attr(m,4)[0][:,:2])[:3] if False else (P,T,attr(m,4)[0][:,:2])
        u,inv=np.unique(T,return_inverse=True); P=P[u]; UV=UV[u]; T=inv.reshape(-1,3)
        Ps.append(P);Ts.append(T+o);UVs.append(UV);parts.append(np.zeros(len(P),int));vul.append(np.zeros(len(P),bool))
        if with_w: Ws.append((dense_w(m)[u],m['table']))
        o+=len(P)
    for mi_,m in enumerate(dwn['meshes']):
        if m['mat']!='/mt_c0201b0001_bibo.mtrl' or is_inner(m): continue
        # VULVA (None = both variants, as before): NIRÆ 0.9.120+ legs carry the Open AND the Closed vulva as alternative
        # sub-meshes on top of each other; a fit against both glues crotch cloth into the Open variant's opening
        vs=[s for s in m['subs'] if not (VULVA and any(a.startswith('atrx_cb_vulva_') and a!='atrx_cb_vulva_'+VULVA for a in s['attr']))]
        P=attr(m,0)[0][:,:3]; T=tris(m,None if len(vs)==len(m['subs']) else vs,shp)
        UV=attr(m,4)[0][:,:2]
        if hips!='medium': P=P+dwn['_hipsD'][hips][mi_]
        vv=np.zeros(m['nv'],bool)
        for s_ in vs:
            if s_['cnt'] and any(a.startswith('atrx_cb_vulva_') for a in s_['attr']): vv[np.frombuffer(m['idx'],np.uint16).astype(int)[s_['off']:s_['off']+s_['cnt']]]=True
        u,inv=np.unique(T,return_inverse=True); P=P[u]; UV=UV[u]; T=inv.reshape(-1,3)
        Ps.append(P);Ts.append(T+o);UVs.append(UV);parts.append(np.ones(len(P),int));vul.append(vv[u])
        if with_w: Ws.append((dense_w(m)[u],m['table']))
        o+=len(P)
    for P,T,UV,part,Wx in extra_meshes(CFG.get('ours_extra') if CFG else None,with_w):
        Ps.append(P);Ts.append(T+o);UVs.append(UV);parts.append(part);vul.append(np.zeros(len(P),bool))
        if with_w: Ws.append(Wx)
        o+=len(P)
    W,names=merge_w(Ws) if with_w else (None,None)
    S_=Surf(np.concatenate(Ps),np.concatenate(Ts),np.concatenate(UVs),np.concatenate(parts),W,names); S_.vulva=np.concatenate(vul)
    return S_
CFG=None
def load_cfg(path):
    """outfit config (json): sizes {key: author outfit .mdl}, body {key: author's own top body .mdl}, legs: author legs .mdl,
    drape: [material substrings that hang like a cape], out: folder prefix, name: file stem"""
    global CFG; CFG=json.load(open(path)); return CFG

DECL8=None
def upgrade_layout(m):
    """old 4-weight vertex layout (20-byte stream 0) -> the 8-weight layout the pipeline writes (28 bytes)"""
    global DECL8
    from lib import el
    L=[x for x in el(m) if x!=(0,0,0,0)]; e={}
    for x in L: e.setdefault(x[3],x)
    if e[1][2]==17 or m['nv']==0: return m
    assert e[0][:3]==(0,0,2) and e[1][:3]==(0,12,8) and e[2][:3]==(0,16,5), el(m)
    if DECL8 is None:
        DECL8=read_dwn('curvy')['meshes'][0]['decl']
    s1=[x for x in L if x[0]==1]; s1r=[x for x in el({'decl':DECL8}) if x[0]==1 and x!=(0,0,0,0)]
    assert s1==s1r, (s1,s1r)
    A=np.frombuffer(m['streams'][0],np.uint8).reshape(m['nv'],-1); B=np.zeros((m['nv'],28),np.uint8)
    B[:,:12]=A[:,:12]; B[:,12:16]=A[:,12:16]; B[:,20:24]=A[:,16:20]
    m=dict(m); m['streams']=[B.tobytes()]+list(m['streams'][1:]); m['decl']=DECL8
    if 'strides' in m: m['strides']=[28]+list(m['strides'][1:])
    return m
def author_surface(size):
    outfit=CFG['sizes'][size] if CFG else AUTH[size]; body=CFG['body'][size] if CFG else NEOTOP[size]; legs=CFG['legs'] if CFG else NEOLEGS
    if isinstance(legs,dict): legs=legs[size]
    X=read(outfit)
    X['meshes']=[upgrade_layout(m) for m in X['meshes'] if m['nv']>0]   # authors leave empty meshes behind
    if CFG and CFG.get('author_body_npz'):
        # outfits made for another body (no Bibo author body): the outfit was first fitted onto one of OUR bodies,
        # stored as a surface (P, T, UV, part)
        z=np.load(CFG['author_body_npz'] if isinstance(CFG['author_body_npz'],str) else CFG['author_body_npz'][size])
        return X,Surf(z['P'],z['T'],z['UV'],z['part'])
    # the outfit's own skin usually has the hidden parts cut away (or is empty): use the complete author body
    sk=max([m for m in read(body)['meshes'] if 'b0001_bibo' in m['mat']],key=lambda m:m['nv'])
    P=attr(sk,0)[0][:,:3]; T=tris(sk); UV=attr(sk,4)[0][:,:2].copy(); UV-=np.floor(UV.mean(0)); u,inv=np.unique(T,return_inverse=True)
    P1,T1,UV1=P[u],inv.reshape(-1,3),UV[u]
    if legs=='split':
        # one complete author skin with torso AND legs (e.g. YAB outfits): split it by which of our UV islands
        # (torso or legs) each vertex falls in
        R=our_surface('curvy','medium'); d=[]
        for part in (0,1):
            tb=np.where(R.part[R.T[:,0]]==part)[0]; d.append(cKDTree(R.UV[R.T[tb]].mean(1)).query(UV1)[0])
        pv=(d[1]<d[0]).astype(int)
        pt=np.round(pv[T1].mean(1)).astype(int); pv=np.zeros(len(P1),int)
        for k in range(3): pv[T1[pt==1,k]]=1
        # vertices of leg triangles become part 1 (duplicate the ones shared with torso triangles)
        keep0=np.unique(T1[pt==0]); keep1=np.unique(T1[pt==1])
        r0=-np.ones(len(P1),int); r0[keep0]=np.arange(len(keep0)); r1=-np.ones(len(P1),int); r1[keep1]=np.arange(len(keep1))+len(keep0)
        P2=np.r_[P1[keep0],P1[keep1]]; UV2=np.r_[UV1[keep0],UV1[keep1]]; T2=np.r_[r0[T1[pt==0]],r1[T1[pt==1]]]
        part=np.r_[np.zeros(len(keep0),int),np.ones(len(keep1),int)]
        return X,Surf(P2,T2,UV2,part)
    L=read(legs)
    # the outfit's own skin usually has the hidden parts cut away (or is empty): use the complete author body
    sk=max([m for m in read(body)['meshes'] if 'b0001_bibo' in m['mat']],key=lambda m:m['nv'])
    P=attr(sk,0)[0][:,:3]; T=tris(sk); UV=attr(sk,4)[0][:,:2].copy(); UV-=np.floor(UV.mean(0)); u,inv=np.unique(T,return_inverse=True)
    P1,T1,UV1=P[u],inv.reshape(-1,3),UV[u]
    lm=[m for m in L['meshes'] if m['mat']=='/mt_c0201b0001_bibo.mtrl'][0]
    subs=[s for s in lm['subs'] if not any(a.startswith('atr_dv_') for a in s['attr'])]
    # the legs UVs get the same whole-unit normalisation as the top's: Bibo+ keeps V in [-1, 0], so without it every legs
    # correspondence was wrong (Rebel Rabbit's long hoodie folded up to the waist, 2750 of 6586 matches 'untrusted')
    P=attr(lm,0)[0][:,:3]; T=tris(lm,subs); UV=attr(lm,4)[0][:,:2].copy(); UV-=np.floor(UV.mean(0)); u,inv=np.unique(T,return_inverse=True)
    P2,T2,UV2=P[u],inv.reshape(-1,3)+len(P1),UV[u]
    if CFG and CFG.get('legs_match'): P2=legs_match(P2,inv.reshape(-1,3),UV2,CFG['legs_match'])
    Ps=[P1,P2];Ts=[T1,T2];UVs=[UV1,UV2];parts=[np.zeros(len(P1),int),np.ones(len(P2),int)];o=len(P1)+len(P2)
    for P,T,UV,part,_ in extra_meshes(CFG.get('author_extra') if CFG else None,False):
        Ps.append(P);Ts.append(T+o);UVs.append(UV);parts.append(part);o+=len(P)
    return X,Surf(np.concatenate(Ps),np.concatenate(Ts),np.concatenate(UVs),np.concatenate(parts))
def legs_match(P,T,UV,path):
    """the author's legs differ a little from the stock body (tweaked belly/hips): move the stock legs onto the skin
    shipped inside the outfit where it exists (same UV, close), and fill the rest of the displacement smoothly"""
    M=read(path); m=max([m for m in M['meshes'] if m['mat']=='/mt_c0201b0001_bibo.mtrl'],key=lambda m:m['nv'])
    Q=attr(m,0)[0][:,:3].astype(float); UQ=attr(m,4)[0][:,:2].astype(float); UQ-=np.floor(UQ.mean(0))
    d,i=cKDTree(UQ).query(UV); d3=np.linalg.norm(Q[i]-P,axis=1); known=(d<2e-4)&(d3<0.012)
    D=np.where(known[:,None],Q[i]-P,0.0)
    import scipy.sparse as sp_
    r=np.r_[T[:,0],T[:,1],T[:,2],T[:,1],T[:,2],T[:,0]]; c=np.r_[T[:,1],T[:,2],T[:,0],T[:,0],T[:,1],T[:,2]]
    A=sp_.coo_matrix((np.ones(len(r)),(r,c)),shape=(len(P),len(P))).tocsr(); A.data[:]=1
    deg=np.maximum(np.asarray(A.sum(1)).ravel(),1)
    for _ in range(300):
        Dn=(A@D)/deg[:,None]; D=np.where(known[:,None],D,Dn)
    return P+D
def uv_map(A,B):
    """for each vertex of A: (triangle, bary) on B with the same UV (same body piece). exact UV interpolation"""
    tri=np.zeros(len(A.P),int); W=np.zeros((len(A.P),3)); err=np.zeros(len(A.P))
    for part in np.unique(A.part):
        ia=np.where(A.part==part)[0]; tb=np.where(B.part[B.T[:,0]]==part)[0]
        if len(tb)==0: continue
        UVt=B.UV[B.T[tb]]; C=UVt.mean(1); tree=cKDTree(C)
        _,cand=tree.query(A.UV[ia],k=24)
        best=np.full(len(ia),np.inf); bt=np.zeros(len(ia),int); bw=np.zeros((len(ia),3))
        q3=np.c_[A.UV[ia],np.zeros(len(ia))]
        for j in range(cand.shape[1]):
            t=cand[:,j]; tr=np.dstack([UVt[t],np.zeros((len(ia),3,1))])
            c=_closest_on_tris(q3,tr[:,0],tr[:,1],tr[:,2]); d=np.linalg.norm(c-q3,axis=1)
            b=d<best-1e-12; best[b]=d[b]; bt[b]=t[b]; bw[b]=bary(c[b],tr[b])
        tri[ia]=tb[bt]; W[ia]=np.clip(bw,0,1)/np.clip(bw,0,1).sum(1,keepdims=True); err[ia]=best
    return tri,W,err

def our_rest_and_shapes(top,dwn,chest,with_w=True):
    """rest surface (belly full, hips medium) + displacement of every rest vertex for each body shape option"""
    B=our_surface_from(top,dwn,chest,with_w=with_w)
    D={k:np.zeros_like(B.P) for k in ('belly_none','belly_soft','hips_small','hips_large','waist_v_none')}
    o=0
    for mdl,isleg in ((top,0),(dwn,1)):
        for mi_,m in enumerate(mdl['meshes']):
            if not is_skin(m) or 'b0001_bibo' not in m['mat']: continue
            if isleg and (m['mat']!='/mt_c0201b0001_bibo.mtrl' or is_inner(m)): continue
            if not isleg:
                at=[a for s_ in m['subs'] for a in s_['attr'] if a.startswith('atrx_cb_chest_')]
                if at and 'atrx_cb_chest_'+chest not in at: continue
                subs=[s_ for s_ in m['subs'] if 'atrx_cb_nip_inv' not in s_['attr']]
            else: subs=[s_ for s_ in m['subs'] if not (VULVA and any(a.startswith('atrx_cb_vulva_') and a!='atrx_cb_vulva_'+VULVA for a in s_['attr']))]
            P=attr(m,0)[0][:,:3]; idx=np.frombuffer(m['idx'],np.uint16).astype(int)
            T=tris(m,subs); u=np.unique(T); pos={v:i for i,v in enumerate(u)}
            for k in D:
                if isleg and k.startswith('hips_'):
                    D[k][o:o+len(u)]=mdl['_hipsD'][k[5:]][mi_][u]; continue
                for io,rv in m['shapes'].get('shpx_cb_'+k,[]):
                    ov=idx[io]
                    if ov in pos: D[k][o+pos[ov]]=P[rv]-P[ov]
            o+=len(u)
    for P_,T_,UV_,part_,W_ in extra_meshes(CFG.get('ours_extra') if CFG else None,False): o+=len(P_)
    assert o==len(B.P)
    if not (CFG or {}).get('no_waist_envelope'):
        # NIRÆ "None · vanilla waist" shows the belly-none cloth (atrx_cb_belly_none) over the waist_v_none body, which
        # bulges up to ~1.2 cm further out at the waist than belly none: the belly-none cloth clears both (envelope).
        # (a cloth shape key for it would need ~50k shape values: over the per-model limit)
        out_=np.einsum('nd,nd->n',D['waist_v_none']-D['belly_none'],B.N)
        D['belly_none']=D['belly_none']+np.clip(out_,0,None)[:,None]*B.N
    return B,D
