"""Smooth subdivision of the game's own (vanilla) gear before it is fitted: vanilla cloth has 4-8 cm triangles, which
look faceted on NIRÆ's detailed body. Each level splits every triangle in four (Loop subdivision on the welded mesh):
interior edges and vertices are rounded, hems / openings (boundary edges) and hard creases (dihedral > `crease` deg)
stay sharp. New vertices take the mean UV / normal / colour of their edge and the merged bone weights of both ends.
Works on the 8-weight layout (surf.upgrade_layout); the gear's own shape keys are dropped (port4 drops them anyway)."""
import numpy as np
from scipy.spatial import cKDTree


def _weld(P, tol=2e-5):
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    pr = cKDTree(P).query_pairs(tol, output_type='ndarray')
    A = coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(P), len(P)))
    return connected_components(A, directed=False)[1]


def _merge_w(W1, I1, W2, I2):
    """two 8-slot weight sets (bytes) -> their mean, best 8 bones, summing to 255"""
    n = len(W1); W = np.concatenate([W1, W2], 1).astype(float) / 2; I = np.concatenate([I1, I2], 1).astype(int)
    out_w = np.zeros((n, 8)); out_i = np.zeros((n, 8), int)
    for r in range(n):
        acc = {}
        for w, i in zip(W[r], I[r]):
            if w > 0: acc[i] = acc.get(i, 0) + w
        top = sorted(acc.items(), key=lambda kv: -kv[1])[:8]
        for k, (i, w) in enumerate(top): out_i[r, k] = i; out_w[r, k] = w
    s = out_w.sum(1, keepdims=True); out_w = out_w / np.maximum(s, 1e-9) * 255
    q = np.floor(out_w).astype(int); rem = 255 - q.sum(1)
    q[np.arange(n), 0] += np.where(s[:, 0] > 0, rem, 0)
    return q.astype(np.uint8), out_i.astype(np.uint8)


def _level(m, crease):
    nv = m['nv']; S0 = np.frombuffer(m['streams'][0], np.uint8).reshape(nv, 28); S1 = np.frombuffer(m['streams'][1], np.uint8).reshape(nv, 44)
    P = S0[:, 0:12].copy().view(np.float32).astype(float)
    F = np.frombuffer(m['idx'], np.uint16).astype(int).reshape(-1, 3)
    key = _weld(P); nk = key.max() + 1
    Pk = np.zeros((nk, 3)); np.add.at(Pk, key, P); Pk /= np.bincount(key, minlength=nk)[:, None]
    K = key[F]
    # raw edges (attributes) and welded edges (geometry)
    E = np.sort(np.stack([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]], 1).reshape(-1, 2), 1)
    Eu, einv = np.unique(E, axis=0, return_inverse=True); einv = einv.reshape(-1, 3)
    EK = np.sort(K[:, [[0, 1], [1, 2], [2, 0]]].reshape(-1, 2), 1)
    opp = K[:, [2, 0, 1]].reshape(-1)                                  # vertex opposite each triangle edge
    EKu, ekinv = np.unique(EK, axis=0, return_inverse=True)
    cnt = np.bincount(ekinv, minlength=len(EKu))
    fn = np.cross(Pk[K[:, 1]] - Pk[K[:, 0]], Pk[K[:, 2]] - Pk[K[:, 0]]); fn /= np.maximum(np.linalg.norm(fn, axis=1), 1e-12)[:, None]
    tri_of = np.repeat(np.arange(len(F)), 3)
    # dihedral of 2-triangle edges
    sharp = cnt != 2
    two = np.where(cnt == 2)[0]
    order = np.argsort(ekinv, kind='stable'); starts = np.r_[0, np.cumsum(cnt)[:-1]]
    a_ = order[starts[two]]; b_ = order[starts[two] + 1]
    cosd = np.einsum('nd,nd->n', fn[tri_of[a_]], fn[tri_of[b_]])
    sharp[two] = cosd < np.cos(np.radians(crease))
    # new edge points (welded): Loop 3/8, 3/8, 1/8, 1/8 inside, midpoint on sharp edges
    osum = np.zeros((len(EKu), 3)); np.add.at(osum, ekinv, Pk[opp])
    mid = 0.5 * (Pk[EKu[:, 0]] + Pk[EKu[:, 1]])
    EP = np.where(sharp[:, None], mid, 0.75 * mid + 0.125 * osum)
    # old vertices: Loop smoothing; on sharp edges only along them; corners (other than 2 sharp edges) stay
    nb_sum = np.zeros((nk, 3)); nb_n = np.zeros(nk); sh_sum = np.zeros((nk, 3)); sh_n = np.zeros(nk)
    for c0, c1 in ((0, 1), (1, 0)):
        np.add.at(nb_sum, EKu[:, c0], Pk[EKu[:, c1]]); np.add.at(nb_n, EKu[:, c0], 1)
        s_ = sharp
        np.add.at(sh_sum, EKu[s_, c0], Pk[EKu[s_, c1]]); np.add.at(sh_n, EKu[s_, c0], 1)
    n_ = np.maximum(nb_n, 1); beta = np.where(n_ > 3, 3 / (8 * n_), 3 / 16)
    Pin = (1 - n_ * beta)[:, None] * Pk + beta[:, None] * nb_sum
    Psh = 0.75 * Pk + 0.125 * sh_sum
    NP = np.where((sh_n == 0)[:, None], Pin, np.where((sh_n == 2)[:, None], Psh, Pk))
    # raw edge -> welded edge point
    ekey = np.sort(key[Eu], 1); ek_idx = {tuple(r): i for i, r in enumerate(EKu)}
    eP = EP[[ek_idx[tuple(r)] for r in ekey]]
    # attributes of the new edge vertices
    a, b = Eu[:, 0], Eu[:, 1]
    S0n = np.zeros((len(Eu), 28), np.uint8); S1n = np.zeros((len(Eu), 44), np.uint8)
    S0n[:, 0:12] = eP.astype(np.float32).view(np.uint8)
    S0n[:, 12:20], S0n[:, 20:28] = _merge_w(S0[a, 12:20], S0[a, 20:28], S0[b, 12:20], S0[b, 20:28])
    fl = lambda S, o, n: S[:, o:o + 4 * n].copy().view(np.float32).astype(float)
    Nn = 0.5 * (fl(S1, 0, 3)[a] + fl(S1, 0, 3)[b]); Nn /= np.maximum(np.linalg.norm(Nn, axis=1), 1e-9)[:, None]
    S1n[:, 0:12] = Nn.astype(np.float32).view(np.uint8)
    S1n[:, 12:20] = ((S1[a, 12:20].astype(int) + S1[b, 12:20].astype(int)) // 2).astype(np.uint8)
    S1n[:, 20:44] = (0.5 * (fl(S1, 20, 6)[a] + fl(S1, 20, 6)[b])).astype(np.float32).view(np.uint8)
    S0o = S0.copy(); S0o[:, 0:12] = NP[key].astype(np.float32).view(np.uint8)
    # faces: each triangle -> 4, in order (submesh ranges scale by 4)
    e = einv + nv
    ab, bc, ca = e[:, 0], e[:, 1], e[:, 2]
    A_, B_, C_ = F[:, 0], F[:, 1], F[:, 2]
    NF = np.stack([np.stack([A_, ab, ca], 1), np.stack([ab, B_, bc], 1), np.stack([ca, bc, C_], 1), np.stack([ab, bc, ca], 1)], 1).reshape(-1, 3)
    m = dict(m)
    m['streams'] = [np.r_[S0o, S0n].tobytes(), np.r_[S1, S1n].tobytes()] + list(m['streams'][2:])
    m['nv'] = nv + len(Eu); m['idx'] = NF.astype(np.uint16).tobytes(); m['ic'] = len(NF) * 3
    m['subs'] = [dict(s, off=s['off'] * 4, cnt=s['cnt'] * 4) for s in m['subs']]
    m['shapes'] = {}
    return m


def subdivide(m, levels=2, max_edge=0.012, crease=50.0, max_nv=60000):
    """levels of smooth subdivision, fewer when the edges are already short or the vertex count would pass max_nv"""
    out = m; done = 0
    for _ in range(levels):
        nv = out['nv']; F = np.frombuffer(out['idx'], np.uint16).astype(int).reshape(-1, 3)
        P = np.frombuffer(out['streams'][0], np.uint8).reshape(nv, 28)[:, 0:12].copy().view(np.float32)
        el = np.median(np.linalg.norm(P[F[:, 0]] - P[F[:, 1]], axis=1))
        ne = len(np.unique(np.sort(np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]], 1), axis=0))
        if el < max_edge or nv + ne > max_nv: break
        out = _level(out, crease); done += 1
    return out, done
