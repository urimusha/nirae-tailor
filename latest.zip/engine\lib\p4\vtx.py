"""vertex data by semantic: decode a mesh's vertex streams into per-element arrays and encode them into another
vertex layout (FFXIV per-mesh vertex declarations: the body writes float normals/UVs, some ports write halfs)"""
import numpy as np
TYPES = {1: ('<f4', 2), 2: ('<f4', 3), 3: ('<f4', 4), 5: ('u1', 4), 8: ('u1', 4), 13: ('<f2', 2), 14: ('<f2', 4), 17: ('u1', 8)}

def elements(m):
    out = []
    for i in range(17):
        s, o, t, u = m['decl'][i * 8:i * 8 + 4]
        if s == 255: break
        out.append((s, o, t, u))
    return out

def keyed(m):
    """[(key=(usage, ordinal), (stream, offset, type))]"""
    cnt = {}; out = []
    for s, o, t, u in elements(m):
        k = (u, cnt.get(u, 0)); cnt[u] = k[1] + 1; out.append((k, (s, o, t)))
    return out

def rows(m, s):
    st = m['strides'][s]
    return np.frombuffer(m['streams'][s], np.uint8).reshape(m['nv'], st) if st else None

def decode(m, sel=None):
    """{key: array (nv, n) float64 for float/half types, uint8 for byte types}"""
    R = {}; out = {}
    for k, (s, o, t) in keyed(m):
        if s not in R: R[s] = rows(m, s)
        dt, n = TYPES[t]; sz = np.dtype(dt).itemsize * n
        a = np.ascontiguousarray(R[s][:, o:o + sz]).view(dt).reshape(-1, n)
        if sel is not None: a = a[sel]
        out[k] = (t, a.astype(float) if dt != 'u1' else a.copy())
    return out

def encode_into(m, data, nv):
    """new stream bytes for mesh m's layout from decoded data (another layout allowed): float<->half and
    float3 normal -> half4 (w = 0 unless the source had a w); byte types must match"""
    bufs = [np.zeros((nv, st), np.uint8) for st in m['strides']]
    for k, (s, o, t) in keyed(m):
        if k not in data: raise KeyError('no %s in the source vertex data' % (k,))
        ts, a = data[k]; dt, n = TYPES[t]
        if dt == 'u1':
            if TYPES[ts][0] != 'u1' or a.shape[1] != n: raise ValueError('byte element %s: %s -> %s' % (k, ts, t))
            b = a
        else:
            if a.dtype == np.uint8: raise ValueError('float element %s from bytes' % (k,))
            b = np.zeros((nv, n)); w = min(n, a.shape[1]); b[:, :w] = a[:, :w]
            b = b.astype(dt)
        sz = np.dtype(dt).itemsize * n
        bufs[s][:, o:o + sz] = np.ascontiguousarray(b).view(np.uint8).reshape(nv, sz)
    return [x.tobytes() for x in bufs]
