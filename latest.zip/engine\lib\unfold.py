"""Remove folded (flipped) triangles in the transferred region: relax their vertices to the neighbour average, then snap
back onto the source surface. Only vertices of folded triangles (and their 1-ring) move."""
import numpy as np, scipy.sparse as sp
from scipy.spatial import cKDTree
def _closest_on_tris(p,A,B,C):
    # vectorised closest point on many triangles (Ericson); returns points
    ab=B-A; ac=C-A; ap=p-A
    d1=np.einsum('ij,ij->i',ab,ap); d2=np.einsum('ij,ij->i',ac,ap)
    bp=p-B; d3=np.einsum('ij,ij->i',ab,bp); d4=np.einsum('ij,ij->i',ac,bp)
    cp=p-C; d5=np.einsum('ij,ij->i',ab,cp); d6=np.einsum('ij,ij->i',ac,cp)
    va=d3*d6-d5*d4; vb=d5*d2-d1*d6; vc=d1*d4-d3*d2
    den=1/np.maximum(va+vb+vc,1e-30); v=vb*den; w=vc*den
    out=A+ab*v[:,None]+ac*w[:,None]
    m=(d1<=0)&(d2<=0); out[m]=A[m]
    m=(d3>=0)&(d4<=d3); out[m]=B[m]
    m=(d6>=0)&(d5<=d6); out[m]=C[m]
    m=(vc<=0)&(d1>=0)&(d3<=0); t=d1/np.where(d1-d3==0,1,d1-d3); out[m]=(A+ab*t[:,None])[m]
    m=(vb<=0)&(d2>=0)&(d6<=0); t=d2/np.where(d2-d6==0,1,d2-d6); out[m]=(A+ac*t[:,None])[m]
    m=(va<=0)&((d4-d3)>=0)&((d5-d6)>=0); t=(d4-d3)/np.where((d4-d3)+(d5-d6)==0,1,(d4-d3)+(d5-d6)); out[m]=(B+(C-B)*t[:,None])[m]
    return out
def snap(Q,Ps,Ts,k=16):
    C=Ps[Ts].mean(1); tr=cKDTree(C); _,cand=tr.query(Q,k=k); best=np.full(len(Q),np.inf); out=Q.copy()
    for j in range(k):
        t=cand[:,j]; c=_closest_on_tris(Q,Ps[Ts[t,0]],Ps[Ts[t,1]],Ps[Ts[t,2]]); d=np.linalg.norm(c-Q,axis=1)
        b=d<best; best[b]=d[b]; out[b]=c[b]
    return out
def unfold(V,T,wid,ref,region,Ps,Ts,iters=40):
    """V: positions (n_vertices), ref: reference positions giving the intended orientation, region: bool per vertex allowed to move"""
    n=wid.max()+1; rep=np.zeros(n,int); rep[wid]=np.arange(len(V))
    W=T if False else wid[T]
    E=np.concatenate([W[:,[0,1]],W[:,[1,2]],W[:,[2,0]]]); E=np.unique(np.sort(E,1),axis=0); E=E[E[:,0]!=E[:,1]]
    A=sp.coo_matrix((np.ones(2*len(E)),(np.r_[E[:,0],E[:,1]],np.r_[E[:,1],E[:,0]])),shape=(n,n)).tocsr()
    deg=np.asarray(A.sum(1)).ravel(); M=sp.diags(1/np.maximum(deg,1))@A
    Q=V[rep].copy(); R=ref[rep]; reg=np.zeros(n,bool); np.logical_or.at(reg,wid,region)
    SC=Ps[Ts].mean(1); SN=np.cross(Ps[Ts[:,1]]-Ps[Ts[:,0]],Ps[Ts[:,2]]-Ps[Ts[:,0]]); SN/=np.maximum(np.linalg.norm(SN,axis=1),1e-15)[:,None]
    str_=cKDTree(SC)
    hist=[]
    for it in range(iters):
        _,j=str_.query(Q[W].mean(1)); fr=SN[j]
        fq=np.cross(Q[W[:,1]]-Q[W[:,0]],Q[W[:,2]]-Q[W[:,0]])
        bad=(np.einsum('ij,ij->i',fq,fr)<0)&reg[W].all(1)
        hist.append(int(bad.sum()))
        if not bad.any(): break
        mv=np.zeros(n,bool); mv[W[bad].ravel()]=True
        mv=mv|(A@mv.astype(float)>0); mv&=reg
        avg=M@Q; Q[mv]=avg[mv]
        Q[mv]=snap(Q[mv],Ps,Ts)
    return Q[wid],hist
