"""tall-race outfit -> NIRÆ (all builds, every chest / belly / hips option, the body's jiggles): the port4 pipeline,
one process per build (port4 keeps module caches), up to `parallel` at once.

Job (direction "tall2nirae"):
  items: [{slot: top | dwn, src: outfit .mdl, out: folder, body: {top: author body top .mdl, dwn: author legs .mdl}}]
  builds: [curvy, thick, athletic, slim], nirae_meta: NIRÆ Body meta.json (the body files its Build & Hips option uses)
  parallel: processes at once (default: by memory and cores)
Job (direction "detect"): items [{slot, src}] -> per item the ranked author bodies (bodylib) + the whole library."""
import os, sys, json, re, time, subprocess, threading

HERE = os.path.dirname(os.path.abspath(__file__))
BUILDS = ('curvy', 'thick', 'athletic', 'slim')
HIPS = ('small', 'medium', 'large')


def nirae_builds(meta_path):
    """{'builds': {b: [top, dwn medium]}, 'hips': {b: {h: dwn}}} - file names in files/standalone - from the body's
    Build & Hips option (whatever versions the installed NIRÆ uses)"""
    with open(meta_path, encoding='utf-8-sig') as f:
        m = json.load(f)
    g = next((g for g in m.get('Groups') or [] if g.get('Name') == 'Build & Hips'), None)
    if g is None:
        raise ValueError('the NIRÆ body has no "Build & Hips" option')
    builds = {}; hips = {}
    for o in g.get('Options') or []:
        mm = re.match(r'^\s*(\w+)\s*·\s*(\w+)\s+hips', o.get('Name') or '', re.I)
        if not mm:
            continue
        b, h = mm.group(1).lower(), mm.group(2).lower()
        fs = {k.replace('\\', '/').lower(): v.replace('\\', '/').split('/')[-1] for k, v in (o.get('Files') or {}).items()}
        top = fs.get('chara/equipment/e0000/model/c0201e0000_top.mdl'); dwn = fs.get('chara/equipment/e0000/model/c0201e0000_dwn.mdl')
        if b in BUILDS and h in HIPS and top and dwn:
            hips.setdefault(b, {})[h] = dwn
            if h == 'medium':
                builds[b] = [top, dwn]
    for b in BUILDS:
        if b not in builds or set(hips.get(b, {})) != set(HIPS):
            raise ValueError('the NIRÆ Build & Hips option has no complete %s files' % b)
    return dict(builds=builds, hips=hips)


def default_parallel():
    n = os.cpu_count() or 2
    mem = None
    try:
        if os.name == 'nt':
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong), ('ullTotalPhys', ctypes.c_ulonglong),
                            ('ullAvailPhys', ctypes.c_ulonglong), ('ullTotalPageFile', ctypes.c_ulonglong),
                            ('ullAvailPageFile', ctypes.c_ulonglong), ('ullTotalVirtual', ctypes.c_ulonglong),
                            ('ullAvailVirtual', ctypes.c_ulonglong), ('ullAvailExtendedVirtual', ctypes.c_ulonglong)]
            s = MS(); s.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            mem = s.ullAvailPhys / 2 ** 30
        else:
            with open('/proc/meminfo') as f:
                for line in f:
                    if line.startswith('MemAvailable'):
                        mem = int(line.split()[1]) / 2 ** 20
    except Exception:
        mem = None
    by_mem = int(mem // 3.5) if mem else 1                   # a big outfit's run peaks at ~3 GB
    return max(1, min(4, n // 4 if n >= 8 else 1, by_mem))


def port_one(slot, src, body, build, out_mdl, env, log_path, extra_cfg=None):
    """one port4 run in its own process; returns (exit code, seconds, report dict or None)"""
    # loose garments are found in the author's model (port4 auto_loose); small hard pieces stay rigid and narrow strips
    # over the chest stay stiff (port4 defaults)
    cfg = dict(name=slot, sizes={'s': src}, body={'s': body['top']}, legs=body['dwn'], drape=[], auto_loose=True)
    if slot == 'dwn':
        # the Legs slot carries the legs skin and has no chest switches in the NIRÆ meta: one fit, against Medium Round
        cfg['slot'] = 'dwn'; cfg['only_chest'] = 'medium'
    if extra_cfg:
        cfg.update(extra_cfg)
    cfgp = out_mdl[:-4] + '_cfg.json'
    with open(cfgp, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)
    cmd = [sys.executable, '-I', '-X', 'utf8', os.path.join(HERE, '..', 'run_port4.py'), build, out_mdl, cfgp]
    t0 = time.time()
    kw = {}
    if os.name == 'nt':
        kw['creationflags'] = 0x00004000 | 0x08000000          # BELOW_NORMAL_PRIORITY_CLASS | CREATE_NO_WINDOW
    with open(log_path, 'w', encoding='utf-8') as lf:
        rc = subprocess.call(cmd, stdout=lf, stderr=subprocess.STDOUT, env=env, **kw)
    rep = None
    try:
        txt = open(log_path, encoding='utf-8', errors='replace').read()
        i = txt.find('\n{')
        if i >= 0:
            rep = json.JSONDecoder().raw_decode(txt[i + 1:])[0]
            rep.pop('variant_lift', None)
        # share of the author's body that found no trustworthy spot on NIRÆ through the shared UVs: high = wrong body
        # or UV layout (the cloth there only follows its neighbours)
        # (the vulva bridge marks the author skin over NIRÆ's vulva untrusted on purpose: not counted)
        vb = [int(x) for x in re.findall(r'vulva bridge: (\d+) author skin points untrusted', txt)]
        un = re.findall(r'untrusted UV matches filled: (\d+) of (\d+)', txt)
        sh = [max(0, int(a) - (vb[k] if k < len(vb) else 0)) / max(1, int(b)) for k, (a, b) in enumerate(un)]
        if rep is not None and sh:
            # per chest option: the median says whether the body is right (the biggest chests always match less)
            rep['untrusted'] = round(float(sorted(sh)[len(sh) // 2]), 3); rep['untrusted_max'] = round(max(sh), 3)
        if rep is not None:
            m_ = re.search(r'auto loose: (\[[^\]]*\]|none)', txt)
            if m_: rep['loose'] = [] if m_.group(1) == 'none' else re.findall(r"'([^']*)'", m_.group(1))
            m_ = re.search(r'shape-keeping pieces: (\d+) rigid \(< \d+ mm\), (\d+) stiff strips', txt)
            if m_: rep['rigid_pieces'] = int(m_.group(1)); rep['stiff_strips'] = int(m_.group(2))
    except Exception:
        rep = None
    return rc, time.time() - t0, rep


def run(job, say, log):
    """ports every item to every build; returns result items"""
    meta = job.get('nirae_meta')
    nb = nirae_builds(meta)
    env = dict(os.environ)
    env['LP_NIRAE_BUILDS'] = json.dumps(nb)
    env['PYTHONIOENCODING'] = 'utf-8'
    builds = [b for b in (job.get('builds') or BUILDS) if b in BUILDS]
    par = int(job.get('parallel') or 0) or default_parallel()
    tasks = []
    res = []
    for it in job['items']:
        if it['slot'] not in ('top', 'dwn'):
            res.append(dict(slot=it['slot'], error='the %s slot is not supported for NIRÆ yet' % it['slot']))
            continue
        os.makedirs(it['out'], exist_ok=True)
        r = dict(slot=it['slot'], src=it['src'], body=it['body'], outs={}, reports={}, seconds={}, errors={})
        res.append(r)
        for b in builds:
            tasks.append((r, it, b))
    say(stage='port', msg='porting %d model(s) to %d build(s), %d at a time' % (len(res), len(builds), par))
    lock = threading.Lock(); queue = list(tasks)

    def worker():
        while True:
            with lock:
                if not queue:
                    return
                r, it, b = queue.pop(0)
            out = os.path.join(it['out'], '%s_%s.mdl' % (it['slot'], b))
            lp = out[:-4] + '_log.txt'
            say(stage='slot', slot=it['slot'], msg='%s: fitting the %s build' % (it['slot'], b))
            try:
                rc, sec, rep = port_one(it['slot'], it['src'], it['body'], b, out, env, lp, it.get('cfg'))
            except Exception as e:
                rc, sec, rep = -1, 0.0, None
                with lock:
                    log.append('%s %s: %s' % (it['slot'], b, e))
            with lock:
                r['seconds'][b] = round(sec, 1)
                if rc == 0 and os.path.exists(out):
                    r['outs'][b] = out
                    if rep is not None:
                        r['reports'][b] = rep
                    say(stage='slot_done', slot=it['slot'], msg='%s: %s done in %.0f s' % (it['slot'], b, sec))
                else:
                    tail = ''
                    try:
                        tail = open(lp, encoding='utf-8', errors='replace').read()[-600:]
                    except Exception:
                        pass
                    r['errors'][b] = 'port4 exit %s: %s' % (rc, tail.strip().splitlines()[-1] if tail.strip() else '')
                    log.append('%s %s failed (exit %s); log %s\n%s' % (it['slot'], b, rc, lp, tail))
                    say(stage='slot_error', slot=it['slot'], msg='%s: %s failed (see %s)' % (it['slot'], b, lp))

    th = [threading.Thread(target=worker) for _ in range(max(1, min(par, len(tasks))))]
    for t in th:
        t.start()
    for t in th:
        t.join()
    for r in res:
        if 'outs' in r and not r['outs']:
            r['error'] = 'no build could be ported: ' + '; '.join('%s: %s' % kv for kv in r['errors'].items())
    return res


def detect(job, say, log):
    import bodylib as BL
    root = os.environ.get('LP_MODS', '')
    skip = [job['nirae_dir']] if job.get('nirae_dir') else []
    t0 = time.time()
    lib = BL.scan(root, skip=skip)
    say(stage='detect', msg='%d body models in %d mods (%.1f s)' % (len(lib), len({c['mod'] for c in lib}), time.time() - t0))
    out = []
    for it in job['items']:
        r = BL.detect(it['src'], lib)
        top = [dict(score=sc, label=BL.label(c), **c) for sc, c in r['top'][:8]]
        dwn = [dict(score=sc, label=BL.label(c), **c) for sc, c in r['dwn'][:8]]
        legs = None
        if top and not dwn:
            lg = BL.legs_for(r['top'][0][1], lib)
            legs = dict(label=BL.label(lg), **lg) if lg else None
        out.append(dict(slot=it['slot'], src=it['src'], skin_points=r['skin_points'], top=top, dwn=dwn, legs=legs))
    return dict(items=out, library=[dict(label=BL.label(c), **c) for c in lib])
