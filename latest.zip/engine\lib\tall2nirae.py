"""tall-race outfit -> NIRÆ (all builds, every chest / belly / hips option, the body's jiggles): the port4 pipeline,
one process per build (port4 keeps module caches), up to `parallel` at once.

Job (direction "tall2nirae"):
  items: [{slot: top | dwn, src: outfit .mdl, out: folder, body: {top: author body top .mdl, dwn: author legs .mdl},
           vanilla: true for the game's own gear (body = the game's smallclothes top / legs models)}]
  builds: [curvy, thick, athletic, slim], nirae_meta: NIRÆ Body meta.json (the body files its Build & Hips option uses)
  parallel: processes at once (default: by memory and cores)
Job (direction "detect"): items [{slot, src}] -> per item the ranked author bodies (bodylib) + the whole library."""
import os, sys, json, re, time, subprocess, threading

HERE = os.path.dirname(os.path.abspath(__file__))
BUILDS = ('curvy', 'thick', 'athletic', 'slim')
HIPS = ('small', 'medium', 'large')


def nirae_builds(meta_path):
    """{'builds': {b: [top, dwn medium]}, 'hips': {b: {h: dwn}}} - file names in files/standalone - from the body's
    Build & Hips option (whatever versions the installed NIRÆ uses)"""
    with open(meta_path, encoding='utf-8-sig') as f:
        m = json.load(f)
    g = next((g for g in m.get('Groups') or [] if g.get('Name') == 'Build & Hips'), None)
    if g is None:
        raise ValueError('the NIRÆ body has no "Build & Hips" option')
    builds = {}; hips = {}
    for o in g.get('Options') or []:
        mm = re.match(r'^\s*(\w+)\s*·\s*(\w+)\s+hips', o.get('Name') or '', re.I)
        if not mm:
            continue
        b, h = mm.group(1).lower(), mm.group(2).lower()
        fs = {k.replace('\\', '/').lower(): v.replace('\\', '/').split('/')[-1] for k, v in (o.get('Files') or {}).items()}
        top = fs.get('chara/equipment/e0000/model/c0201e0000_top.mdl'); dwn = fs.get('chara/equipment/e0000/model/c0201e0000_dwn.mdl')
        if b in BUILDS and h in HIPS and top and dwn:
            hips.setdefault(b, {})[h] = dwn
            if h == 'medium':
                builds[b] = [top, dwn]
    for b in BUILDS:
        if b not in builds or set(hips.get(b, {})) != set(HIPS):
            raise ValueError('the NIRÆ Build & Hips option has no complete %s files' % b)
    # Squish: the body's squish tops have the same shape plus the cb_skin bones the arms push. Fitted against them the
    # cloth carries those weights too, so with Squish on it is pushed in with the skin (Squish off: the bones rest)
    sq = next((g for g in m.get('Groups') or [] if g.get('Name') == 'Squish'), None)
    squish = {}
    for o in (sq or {}).get('Options') or []:
        mm = re.search(r'\((\w+)\)\s*$', o.get('Name') or '')
        top = {k.replace('\\', '/').lower(): v.replace('\\', '/').split('/')[-1] for k, v in (o.get('Files') or {}).items()}.get('chara/equipment/e0000/model/c0201e0000_top.mdl')
        if mm and top and mm.group(1).lower() in BUILDS:
            squish[mm.group(1).lower()] = top
    for b, top in squish.items():
        builds[b] = [top, builds[b][1]]
    # NIRÆ's own hands and feet (the Hands & Feet option that has files)
    parts = {}
    hf = next((g for g in m.get('Groups') or [] if g.get('Name') == 'Hands & Feet'), None)
    for o in (hf or {}).get('Options') or []:
        fs = {k.replace('\\', '/').lower(): v.replace('\\', '/').split('/')[-1] for k, v in (o.get('Files') or {}).items()}
        for sl in ('glv', 'sho'):
            f = fs.get('chara/equipment/e0000/model/c0201e0000_%s.mdl' % sl)
            if f and sl not in parts:
                parts[sl] = f
    return dict(builds=builds, hips=hips, squish=sorted(squish), parts=parts)


def default_parallel():
    n = os.cpu_count() or 2
    mem = None
    try:
        if os.name == 'nt':
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong), ('ullTotalPhys', ctypes.c_ulonglong),
                            ('ullAvailPhys', ctypes.c_ulonglong), ('ullTotalPageFile', ctypes.c_ulonglong),
                            ('ullAvailPageFile', ctypes.c_ulonglong), ('ullTotalVirtual', ctypes.c_ulonglong),
                            ('ullAvailVirtual', ctypes.c_ulonglong), ('ullAvailExtendedVirtual', ctypes.c_ulonglong)]
            s = MS(); s.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            mem = s.ullAvailPhys / 2 ** 30
        else:
            with open('/proc/meminfo') as f:
                for line in f:
                    if line.startswith('MemAvailable'):
                        mem = int(line.split()[1]) / 2 ** 20
    except Exception:
        mem = None
    by_mem = int(mem // 3.5) if mem else 1                   # a big outfit's run peaks at ~3 GB
    return max(1, min(4, n // 4 if n >= 8 else 1, by_mem))


def port_one(slot, src, body, build, out_mdl, env, log_path, extra_cfg=None):
    """one port4 run in its own process; returns (exit code, seconds, report dict or None)"""
    # loose garments are found in the author's model (port4 auto_loose); small hard pieces stay rigid and narrow strips
    # over the chest stay stiff (port4 defaults)
    cfg = dict(name=slot, sizes={'s': src}, body={'s': body['top']}, legs=body['dwn'], drape=[], auto_loose=True)
    if slot == 'top':
        # tops: tight fabric bridges the nipples (a smooth tent) instead of following them; on the big chests the
        # glued cloth showed the nipples poking through
        cfg['smooth_nipples'] = True
    if slot == 'dwn':
        # the Legs slot carries the legs skin and has no chest switches in the NIRÆ meta: one fit, against Medium Round
        cfg['slot'] = 'dwn'; cfg['only_chest'] = 'medium'
    if extra_cfg:
        cfg.update(extra_cfg)
    cfgp = out_mdl[:-4] + '_cfg.json'
    with open(cfgp, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)
    cmd = [sys.executable, '-I', '-X', 'utf8', os.path.join(HERE, '..', 'run_port4.py'), build, out_mdl, cfgp]
    t0 = time.time()
    kw = {}
    if os.name == 'nt':
        kw['creationflags'] = 0x00004000 | 0x08000000          # BELOW_NORMAL_PRIORITY_CLASS | CREATE_NO_WINDOW
    with open(log_path, 'w', encoding='utf-8') as lf:
        rc = subprocess.call(cmd, stdout=lf, stderr=subprocess.STDOUT, env=env, **kw)
    rep = None
    try:
        txt = open(log_path, encoding='utf-8', errors='replace').read()
        i = txt.find('\n{')
        if i >= 0:
            rep = json.JSONDecoder().raw_decode(txt[i + 1:])[0]
            rep.pop('variant_lift', None)
        # share of the author's body that found no trustworthy spot on NIRÆ through the shared UVs: high = wrong body
        # or UV layout (the cloth there only follows its neighbours)
        # (the vulva bridge marks the author skin over NIRÆ's vulva untrusted on purpose: not counted)
        vb = [int(x) for x in re.findall(r'vulva bridge: (\d+) author skin points untrusted', txt)]
        un = re.findall(r'untrusted UV matches filled: (\d+) of (\d+)', txt)
        sh = [max(0, int(a) - (vb[k] if k < len(vb) else 0)) / max(1, int(b)) for k, (a, b) in enumerate(un)]
        if rep is not None and sh:
            # per chest option: the median says whether the body is right (the biggest chests always match less)
            rep['untrusted'] = round(float(sorted(sh)[len(sh) // 2]), 3); rep['untrusted_max'] = round(max(sh), 3)
        if rep is not None:
            m_ = re.search(r'auto loose: (\[[^\]]*\]|none)', txt)
            if m_: rep['loose'] = [] if m_.group(1) == 'none' else re.findall(r"'([^']*)'", m_.group(1))
            # per chest: crumpled vertices repaired, final lift against the skin (the plugin's fit report)
            cr = {}
            for ln in txt.splitlines():
                m2 = re.match(r'^(\w+) auto fix: (.*); lifted max ([\d.]+) mm', ln)
                if m2: cr.setdefault(m2.group(1), {})['fixed'] = sum(int(x) for x in re.findall(r'(\d+) crumpled verts smoothed', m2.group(2)))
                m2 = re.match(r'^(\w+) final clear: lifted max ([\d.]+) mm', ln)
                if m2: cr.setdefault(m2.group(1), {})['cleared_mm'] = float(m2.group(2))
                m2 = re.match(r'^(\w+) chest map smoothed \(bust (\d+) mm', ln)
                if m2: cr.setdefault(m2.group(1), {})['bust_diff_mm'] = int(m2.group(2))
            if cr: rep['chest_report'] = cr
            fx = [int(x) for x in re.findall(r'(\d+) crumpled verts smoothed', txt)]
            if fx: rep['auto_fixed'] = max(fx); rep['auto_fixed_chests'] = len(re.findall(r'auto fix: ', txt))
            m_ = re.search(r'shape-keeping pieces: (\d+) rigid \(< \d+ mm\), (\d+) stiff strips', txt)
            if m_: rep['rigid_pieces'] = int(m_.group(1)); rep['stiff_strips'] = int(m_.group(2))
    except Exception:
        rep = None
    return rc, time.time() - t0, rep


def run(job, say, log):
    """ports every item to every build; returns result items"""
    meta = job.get('nirae_meta')
    nb = nirae_builds(meta)
    env = dict(os.environ)
    env['LP_NIRAE_BUILDS'] = json.dumps(nb)
    env['PYTHONIOENCODING'] = 'utf-8'
    builds = [b for b in (job.get('builds') or BUILDS) if b in BUILDS]
    par = int(job.get('parallel') or 0) or default_parallel()
    # the user's fine-tuning (plugin): snug upper chest, loose hang, smoothing, repair strength
    tn = job.get('tuning') or {}
    tcfg = {}
    if 'snug' in tn:
        v = max(0.0, min(1.0, float(tn['snug'])))
        tcfg['snug'] = {c: v for c in (('flat', 'small', 'champs', 'smallperky', 'medium', 'large', 'saggy', 'perky', 'earth', 'mireya')
                                         if tn.get('snug_all') else ('perky', 'smallperky'))}
    if 'hang' in tn:
        tcfg['hang'] = max(0.0, min(1.0, float(tn['hang'])))
    rp = tn.get('repair')
    if rp is not None:
        tcfg['auto_fix'] = {'off': False, 'gentle': {'thr': 0.5, 'sigma': 0.010}, 'normal': {'thr': 0.3, 'sigma': 0.012},
                            'strong': {'thr': 0.2, 'sigma': 0.016}}.get(rp, {'thr': 0.3, 'sigma': 0.012})
    if 'smooth' in tn:
        job['subdivide'] = int(tn['smooth'])
    for it in job['items']:
        if tcfg:
            it['cfg'] = dict(tcfg, **(it.get('cfg') or {}))
    tasks = []
    res = []
    hf = []
    for it in job['items']:
        if it['slot'] not in ('top', 'dwn', 'glv', 'sho'):
            res.append(dict(slot=it['slot'], error='the %s slot is not supported for NIRÆ yet' % it['slot']))
            continue
        os.makedirs(it['out'], exist_ok=True)
        r = dict(slot=it['slot'], src=it['src'], body=it['body'], outs={}, reports={}, seconds={}, errors={})
        res.append(r)
        if it['slot'] in ('glv', 'sho'):
            hf.append((r, it))                       # one fit for every build (NIRÆ has one hands / feet model)
            continue
        for b in builds:
            tasks.append((r, it, b))
    # the game's own (vanilla) gear: its author body is the vanilla smallclothes body, morphed from a NIRÆ body so it
    # shares our UVs (built once per pair of body files, then every build fits against it)
    kw = {'creationflags': 0x00004000 | 0x08000000} if os.name == 'nt' else {}

    def helper(args, lp):
        with open(lp, 'w', encoding='utf-8') as lf:
            rc = subprocess.call([sys.executable, '-I', '-X', 'utf8', os.path.join(HERE, '..', 'run_vanilla.py')] + args,
                                 stdout=lf, stderr=subprocess.STDOUT, env=env, **kw)
        if rc != 0:
            log.append('vanilla helper %s failed (exit %s): %s' % (args[0], rc, open(lp, encoding='utf-8', errors='replace').read()[-400:]))
        return rc == 0

    # the game's own gear that exists only as another race's model (gloves / shoes are mostly the men's c0101): the
    # model and the smallclothes body it was made on are first reshaped to c0201 by the game's own race deformer
    for it in job['items']:
        rc = it.get('race')
        if not it.get('vanilla') or not rc or rc == 'c0201' or not it.get('pbd') or not it.get('sklb'):
            continue
        src_race = int(rc[1:])
        say(stage='slot', slot=it['slot'], msg='%s: reshaping the game\'s %s model to the women\'s body' % (it['slot'], rc))
        new = {}
        for k, f in (('src', it['src']), ('top', it['body']['top']), ('dwn', it['body']['dwn'])):
            if k == 'dwn' and f == it['body']['top']:
                new[k] = new['top']; continue
            o_ = os.path.join(it['out'], 'c0201_' + k + '_' + os.path.basename(f))
            os.makedirs(it['out'], exist_ok=True)
            if not helper(['deform', f, o_, it['pbd'], it['sklb'], str(src_race)], o_[:-4] + '_log.txt') or not os.path.exists(o_):
                new = None; break
            new[k] = o_
        if new is None:
            it['_deform_failed'] = True
            continue
        it['src'] = new['src']; it['body'] = {'top': new['top'], 'dwn': new['dwn']}
    for r, it in [(t[0], t[1]) for t in tasks] + hf:
        if it.get('_deform_failed'):
            r['error'] = 'the game\'s %s model could not be reshaped to the women\'s body (see the engine log)' % it.get('race')
    vb = {}; done_it = set()

    for r, it, b in tasks:
        if not it.get('vanilla') or id(it) in done_it:
            continue
        done_it.add(id(it))
        key = (it['body']['top'], it['body']['dwn'])
        if key not in vb:
            npz = os.path.join(it['out'], 'vanilla_body.npz')
            say(stage='slot', slot=it['slot'], msg='%s: shaping the game\'s own body for vanilla gear' % it['slot'])
            vb[key] = npz if helper(['body', key[0], key[1], npz], npz[:-4] + '_log.txt') and os.path.exists(npz) else None
        if vb[key] is None:
            r['error'] = 'the game\'s own body could not be prepared (see the engine log)'
            continue
        it['cfg'] = dict(it.get('cfg') or {}, author_body_npz=vb[key])
        # the game's low-poly cloth smoothly subdivided first (job 'subdivide': levels, default 2; 0 = as it is)
        lv = int(job.get('subdivide', 2))
        if lv > 0:
            sub = os.path.join(it['out'], 'smooth_' + os.path.basename(it['src']))
            say(stage='slot', slot=it['slot'], msg='%s: smoothing the game\'s low-poly model' % it['slot'])
            if helper(['subdiv', it['src'], sub, str(lv)], sub[:-4] + '_log.txt') and os.path.exists(sub):
                it['src'] = sub
            else:
                say(stage='log', msg='%s: smoothing failed, ported as it is' % it['slot'])
    # mod outfits: coarse (game-like, low-poly) pieces are smoothly subdivided too (job 'subdivide' 0 = off)
    for r, it, b in tasks:
        if it.get('vanilla') or id(it) in done_it or int(job.get('subdivide', 2)) <= 0:
            continue
        done_it.add(id(it))
        sub = os.path.join(it['out'], 'smooth_' + os.path.basename(it['src']))
        if helper(['subdiv', it['src'], sub, str(int(job.get('subdivide', 2))), 'auto'], sub[:-4] + '_log.txt') and os.path.exists(sub):
            say(stage='log', msg='%s: coarse pieces smoothed before the fit' % it['slot'])
            it['src'] = sub
    tasks = [t for t in tasks if 'error' not in t[0]]
    # gloves / shoes: NIRÆ's own hands / feet, fitted once and used for every build
    for r, it in hf:
        if 'error' in r:
            continue
        part = (nb.get('parts') or {}).get(it['slot'])
        if not part:
            r['error'] = 'the NIRÆ Body has no %s model in its Hands & Feet option' % ('hands' if it['slot'] == 'glv' else 'feet')
            continue
        src = it['src']
        if int(job.get('subdivide', 2)) > 0:
            # coarse mod pieces (auto) / the game's own gear (always) smoothed first
            sub = os.path.join(it['out'], 'smooth_' + os.path.basename(src))
            if helper(['subdiv', src, sub, str(int(job.get('subdivide', 2)))] + ([] if it.get('vanilla') else ['auto']), sub[:-4] + '_log.txt') and os.path.exists(sub):
                src = sub
        out = os.path.join(it['out'], '%s_all.mdl' % it['slot']); lp = out[:-4] + '_log.txt'
        say(stage='slot', slot=it['slot'], msg='%s: fitting to NIRÆ\'s %s' % (it['slot'], 'hands' if it['slot'] == 'glv' else 'feet'))
        t0 = time.time()
        args = ['handfeet', it['slot'], src, it['body']['top'], os.path.join(os.environ.get('LP_NIRAE_STANDALONE', ''), part), out] + (['vanilla'] if it.get('vanilla') else [])
        if helper(args, lp) and os.path.exists(out):
            r['outs'] = {b: out for b in builds}
            r['seconds'] = {b: round(time.time() - t0, 1) for b in builds}
            fx = [int(x) for x in re.findall(r'(\d+) crumpled verts smoothed', open(lp, encoding='utf-8', errors='replace').read())]
            r['reports'] = {builds[0]: dict(auto_fixed=max(fx) if fx else 0, auto_fixed_chests=1 if fx else 0)} if builds else {}
            say(stage='slot_done', slot=it['slot'], msg='%s: done in %.0f s' % (it['slot'], time.time() - t0))
        else:
            r['error'] = 'the %s fit failed (see %s)' % (it['slot'], lp)
    say(stage='port', msg='porting %d model(s) to %d build(s), %d at a time' % (len(res), len(builds), par))
    lock = threading.Lock(); queue = list(tasks)

    def worker():
        while True:
            with lock:
                if not queue:
                    return
                r, it, b = queue.pop(0)
            out = os.path.join(it['out'], '%s_%s.mdl' % (it['slot'], b))
            lp = out[:-4] + '_log.txt'
            say(stage='slot', slot=it['slot'], msg='%s: fitting the %s build' % (it['slot'], b))
            try:
                rc, sec, rep = port_one(it['slot'], it['src'], it['body'], b, out, env, lp, it.get('cfg'))
            except Exception as e:
                rc, sec, rep = -1, 0.0, None
                with lock:
                    log.append('%s %s: %s' % (it['slot'], b, e))
            with lock:
                r['seconds'][b] = round(sec, 1)
                if rc == 0 and os.path.exists(out):
                    r['outs'][b] = out
                    if rep is not None:
                        r['reports'][b] = rep
                    say(stage='slot_done', slot=it['slot'], msg='%s: %s done in %.0f s' % (it['slot'], b, sec))
                else:
                    tail = ''
                    try:
                        tail = open(lp, encoding='utf-8', errors='replace').read()[-600:]
                    except Exception:
                        pass
                    r['errors'][b] = 'port4 exit %s: %s' % (rc, tail.strip().splitlines()[-1] if tail.strip() else '')
                    log.append('%s %s failed (exit %s); log %s\n%s' % (it['slot'], b, rc, lp, tail))
                    say(stage='slot_error', slot=it['slot'], msg='%s: %s failed (see %s)' % (it['slot'], b, lp))

    th = [threading.Thread(target=worker) for _ in range(max(1, min(par, len(tasks))))]
    for t in th:
        t.start()
    for t in th:
        t.join()
    for r in res:
        if 'outs' in r and not r['outs'] and 'error' not in r:
            r['error'] = 'no build could be ported: ' + '; '.join('%s: %s' % kv for kv in r['errors'].items())
    return res


def detect(job, say, log):
    import bodylib as BL
    root = os.environ.get('LP_MODS', '')
    skip = [job['nirae_dir']] if job.get('nirae_dir') else []
    t0 = time.time()
    lib = BL.scan(root, skip=skip)
    say(stage='detect', msg='%d body models in %d mods (%.1f s)' % (len(lib), len({c['mod'] for c in lib}), time.time() - t0))
    out = []
    for it in job['items']:
        r = BL.detect(it['src'], lib)
        # hands / feet pieces: their author is a hands / feet model (both lists, the plugin shows one choice)
        kt = it['slot'] if it['slot'] in ('glv', 'sho') else 'top'; kd = it['slot'] if it['slot'] in ('glv', 'sho') else 'dwn'
        top = [dict(score=sc, label=BL.label(c), **c) for sc, c in r[kt][:8]]
        dwn = [dict(score=sc, label=BL.label(c), **c) for sc, c in r[kd][:8]]
        legs = None
        if top and not dwn and kt == 'top':
            lg = BL.legs_for(r['top'][0][1], lib)
            legs = dict(label=BL.label(lg), **lg) if lg else None
        out.append(dict(slot=it['slot'], src=it['src'], skin_points=r['skin_points'], top=top, dwn=dwn, legs=legs))
    return dict(items=out, library=[dict(label=BL.label(c), **c) for c in lib])
