"""model bounding boxes from the model's own vertices (same as ohport finalize3.fix_bbox)"""
import numpy as np, sys
pass
from surf import attr


def fix_bbox(M):
    P = np.concatenate([attr(m, 0)[0][:, :3].astype(float) for m in M['meshes'] if m['nv']])
    lo, hi = P.min(0), P.max(0)
    b = np.frombuffer(M['bbox'], '<f4').copy()
    b[0:8] = [*np.minimum(lo, 0), 1.0, *np.maximum(hi, 0), 1.0]
    b[8:16] = [*lo, 1.0, *hi, 1.0]
    M['bbox'] = b.astype('<f4').tobytes()
