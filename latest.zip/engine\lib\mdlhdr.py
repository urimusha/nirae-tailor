import struct
def walk(d):
    h=struct.unpack_from('<IIIHH3I3I3I3IBBBB',d,0)
    o=0x44+136*h[3]
    sc,ss=struct.unpack_from('<II',d,o); o+=8+ss
    mh_off=o
    mh=struct.unpack_from('<f9HBBHBBffHHBBBBHHH6s',d,o); o+=56
    meshC,attrC,subC,matC,boneC,btC,shapeC,shapeMeshC,shapeValC=mh[1:10]
    lodC,f1,elemC,tsmC,f2=mh[10],mh[11],mh[12],mh[13],mh[14]
    tssC=mh[18]; btTot=mh[23]
    R={'mh_off':mh_off,'h':h,'mh':mh}
    o+=elemC*32
    R['lod_off']=o; o+=180
    if f2&0x10: o+=120
    R['mesh_off']=o; o+=36*meshC
    o+=4*attrC
    o+=20*tsmC
    R['sub_off']=o; o+=16*subC
    o+=10*tssC
    o+=4*matC
    o+=4*boneC
    R['bt_off']=o; o+=4*btC; R['arr_off']=o; o+=2*btTot
    R['shape_off']=o; o+=16*shapeC+12*shapeMeshC+4*shapeValC
    R['sbm_off']=o; sz=struct.unpack_from('<I',d,o)[0]; R['sbm_size']=sz; o+=4+sz
    R['pad_off']=o; pad=d[o]; o+=1+pad
    o+=128+32*boneC
    R['end']=o; R['vb']=h[5]
    R['subs']=[list(struct.unpack_from('<IIIHH',d,R['sub_off']+16*i)) for i in range(subC)]
    R['sbm']=list(struct.unpack_from('<%dH'%(sz//2),d,R['sbm_off']+4))
    R['meshes']=[list(struct.unpack_from('<HHIHHHHI3I3BB',d,R['mesh_off']+36*i)) for i in range(meshC)]
    return R
if __name__=='__main__':
    import sys
    d=open(sys.argv[1],'rb').read(); R=walk(d)
    print('end',R['end'],'vb',R['vb'],'shapes',R['mh'][7:10],'sbm size',R['sbm_size'])
    for i,m in enumerate(R['meshes']): print('mesh',i,'subIdx',m[4],'subCnt',m[5],'tbl',m[6])
    for i,s in enumerate(R['subs'][:20]): print('sub',i,s)
