"""The game's race reshaping (chara/xls/boneDeformer/human.pbd): a men's model (c0101) is shown on other races by
moving every vertex with its bone weights through per-bone 3x4 matrices, race to parent race along a tree
(c0201 Midlander women hang under c0101). deform(model, pbd, skeleton, 'c0201') does the same to a model file, so the
game's own gloves / shoes that exist only as the men's model can be fitted like any women's gear."""
import struct
import numpy as np


def read_pbd(path):
    d = open(path, 'rb').read()
    n = struct.unpack_from('<i', d, 0)[0]
    ent = [struct.unpack_from('<HHif', d, 4 + 12 * i) for i in range(n)]
    o = 4 + 12 * n
    tree = [struct.unpack_from('<hhhh', d, o + 8 * i) for i in range(n)]       # parent, first child, next sibling, deformer
    defs = {}
    for race, ti, off, sc in ent:
        if off == 0:
            defs[race] = {}; continue
        k = struct.unpack_from('<i', d, off)[0]
        so = struct.unpack_from('<%dH' % k, d, off + 4)
        mo = (off + 4 + 2 * k + 3) & ~3
        M = np.array(struct.unpack_from('<%df' % (12 * k), d, mo)).reshape(k, 3, 4)
        names = []
        for s in so:
            p = off + s; e = d.index(b'\0', p); names.append(d[p:e].decode())
        defs[race] = dict(zip(names, M))
    race_of_node = {}
    for race, ti, off, sc in ent:
        race_of_node[ti] = race
    parent = {}
    for ti, (pa, fc, ns, di) in enumerate(tree):
        if ti in race_of_node and pa >= 0 and pa in race_of_node:
            parent[race_of_node[ti]] = race_of_node[pa]
    return defs, parent


def chain(defs, parent, src, dst):
    """the deformers from src's child down to dst (src must be an ancestor of dst)"""
    out = []; r = dst
    while r != src:
        if r not in parent:
            raise ValueError('race %d is not under %d in the deformer tree' % (dst, src))
        out.append(defs[r]); r = parent[r]
    return out[::-1]


def bone_matrix(D, bone, parents):
    b = bone
    while b is not None:
        if b in D: return D[b]
        b = parents.get(b)
    return None


def deform_points(P, W, names, mats_chain, parents):
    """P (n,3) skinned with W (n, len(names)): each deformer of the chain applied in turn (linear blend of the bones'
    3x4 matrices; a bone without one takes its nearest ancestor's, none at all = unchanged)"""
    X = P.copy()
    for D in mats_chain:
        Y = np.zeros_like(X); tot = np.zeros(len(X))
        for j, b in enumerate(names):
            w = W[:, j]
            if not (w > 0).any(): continue
            M = bone_matrix(D, b, parents)
            if M is None: M = np.c_[np.eye(3), np.zeros(3)]
            Y += w[:, None] * (X @ M[:, :3].T + M[:, 3]); tot += w
        X = np.where(tot[:, None] > 0, Y / np.maximum(tot, 1e-9)[:, None], X)
    return X


def skeleton_parents(sklb):
    """bone -> parent bone of a .sklb (havok tagfile)"""
    import tagfile_anim as T
    d = open(sklb, 'rb').read(); i = d.find(b'\x1e\x0d\xb0\xca')
    t = T.Tagfile().load(d[i:])
    cn = lambda o: t.types[o.cls].name if isinstance(o.cls, int) else str(o.cls)
    S = [o for o in t.objs if cn(o) == 'hkaSkeleton'][0]
    names = []
    for b in S.f['bones'][3]:
        n = b.f.get('name'); names.append(n[1] if isinstance(n, tuple) else n)
    par = list(S.f['parentIndices'][3])
    return {n: (names[p] if p >= 0 else None) for n, p in zip(names, par)}


def deform_model(src, out, pbd, sklb, src_race=101, dst_race=201):
    """a whole model file reshaped from src_race to dst_race (positions; normals re-derived from the triangles)"""
    from mdlio import read, write
    from lib import attr
    import surf as S
    defs, parent = read_pbd(pbd)
    ch = chain(defs, parent, src_race, dst_race)
    pars = skeleton_parents(sklb)
    M = read(src); M['meshes'] = [S.upgrade_layout(m) for m in M['meshes'] if m['nv'] > 0]
    for m in M['meshes']:
        P = attr(m, 0)[0][:, :3].astype(float); W = S.dense_w(m)
        X = deform_points(P, W, list(m['table']), ch, pars)
        A = np.frombuffer(m['streams'][0], np.uint8).reshape(m['nv'], -1).copy()
        A[:, 0:12] = X.astype(np.float32).view(np.uint8).reshape(-1, 12)
        m['streams'] = [A.tobytes()] + list(m['streams'][1:])
        if len(m['streams'][1]) == 44 * m['nv']:
            B = np.frombuffer(m['streams'][1], np.uint8).reshape(m['nv'], 44).copy()
            idx = np.frombuffer(m['idx'], np.uint16).astype(int).reshape(-1, 3)
            N = S.vnorm(X, idx) if len(idx) else np.zeros_like(X)
            B[:, 0:12] = N.astype(np.float32).view(np.uint8).reshape(-1, 12)
            m['streams'][1] = B.tobytes()
        m['shapes'] = {}
    write(M, out)
    return out
