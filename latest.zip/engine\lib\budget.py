"""Vertex-budget tools for NIRÆ ports (the game corrupts a model whose vertex data passes 16 MB; port4 stops at 15.5 MB).

compact(M): cloth meshes (not the body skin) take the compact layout: normal half4, uv half4, second uv half2
            (72 -> 56 bytes a vertex); positions, weights, tangents and colours are unchanged.
split(M, prefix, keep): keeps the pieces of one option of an attribute family (atrx_cb_hips_*, or a chest group's
            atrx_cb_chest_* set) and everything without that family; drops the others and the vertices only they used.
            For hips the attribute is removed (the outfit's own Build & Hips option picks the file); chest attributes
            stay (the body still switches the chest inside the group)."""
import numpy as np

LIMIT = int(15.5 * 2 ** 20)
CG = {'s': ('flat', 'small', 'champs', 'smallperky', 'medium', 'earth'), 'l': ('large', 'saggy', 'perky', 'mireya')}


def vb(M):
    return sum(len(s) for m in M['meshes'] for s in m['streams'])


def is_skin(m):
    return 'b0001' in m['mat']


def _decl(elems):
    b = bytearray(136)
    for i, (s, o, t, u, ui) in enumerate(elems):
        b[i * 8:i * 8 + 5] = bytes((s, o, t, u, ui))
    b[len(elems) * 8] = 255
    return bytes(b)


COMPACT = _decl([(0, 0, 2, 0, 0), (0, 12, 17, 1, 0), (0, 20, 17, 2, 0),
                 (1, 0, 14, 3, 0), (1, 8, 8, 6, 0), (1, 12, 8, 7, 0), (1, 16, 14, 4, 0), (1, 24, 13, 4, 1)])
FULL = _decl([(0, 0, 2, 0, 0), (0, 12, 17, 1, 0), (0, 20, 17, 2, 0),
              (1, 0, 2, 3, 0), (1, 12, 8, 6, 0), (1, 16, 8, 7, 0), (1, 20, 3, 4, 0), (1, 36, 1, 4, 1)])


def compact(M):
    """returns bytes saved"""
    import vtx
    saved = 0
    for i, m in enumerate(M['meshes']):
        if not m['nv'] or is_skin(m) or bytes(m['decl'][:72]) != FULL[:72]:
            continue
        data = vtx.decode(m)
        t = dict(m, decl=COMPACT, strides=[28, 28, 0])
        new = [b for b, st in zip(vtx.encode_into(t, data, m['nv']), t['strides']) if st]
        before = sum(len(s) for s in m['streams'])
        m['decl'] = COMPACT; m['strides'] = [28, 28, 0]; m['streams'] = new
        if 'decls' in M and i < len(M['decls']):
            M['decls'][i] = COMPACT
        saved += before - sum(len(s) for s in m['streams'])
    return saved


def _family(a, prefix, keep):
    """None: not of the family; True: of the family and kept; False: of the family, dropped"""
    if not a.startswith(prefix):
        return None
    return a[len(prefix):] in keep


def split(M, prefix, keep, drop_attr):
    """keep = option names (without the prefix); returns dropped vertex count"""
    dropped = 0; meshes = []
    for m in M['meshes']:
        if not m['nv']:
            meshes.append(m); continue
        idx = np.frombuffer(m['idx'], np.uint16).astype(np.int64)
        subs = []
        for sb in m['subs']:
            fam = [_family(a, prefix, keep) for a in sb['attr']]
            fam = [f for f in fam if f is not None]
            if fam and not any(fam):
                continue
            subs.append(sb)
        if len(subs) == len(m['subs']):
            if drop_attr:
                for sb in m['subs']:
                    sb['attr'] = [a for a in sb['attr'] if not a.startswith(prefix)]
            meshes.append(m); continue
        if not subs:
            dropped += m['nv']; continue
        if m['shapes']:
            raise ValueError('cannot split a mesh with shape keys (%s)' % m['mat'])
        parts = [idx[sb['off']:sb['off'] + sb['cnt']] for sb in subs]
        used = np.unique(np.concatenate(parts)) if parts else np.zeros(0, np.int64)
        remap = np.full(m['nv'], -1, np.int64); remap[used] = np.arange(len(used))
        strides = [x for x in m['strides'] if x]
        m['streams'] = [np.frombuffer(s, np.uint8).reshape(m['nv'], st)[used].tobytes() for s, st in zip(m['streams'], strides)]
        dropped += m['nv'] - len(used); m['nv'] = len(used)
        off = 0; chunks = []; ns = []
        for sb, T in zip(subs, parts):
            chunks.append(remap[T].astype(np.uint16))
            ns.append(dict(sb, off=off, cnt=len(T), attr=[a for a in sb['attr'] if not (drop_attr and a.startswith(prefix))]))
            off += len(T)
        m['subs'] = ns; m['idx'] = np.concatenate(chunks).tobytes() if chunks else b''; m['ic'] = off
        meshes.append(m)
    M['meshes'] = meshes
    used_attrs = {a for m in meshes for sb in m['subs'] for a in sb['attr']}
    M['attrs'] = [a for a in M['attrs'] if a in used_attrs or not a.startswith('atrx_')]
    return dropped


def has_family(M, prefix):
    return any(a.startswith(prefix) for m in M['meshes'] for sb in m['subs'] for a in sb['attr'])


def fix_bbox(M, margin=0.001):
    """grows the model's bounding boxes (box 0 down to the floor, box 1 the model) to hold every vertex, shape targets
    included (+1 mm), never smaller: ported cloth reaches past the box the author shipped and would be culled early at
    the screen edge (port4's fix_bbox.py). Returns how much each box grew (mm)"""
    import struct
    import vtx
    lo = np.full(3, np.inf); hi = np.full(3, -np.inf)
    for m in M['meshes']:
        if not m['nv']:
            continue
        P = vtx.decode(m)[(0, 0)][1][:, :3].astype(float)
        lo = np.minimum(lo, P.min(0)); hi = np.maximum(hi, P.max(0))
    bb = bytearray(M['bbox']); grown = []
    for k in (0, 1):
        v = list(struct.unpack_from('<8f', bb, 32 * k)); a = np.array(v[:3]); b = np.array(v[4:7])
        na = np.minimum(a, lo - margin * (lo < a)); nb = np.maximum(b, hi + margin * (hi > b))
        if k == 0:
            na[1] = min(na[1], 0.0)
        grown.append(float(max(np.max(a - na), np.max(nb - b)) * 1000))
        struct.pack_into('<8f', bb, 32 * k, *na, v[3], *nb, v[7])
    M['bbox'] = bytes(bb)
    return grown
