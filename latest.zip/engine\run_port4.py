"""Runs lib/p4/port4.py (BUILD OUT.mdl CFG.json) in this process: the engine starts one per build, because port4 keeps
module-level caches. p4 is the newest port4 of the shared tools (its own surf / pose / vtx); the common readers
(mdlio, lib, unfold) come from lib. python -I does not put the script's folder on sys.path, so both are added here."""
import os, sys, runpy

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, 'lib')
sys.path[:0] = [os.path.join(LIB, 'p4'), LIB]
script = os.path.join(LIB, 'p4', 'port4.py')
sys.argv = [script] + sys.argv[1:]
runpy.run_path(script, run_name='__main__')
