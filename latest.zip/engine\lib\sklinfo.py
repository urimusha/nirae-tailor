"""Read FFXIV sklb (header, layers, havok skeleton) -> dict. PRIVATE helper for Bonebound chain physics."""
import struct, sys
pass
from tagfile_anim import Tagfile
import numpy as np
from scipy.spatial.transform import Rotation as Rot


def layers(d):
    lo = struct.unpack_from('<I', d, 8)[0]
    assert d[lo:lo + 4] == b'hpla'
    nl = struct.unpack_from('<H', d, lo + 4)[0]
    offs = struct.unpack_from('<%dH' % nl, d, lo + 6)
    L = []
    for o in offs:
        lid, cnt = struct.unpack_from('<IH', d, lo + o)
        L.append((lid, list(struct.unpack_from('<%dH' % cnt, d, lo + o + 6))))
    return L


def read(p):
    d = open(p, 'rb').read()
    H = struct.unpack_from('<I', d, 12)[0]
    t = Tagfile(); t.load(d[H:])
    rt = t.save() == d[H:]
    sk = [o for o in t.objs if o.cls == 'hkaSkeleton'][0]
    names = [b.f['name'][1] for b in sk.f['bones'][3]]
    par = list(sk.f['parentIndices'][3]); rp = [tuple(r) for r in sk.f['referencePose'][3]]
    W = []
    for i in range(len(names)):
        r = rp[i]; M = np.eye(4); M[:3, :3] = Rot.from_quat(r[4:8]).as_matrix() * np.array(r[8:11]); M[:3, 3] = r[0:3]
        W.append(M if par[i] < 0 else W[par[i]] @ M)
    hdr = dict(magic=d[0:8], layer_off=struct.unpack_from('<I', d, 8)[0], hav_off=H, connect=struct.unpack_from('<H', d, 16)[0],
               race=struct.unpack_from('<I', d, 20)[0], mappers=struct.unpack_from('<4I', d, 24), connect_ids=struct.unpack_from('<4H', d, 40))
    return dict(d=d, t=t, sk=sk, names=names, par=par, rp=rp, W=np.array(W), hdr=hdr, layers=layers(d), roundtrip=rt)
