# Structured read/write for single-LOD v6 FFXIV .mdl (no element ids / terrain shadow / extra LODs)
import struct
from mdlhdr import walk
LODF='<HHffHHHHHHHHIIIIIIII'
def cstr(b,o): return b[o:b.index(b'\0',o)].decode()
def read(path):
    d=open(path,'rb').read(); R=walk(d); h=list(R['h']); mh=list(R['mh'])
    nd=h[3]; o=0x44+136*nd; sc,ss=struct.unpack_from('<II',d,o); strs=d[o+8:o+8+ss]
    meshC,attrC,subC,matC,boneC,btC,shapeC,smC,svC=mh[1:10]
    assert mh[10]==1 and mh[12]==0 and mh[13]==0 and mh[18]==0 and not (mh[14]&0x10)
    M={'h':h,'mh':mh,'sc':sc}
    M['decls']=[bytes(d[0x44+136*i:0x44+136*(i+1)]) for i in range(nd)]
    lod=list(struct.unpack_from(LODF,d,R['lod_off'])); M['lod']=lod
    M['lodrest']=bytes(d[R['lod_off']+60:R['lod_off']+180])
    vb0,ib0=lod[18],lod[19]
    ao=R['mesh_off']+36*meshC
    M['attrs']=[cstr(strs,x) for x in struct.unpack_from('<%dI'%attrC,d,ao)]
    mo=R['sub_off']+16*subC
    M['mats']=[cstr(strs,x) for x in struct.unpack_from('<%dI'%matC,d,mo)]
    M['bones']=[cstr(strs,x) for x in struct.unpack_from('<%dI'%boneC,d,mo+4*matC)]
    bt=[struct.unpack_from('<HH',d,R['bt_off']+4*i) for i in range(btC)]
    arr=struct.unpack_from('<%dH'%mh[23],d,R['arr_off'])
    M['tables']=[[arr[(4*i+4*a-4*btC)//2+j] for j in range(c)] for i,(a,c) in enumerate(bt)]
    so=R['shape_off']
    shapes=[struct.unpack_from('<I3H3H',d,so+16*i) for i in range(shapeC)]
    sms=[struct.unpack_from('<III',d,so+16*shapeC+12*i) for i in range(smC)]
    svo=so+16*shapeC+12*smC
    svals=[struct.unpack_from('<HH',d,svo+4*i) for i in range(svC)]
    sbm=R['sbm']
    meshes=[]
    for mi,m in enumerate(R['meshes']):
        nv,_,ic,mat,si,sn,tbl,start=m[:8]; offs=m[8:11]; st=m[11:14]; sc_=sum(1 for x in st if x); scb=m[14]
        streams=[bytes(d[vb0+offs[s]:vb0+offs[s]+nv*st[s]]) for s in range(sc_)]
        idx=bytes(d[ib0+2*start:ib0+2*start+2*ic])
        subs=[]
        for s in R['subs'][si:si+sn]:
            subs.append({'off':s[0]-start,'cnt':s[1],'attr':[M['attrs'][k] for k in range(attrC) if s[2]>>k&1],'sbm':list(sbm[s[3]:s[3]+s[4]])})
        meshes.append({'nv':nv,'ic':ic,'mat':M['mats'][mat],'table':[M['bones'][b] for b in M['tables'][tbl]],'streams':streams,'strides':list(st),'idx':idx,'subs':subs,'decl':M['decls'][mi],'shapes':{},'scb':scb})
    for sh in shapes:
        name=cstr(strs,sh[0])
        for k in range(sh[4]):
            smi=sh[1]+k; ms,cnt,vo=sms[smi]
            # find mesh by start index (first with ic>0)
            cand=[i for i,m in enumerate(R['meshes']) if m[7]==ms and m[2]>0] or [i for i,m in enumerate(R['meshes']) if m[7]==ms]
            meshes[cand[0]]['shapes'][name]=svals[vo:vo+cnt]
    M['meshes']=meshes
    po=R['pad_off']; pad=d[po]; bb=po+1+pad
    M['bbox']=bytes(d[bb:bb+128]); M['bonebbox']=[bytes(d[bb+128+32*i:bb+160+32*i]) for i in range(boneC)]
    M['trail']=bytes(d[ib0+R['h'][14]:]) if False else b''
    return M
def write(M,path):
    strs=bytearray(); so={}
    def S(s):
        if s not in so: so[s]=len(strs); strs.extend(s.encode()+b'\0')
        return so[s]
    meshes=M['meshes']
    attrs=list(M['attrs']); [attrs.append(a) for m in meshes for s in m['subs'] for a in s['attr'] if a not in attrs]
    for a in M.get('attrs_keep',[]):
        if a not in attrs: attrs.append(a)
    mats=list(M['mats']); [mats.append(m['mat']) for m in meshes if m['mat'] not in mats]
    bones=list(M['bones']); [bones.append(b) for m in meshes for b in m['table'] if b not in bones]
    shapes=[]; [shapes.append(n) for m in meshes for n in m['shapes'] if n not in shapes]
    # string order: attrs, bones, mats, shapes (like game)
    ao=[S(a) for a in attrs]; bo=[S(b) for b in bones]; mo=[S(m) for m in mats]; sho=[S(s) for s in shapes]
    for x in M.get('extra_strings',[]): S(x)
    while len(strs)%4: strs+=b'\0'
    strs+=b'\0'*4
    # tables: one per mesh
    tabs=[]; arr=[]; bth=[]
    for i,m in enumerate(meshes):
        t=[bones.index(b) for b in m['table']]; tabs.append(t)
    btC=len(tabs); pos=0
    for i,t in enumerate(tabs):
        a=(2*pos+4*btC-4*i)//4; bth.append((a,len(t))); arr+=t; pos+=len(t)
        if len(t)%2: arr.append(0); pos+=1
    # index + vertex buffers
    vb=bytearray(); ib=bytearray(); meshrec=[]; subrec=[]; sbm=[]; smrec=[]; svrec=[]
    shape_sm={n:[] for n in shapes}
    for i,m in enumerate(meshes):
        while (len(ib)//2)%8: ib+=b'\0\0'
        start=len(ib)//2; ib+=m['idx']
        offs=[0,0,0]
        for s,st in enumerate(m['streams']): offs[s]=len(vb); vb+=st
        if not m['streams']: offs=[len(vb)]*3
        si=len(subrec)
        for s in m['subs']:
            mask=sum(1<<attrs.index(a) for a in s['attr'])
            subrec.append((start+s['off'],s['cnt'],mask,len(sbm),len(s['sbm']))); sbm+=s['sbm']
        nsc=len(m['streams'])
        st=list(m['strides'])+[0]*(3-len(m['strides']))
        meshrec.append((m['nv'],0,m['ic'],mats.index(m['mat']),si,len(m['subs']),i,start,*offs,*st[:3],m.get('scb',nsc)))
        m['_start']=start
    for n in shapes:
        for i,m in enumerate(meshes):
            if n in m['shapes']:
                v=m['shapes'][n]; shape_sm[n].append(len(smrec)); smrec.append((m['_start'],len(v),len(svrec))); svrec+=list(v)
    while len(ib)%16: ib+=b'\0'
    # model section
    mh=list(M['mh']); mh[1]=len(meshes); mh[2]=len(attrs); mh[3]=len(subrec); mh[4]=len(mats); mh[5]=len(bones); mh[6]=btC
    mh[7]=len(shapes); mh[8]=len(smrec); mh[9]=len(svrec); mh[23]=len(arr)
    out=bytearray(struct.pack('<f9HBBHBBffHHBBBBHHH6s',*mh))
    lod_pos=len(out)
    lod=list(M['lod']); out+=b'\0'*60+M['lodrest']
    for r in meshrec: out+=struct.pack('<HHIHHHHI3I3BB',*r)
    out+=struct.pack('<%dI'%len(ao),*ao)
    for r in subrec: out+=struct.pack('<IIIHH',*r)
    out+=struct.pack('<%dI'%len(mo),*mo)+struct.pack('<%dI'%len(bo),*bo)
    for a,c in bth: out+=struct.pack('<HH',a,c)
    out+=struct.pack('<%dH'%len(arr),*arr)
    for k,n in enumerate(shapes):
        L=shape_sm[n]; out+=struct.pack('<I3H3H',sho[k],L[0] if L else 0,0,0,len(L),0,0)
    for r in smrec: out+=struct.pack('<III',*r)
    for r in svrec: out+=struct.pack('<HH',*r)
    out+=struct.pack('<I',2*len(sbm))+struct.pack('<%dH'%len(sbm),*sbm)
    nd=len(meshes); hdr_len=0x44+136*nd+8+len(strs)
    pad=(8-((hdr_len+len(out)+1)%8))%8
    out+=bytes([pad])+b'\0'*pad
    out+=M['bbox']
    for b in bones: out+=M['bonebbox_by_name'].get(b,b'\0'*32) if 'bonebbox_by_name' in M else b'\0'*32
    vstart=hdr_len+len(out); istart=vstart+len(vb)
    lod[0]=0; lod[1]=nd
    for k in (4,6,10): lod[k]=nd
    lod[13]=istart; lod[16]=len(vb); lod[17]=len(ib); lod[18]=vstart; lod[19]=istart
    struct.pack_into(LODF,out,lod_pos,*lod)
    h=list(M['h']); h[1]=136*nd; h[2]=len(out)+8+len(strs); h[3]=nd; h[4]=len(mats)
    h[5]=vstart; h[6]=h[7]=istart+len(ib); h[8]=istart; h[9]=h[10]=istart+len(ib); h[11]=len(vb); h[14]=len(ib)
    hdr=struct.pack('<IIIHH3I3I3I3IBBBB',*h)
    decls=b''.join(m['decl'] for m in meshes)
    sc=(M['sc']&0xffff0000)|(len(attrs)+len(bones)+len(mats)+len(shapes))
    final=hdr+decls+struct.pack('<II',sc,len(strs))+bytes(strs)+bytes(out)+bytes(vb)+bytes(ib)
    open(path,'wb').write(final); return len(final)
def bonebbox_map(M): return dict(zip(M['bones'],M['bonebbox']))
if __name__=='__main__':
    import sys
    M=read(sys.argv[1]); M['bonebbox_by_name']=bonebbox_map(M); n=write(M,sys.argv[2]); print('wrote',n)
