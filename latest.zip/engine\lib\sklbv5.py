import numpy as np,struct,re,sys
pass
import sklb2
def vint(d,o):
    b=d[o];o+=1;neg=b&1;v=(b&0x7E)>>1;pos=6
    while b&0x80: b=d[o];o+=1;v|=(b&0x7F)<<pos;pos+=7
    return (-v if neg else v),o
def parse(path):
    n,_,T,Q,S=sklb2.parse(path); N=len(n); d=open(path,'rb').read(); st=d.find(b'n_root')
    for s0 in range(max(0,st-6*N),st):
        o=s0; vals=[]
        try:
            for k in range(N): v,o=vint(d,o); vals.append(v)
        except IndexError: continue
        if vals[0]==-1 and all(-1<=vals[k]<k for k in range(1,N)) and vals[1]==0:
            return n,vals,T,Q,S
    raise ValueError('no parents')
