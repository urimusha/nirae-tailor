import struct
VOID,BYTE,INT,REAL,VEC4,VEC8,VEC12,VEC16,OBJ,STRUCT,CSTR=range(11)
ARR,TUP=16,32
class R:
    def __init__(s,d): s.d=d; s.o=8
    def byte(s): b=s.d[s.o]; s.o+=1; return b
    def vint(s):
        b=s.byte(); neg=b&1; v=(b&0x7E)>>1; pos=6
        while b&0x80: b=s.byte(); v|=(b&0x7F)<<pos; pos+=7
        return -v if neg else v
    def raw(s,n): x=s.d[s.o:s.o+n]; s.o+=n; return x
    def f32(s): return struct.unpack('<f',s.raw(4))[0]
class W:
    def __init__(s): s.b=bytearray(struct.pack('<II',0xCAB00D1E,0xD011FACE))
    def byte(s,x): s.b.append(x)
    def vint(s,v):
        neg=v<0; v=abs(v); s.b.append(((v&0x3F)<<1)|neg|(0x80 if v>>6 else 0)); v>>=6
        while v: s.b.append((v&0x7F)|(0x80 if v>>7 else 0)); v>>=7
    def raw(s,x): s.b+=x
    def f32(s,x): s.b+=struct.pack('<f',x)
class Type:
    def __init__(s,name,ver,parent,members): s.name,s.ver,s.parent,s.members=name,ver,parent,members
class Obj:
    def __init__(s,cls): s.cls=cls; s.f={}   # field values; missing = not present
    def __repr__(s): return '<%s>'%s.cls
class Tagfile:
    def __init__(s): s.types=[Type('void',0,0,[('void',0,0,'')])]; s.lookup={}; s.objs=[]; s.version=3; s.hkver=None
    # ---------- reading
    def rstr(s,r):
        n=r.vint()
        if n<=0: return s.pool[-n]
        x=r.raw(n).decode(); s.pool.append(x); return x
    def allm(s,ci):
        chain=[]; t=ci
        while t: chain.append(t); t=s.types[t].parent
        out=[]
        for t in reversed(chain): out+=s.types[t].members
        return out
    def load(s,d):
        r=R(d); s.order=[]; s.refs={}
        while True:
            tag=r.vint()
            if tag==1:
                s.version=r.vint(); s.pool=['',None]
                if s.version>=4: s.hkver=s.rstr(r)
                s.v5extra=r.raw(6) if s.version>=5 else b''
            elif tag==2:
                name=s.rstr(r); ver=r.vint(); par=r.vint(); n=r.vint(); mem=[]
                for _ in range(n):
                    mn=s.rstr(r); mt=r.vint(); tup=r.vint() if mt&TUP else 0
                    cn=s.rstr(r) if (mt&15) in (OBJ,STRUCT) else ''
                    mem.append((mn,mt,tup,cn))
                s.types.append(Type(name,ver,par,mem)); s.lookup[name]=len(s.types)-1
                s.order.append(('T',len(s.types)-1))
            elif tag==4:
                idx=len(s.objs)+1
                o=s.refs.get(idx) or Obj(None); s.refs[idx]=o; s.objs.append(o)
                s.rstruct(r,0,o); s.order.append(('O',idx))
            elif tag==7: break
            else: raise ValueError('tag %d at %d'%(tag,r.o))
        s.tail=d[r.o:]
        return s
    def rstruct(s,r,ci,o):
        if ci==0: ci=r.vint()
        o.cls=s.types[ci].name; o.ci=ci
        mem=s.allm(ci); bm=r.raw((len(mem)+7)//8)
        for i,m in enumerate(mem):
            if bm[i//8]>>(i%8)&1: o.f[m[0]]=s.rfield(r,m)
        return o
    def rfield(s,r,m):
        mn,mt,tup,cn=m
        if mt==(TUP|BYTE): return ('bytes',r.raw(tup))
        if mt==(ARR|BYTE): return ('bytes',r.raw(r.vint()))
        if mt&(TUP|ARR):
            n=tup if mt&TUP else r.vint()
            return s.rarray(r,m,n)
        return s.rval(r,mt&15,cn,-1)
    def rarray(s,r,m,n):
        mn,mt,tup,cn=m; bt=mt&15; pre=-1
        if bt==STRUCT:
            ci=s.lookup[cn] if cn else r.vint()
            mem=s.allm(ci); bm=r.raw((len(mem)+7)//8)
            items=[Obj(s.types[ci].name) for _ in range(n)]
            for it in items: it.ci=ci
            cols={}
            for i,mm in enumerate(mem):
                if bm[i//8]>>(i%8)&1:
                    pre,vals=s.rcol(r,mm,n); cols[mm[0]]=pre
                    for it,v in zip(items,vals): it.f[mm[0]]=v
            return ('sarr',ci,bytes(bm),items,cols,cn=='')
        if bt in (INT,VEC4): pre=r.vint()
        return ('arr',bt,pre,[s.rval(r,bt,cn,pre) for _ in range(n)])
    def rcol(s,r,mm,n):
        mn,mt,tup,cn=mm
        if mt in (TUP|BYTE,ARR|BYTE) or mt&(TUP|ARR): return None,[s.rfield(r,mm) for _ in range(n)]
        bt=mt&15
        if bt==STRUCT:
            x=s.rarray(r,(mn,ARR|STRUCT,0,cn),n); return ('S',x[1],x[2],x[4],x[5]),x[3]
        pre=r.vint() if bt in (INT,VEC4) else -1
        return pre,[s.rval(r,bt,cn,pre) for _ in range(n)]
    # ---------- writing
    def wstr(s,w,x):
        if x in s.wpool: w.vint(-s.wpool.index(x)); return
        b=x.encode(); w.vint(len(b)); w.raw(b); s.wpool.append(x)
    def save(s):
        w=W(); w.vint(1); w.vint(s.version); s.wpool=['',None]
        if s.version>=4: s.wstr(w,s.hkver)
        w.raw(getattr(s,'v5extra',b''))
        for kind,i in s.order:
            if kind=='T':
                t=s.types[i]; w.vint(2); s.wstr(w,t.name); w.vint(t.ver); w.vint(t.parent); w.vint(len(t.members))
                for mn,mt,tup,cn in t.members:
                    s.wstr(w,mn); w.vint(mt)
                    if mt&TUP: w.vint(tup)
                    if (mt&15) in (OBJ,STRUCT): s.wstr(w,cn)
            else:
                w.vint(4); s.wstruct(w,s.objs[i-1],True)
        w.vint(7); w.raw(s.tail); return bytes(w.b)
    def wstruct(s,w,o,writeci):
        if writeci: w.vint(o.ci)
        mem=s.allm(o.ci); bm=bytearray((len(mem)+7)//8)
        for i,m in enumerate(mem):
            if m[0] in o.f: bm[i//8]|=1<<(i%8)
        w.raw(bytes(bm))
        for m in mem:
            if m[0] in o.f: s.wfield(w,m,o.f[m[0]])
    def wfield(s,w,m,v):
        mn,mt,tup,cn=m
        if mt==(TUP|BYTE): w.raw(v[1]); return
        if mt==(ARR|BYTE): w.vint(len(v[1])); w.raw(v[1]); return
        if mt&(TUP|ARR):
            n=len(v[3])
            if not mt&TUP: w.vint(n)
            s.warray(w,m,v); return
        s.wval(w,mt&15,cn,-1,v)
    def warray(s,w,m,v):
        if v[0]=='sarr':
            _,ci,bm,items,cols,wci=v
            if wci: w.vint(ci)
            mem=s.allm(ci); bm=bytearray((len(mem)+7)//8)
            for i,mm in enumerate(mem):
                if mm[0] in cols: bm[i//8]|=1<<(i%8)
            w.raw(bytes(bm))
            for mm in mem:
                if mm[0] in cols: s.wcol(w,mm,cols[mm[0]],[it.f[mm[0]] for it in items])
            return
        _,bt,pre,vals=v
        if bt in (INT,VEC4): w.vint(pre)
        for x in vals: s.wval(w,bt,m[3],pre,x)
    def wcol(s,w,mm,pre,vals):
        mn,mt,tup,cn=mm
        if pre is None:
            for x in vals: s.wfield(w,mm,x)
            return
        bt=mt&15
        if bt==STRUCT:
            _,ci,bm,cols,wci=pre; s.warray(w,mm,('sarr',ci,bm,vals,cols,wci)); return
        if bt in (INT,VEC4): w.vint(pre)
        for x in vals: s.wval(w,bt,cn,pre,x)
    def wval(s,w,bt,cn,pre,v):
        if bt==BYTE: w.byte(v); return
        if bt==INT: w.vint(v); return
        if bt==REAL: w.f32(v); return
        if bt in (VEC4,VEC12,VEC16):
            for x in v: w.f32(x)
            return
        if bt==OBJ: w.vint(0 if v is None else v[1]); return
        if bt==STRUCT: s.wstruct(w,v,not cn); return
        if bt==CSTR: s.wstr(w,v[1]); return
        raise ValueError(bt)
    def rval(s,r,bt,cn,pre):
        if bt==BYTE: return r.byte()
        if bt==INT: return r.vint()
        if bt==REAL: return r.f32()
        if bt==VEC4:
            k=4 if pre<0 else pre; return tuple(r.f32() for _ in range(k))
        if bt==VEC12: return tuple(r.f32() for _ in range(12))
        if bt==VEC16: return tuple(r.f32() for _ in range(16))
        if bt==OBJ:
            i=r.vint()
            if i==0: return None
            o=s.refs.get(i)
            if o is None: o=Obj(None); s.refs[i]=o
            return ('ref',i)
        if bt==STRUCT:
            o=Obj(None); ci=s.lookup[cn] if cn else 0; return s.rstruct(r,ci,o)
        if bt==CSTR: return ('str',s.rstr(r))
        raise ValueError(bt)
