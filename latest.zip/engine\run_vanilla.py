"""Vanilla gear helpers in their own process (NIRÆ's body files come from LP_NIRAE_BUILDS like port4):
  run_vanilla.py body VTOP.mdl VDWN.mdl OUT.npz   the vanilla author body (lib/vanillabody.py)
  run_vanilla.py subdiv SRC.mdl OUT.mdl [LEVELS]  the gear smoothly subdivided (lib/subdiv.py), skin pieces as they are
  run_vanilla.py handfeet SLOT SRC.mdl AUTHOR.mdl NIRAE_PART.mdl OUT.mdl [vanilla]   gloves / shoes (lib/handfeet.py)"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, 'lib')
sys.path[:0] = [os.path.join(LIB, 'p4'), LIB]

if sys.argv[1] == 'body':
    import vanillabody
    log = []
    vanillabody.build(sys.argv[2], sys.argv[3], sys.argv[4], log)
    print('\n'.join(log))
    print('wrote', sys.argv[4])
elif sys.argv[1] == 'handfeet':
    import json, handfeet
    log = []
    rep = handfeet.port(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], log, vanilla=len(sys.argv) > 7 and sys.argv[7] == 'vanilla')
    print('\n'.join(log))
    print('\n' + json.dumps(rep))
elif sys.argv[1] == 'subdiv':
    # subdiv SRC OUT [LEVELS] [auto]: 'auto' (mod outfits) only smooths coarse pieces (median edge over 20 mm) that are
    # in the 8-weight layout already; without it (vanilla gear) every cloth piece is converted and smoothed
    import numpy as np, surf, subdiv
    from mdlio import read, write
    from lib import attr
    auto = len(sys.argv) > 5 and sys.argv[5] == 'auto'
    M = read(sys.argv[2])
    lv = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    out = []; changed = 0
    for m in M['meshes']:
        if m['nv'] == 0:
            continue
        if surf.is_skin(m) or lv <= 0:
            out.append(m if auto else surf.upgrade_layout(m)); continue
        if auto:
            F = np.frombuffer(m['idx'], np.uint16).astype(int).reshape(-1, 3); P = attr(m, 0)[0][:, :3]
            el = float(np.median(np.linalg.norm(P[F[:, 0]] - P[F[:, 1]], axis=1)))
            mu = surf.upgrade_layout(m)
            ok = list(mu.get('strides', [28, 44])[:2]) == [28, 44] and len(mu['streams'][0]) == 28 * mu['nv'] and len(mu['streams'][1]) == 44 * mu['nv']
            if el < 0.020 or not ok:
                out.append(m); continue
            m = mu
        else:
            m = surf.upgrade_layout(m)
        m2, k = subdiv.subdivide(m, levels=lv)
        print('%s: %d -> %d vertices (%d levels)' % (m['mat'], m['nv'], m2['nv'], k))
        changed += k > 0
        out.append(m2)
    if auto and not changed:
        print('nothing coarse: unchanged')
    else:
        M['meshes'] = out
        write(M, sys.argv[3])
        print('wrote', sys.argv[3])
