"""NIRÆ Tailor fitting engine (PRIVATE use): converts outfit models between bodies for the Dalamud plugin.

python -I -X utf8 lp_engine.py JOB.json
JOB = {
  "direction": "nirae2lala",                        # (later: "lala2nirae", "body2nirae")
  "nirae": {"build": "curvy", "hips": "medium", "chest": "earth", "belly": "soft"},   # the source outfit's NIRÆ options
  "items": [{"slot": "top", "src": "...mdl", "out": "...mdl"}, ...],                   # slots: top dwn glv sho
  "skeletons": ["...skl_c0201t7207.sklb"],          # extra (EST) skeletons the source wears: their bones fold onto
                                                    # the standard bone they hang from instead of the waist
  "pieces": true,                                   # one switch attribute per cloth piece
  "cache": "folder for body maps", "result": "result.json"
}
Progress goes to stdout as one JSON object per line ({"stage": ..., "slot": ..., "msg": ...}); the result file lists
per item the written model, its materials (race-coded names renamed: old -> new), its pieces (attribute + name) and its
attributes, or an "error" for that item (the others still finish). Paths of the bodies come from the environment (see
engine_build.py): LP_MODS, LP_NIRAE_STANDALONE, LP_FLUX_DIR, LP_SKEL_TALL, LP_SKEL_LALA."""
import sys, os, json, re, time, hashlib, traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'lib'))
ENGINE_VERSION = 3
MAP_VERSION = 2          # part of the body-map cache key: bump only when the body fit itself changes


def say(**kw):
    print(json.dumps(kw), flush=True)


class Stream(list):
    """a log list that also streams every line to the plugin"""

    def append(self, x):
        super().append(x)
        s = str(x).rstrip()
        if s: say(stage='log', msg=s[:300])

    def extend(self, xs):
        for x in xs: self.append(x)


RACE = re.compile(r'c\d{4}')


def neutral_material(name):
    """'/mt_c0201e6233_top_a.mtrl' -> '/mt_nt_e6233_top_a.mtrl': no race code, so the game does not swap it for the
    target race (the managed mod provides it under this name in the item's material folder)"""
    base = name.split('/')[-1]
    if not RACE.search(base): return name
    return '/' + RACE.sub('nt', base, count=1).replace('mt_nt', 'mt_nt_', 1).replace('mt_nt__', 'mt_nt_')


def material_list(M):
    out = []
    for m in M['meshes']:
        if m['nv'] and m['mat'] not in out: out.append(m['mat'])
    return out


def rename_materials(M, is_body):
    """renames race-coded cloth materials; body (skin) materials keep their full paths"""
    ren = {}
    for m in M['meshes']:
        if not m['nv'] or is_body(m['mat']): continue
        new = neutral_material(m['mat'])
        if new != m['mat']:
            ren[m['mat']] = new; m['mat'] = new
    if 'mats' in M:
        M['mats'] = [ren.get(x, x) for x in M['mats']]
    return ren


def auto_pieces(M, slot, is_body, order=None):
    """one toggle per cloth material (shells _fur1.._fur3 go with their base). Returns [(attribute, name, materials)].
    order: the stems of every file of one item (sorted), so each piece gets the same attribute in all of them"""
    import pieces as PC
    from lib import attr
    groups = {}
    for m in M['meshes']:
        if not m['nv'] or is_body(m['mat']): continue
        stem = re.sub(r'(_fur)\d(\.mtrl)$', r'\1\2', m['mat'].split('/')[-1])
        groups.setdefault(stem, []).append(m['mat'])
    if order is not None:
        for st in order: groups.setdefault(st, [])
    out = []; rules = []
    # display names: the material name without mt_ / race code / item number, the outfit's own prefix shared by all
    # its materials ('ohbb') and the slot word ('top'): 'mt_ohbb_top_coat.mtrl' -> 'coat'
    toks = {stem: [t for t in re.sub(r'e\d{4}', '', re.sub(r'^mt_(nt_|c\d{4})?', '', stem[:-5])).split('_') if t] for stem in groups}
    first = {t[0] for t in toks.values() if t}
    shared = first.pop() if len(first) == 1 and len(groups) > 1 else None
    for k, (stem, mats) in enumerate(sorted(groups.items())):
        a = 'atrx_nt_%s_%d' % (slot, k + 1)
        t = [x for i, x in enumerate(toks[stem]) if not (i == 0 and x == shared) and x not in ('top', 'dwn', 'glv', 'sho', 'met')]
        nm = ' '.join(t) or ' '.join(toks[stem]) or stem
        if len(nm) <= 2: nm = 'part ' + nm
        out.append((a, nm, sorted(set(mats))))
        if mats: rules.append((PC.mat_is(*set(mats)), PC.all_tris, a))
    PC.tag(M, rules, lambda m: attr(m, 0)[0][:, :3].astype(float))
    return out


def _newest(folder, rx):
    best = None
    for f in os.listdir(folder):
        mm = re.fullmatch(rx, f)
        if mm and (best is None or int(mm.group(1)) > best[0]): best = (int(mm.group(1)), f)
    return best[1] if best else None


def resolve_bodies(log):
    """the NIRÆ body files the engine was validated with, or the newest version on disk when those are gone;
    returns a short signature of every body file used (part of the cache key)"""
    import surf as S
    files = []
    for b in list(S.BUILDS):
        top, _ = S.BUILDS[b]
        if not os.path.exists(S.CB + top):
            n = _newest(S.CB, r'c0201e0000_top_crimson_%s_v(\d+)\.mdl' % b)
            if n: log.append('NIRÆ %s top: %s (newest on disk)' % (b, n)); top = n
        for h in ('small', 'medium', 'large'):
            f = S.HIPSF[b][h]
            if not os.path.exists(S.CB + f):
                n = _newest(S.CB, r'c0201e0000_dwn_crimson_%s_%s_v(\d+)\.mdl' % (b, h))
                if n: log.append('NIRÆ %s %s hips: %s (newest on disk)' % (b, h, n)); S.HIPSF[b][h] = n
        S.BUILDS[b] = (top, S.HIPSF[b]['medium'])
        files += [S.CB + top] + [S.CB + S.HIPSF[b][h] for h in ('small', 'medium', 'large')]
    import mapbody as MB, lalaskel as LK
    for f in sorted(os.listdir(MB.FLUXD)):
        if f.endswith(('.mdl', '.sklb')): files.append(MB.FLUXD + f)
    files += [LK.SRC, LK.DST]
    h = hashlib.sha1()
    for f in files:
        if os.path.exists(f): h.update(('%s:%d;' % (os.path.basename(f), os.path.getsize(f))).encode())
        else: h.update(('%s:missing;' % os.path.basename(f)).encode())
    h.update(b'engine%d' % MAP_VERSION)
    return h.hexdigest()[:10]


def extra_skeletons(paths, log):
    """bones of the source's extra (EST) skeletons hang from standard bones: register their parents so their weights
    fold onto that bone"""
    import mapbody as MB, sklbx
    n0 = len(MB.parA)
    for p in paths or []:
        try:
            for b, pb in sklbx.parents(p).items():
                if b not in MB.parA and pb is not None: MB.parA[b] = pb
        except Exception as e:
            log.append('extra skeleton %s not read: %s' % (os.path.basename(p), e))
    if len(MB.parA) > n0: log.append('extra skeleton bones: %d (folded onto the bones they hang from)' % (len(MB.parA) - n0))


def prepare_extra(job, log):
    """extra (EST) skeletons to port to the Lalafell (their physics bones stay on the cloth): checks each one can be
    rebuilt (its file round-trips, its roots exist in the Lalafell skeleton) BEFORE the fit; returns the usable ones"""
    import mapbody as MB, lalaport as LP, extraskel as X, sklinfo, lalaskel as LK
    from tagfile_anim import Tagfile
    import struct
    L = sklinfo.read(LK.DST)
    usable = []
    for ex in job.get('extra') or []:
        try:
            d = open(ex['skeleton'], 'rb').read(); H = struct.unpack_from('<I', d, 12)[0]
            t = Tagfile(); t.load(d[H:])
            if t.save() != d[H:]: raise ValueError('the skeleton file does not round-trip')
            S, bones = X.extra_bones(ex['skeleton'])
            roots = [n for n, p_ in zip(S['names'], S['par']) if p_ < 0]
            miss = [r for r in roots if r not in L['names']]
            if miss: raise ValueError('roots %s are not in the Lalafell skeleton' % miss)
            if not bones: raise ValueError('no bones of its own')
            MB.STD |= set(bones); LP.KEEP_EXTRA |= set(bones)
            for b, p_ in zip(S['names'], S['par']):
                if p_ >= 0: MB.parA.setdefault(b, S['names'][p_])
            usable.append(dict(ex, S=S, bones=bones))
            log.append('extra skeleton t%04d: %d bones kept for the Lalafell (%s)' % (ex['est'], len(bones), ', '.join(bones[:6]) + (' ...' if len(bones) > 6 else '')))
        except Exception as e:
            log.append('extra skeleton %s not ported (%s): its bones fold onto the bones they hang from' % (os.path.basename(ex.get('skeleton', '?')), e))
    return usable


def root_of(b, S):
    """the root (a base skeleton bone) an extra bone hangs from"""
    i = S['names'].index(b)
    while S['par'][i] >= 0: i = S['par'][i]
    return S['names'][i]


def fold_bones(done, mapping, log):
    """renames bones in the written models' bone tables (vertices keep their weights, now on the target bone)"""
    from surf import read
    from mdlio import write
    for slot, items, out in done:
        M = read(out); n = 0
        for m in M['meshes']:
            if any(b in mapping for b in m['table']):
                m['table'] = [mapping.get(b, b) for b in m['table']]; n += 1
        if n:
            write(M, out); log.append('%s: %d meshes had their own physics bones folded onto %s' % (slot, n, sorted(set(mapping.values()))))


def build_extra(usable, done, mapfile, outdir, log):
    """after the fit: the Lalafell version of each usable extra skeleton (bind pose fitted to the ported cloth) and of
    its physics files"""
    import numpy as np
    import extraskel as X, sklinfo, lalaskel as LK
    L = sklinfo.read(LK.DST); T = sklinfo.read(LK.SRC)
    base_lala = {n: L['W'][i] for i, n in enumerate(L['names'])}
    items = [it for _, its, _ in done for it in its]
    skin = None
    if mapfile and os.path.exists(mapfile):
        Z = np.load(mapfile, allow_pickle=True); skin = (Z['P'], Z['Q'], Z['W'], list(Z['names']))
    out = []
    for ex in usable:
        S = ex['S']; est = int(ex['est']); x = 'm' if ex.get('slot') == 'met' else 't'
        fits = X.bone_fits(items, ex['bones'])
        W, scale, how = X.lala_world(S, fits, base_lala)
        sk_out = os.path.join(outdir, 'skl_c1201%s%04d.sklb' % (x, est))
        rep = X.write_sklb(ex['skeleton'], W, 1201, L['names'], sk_out)
        log.append('extra skeleton %s%04d for the Lalafell: %d of %d bones fitted to the cloth they carry (scale %s), rebuilt within %.1e m' % (
            x, est, sum(1 for h in how.values() if h == 'fit'), len(ex['bones']),
            '%.2f-%.2f' % (min(f[1] for f in fits.values()), max(f[1] for f in fits.values())) if fits else '-', rep['max_world_err']))
        src_extra = {n: S['W'][i] for i, n in enumerate(S['names'])}
        ext_parent = {n: (S['names'][p] if p >= 0 else None) for n, p in zip(S['names'], S['par'])}
        phys = {}
        for k, path in (ex.get('phyb') or {}).items():
            try:
                lg = []
                data, _ = X.adapt_phyb(open(path, 'rb').read(), (T['names'], T['par'], T['W']), (L['names'], L['par'], L['W']),
                                       src_extra, W, scale, ext_parent, skin=skin, log=lg)
                fo = os.path.join(outdir, 'phy_c1201%s%04d_%d.phyb' % (x, est, len(phys)))
                open(fo, 'wb').write(data); phys[k] = fo
                log.append('physics %s adapted' % os.path.basename(path)); log.extend(lg)
            except Exception as e:
                log.append('physics %s not adapted: %s' % (os.path.basename(path), e))
        out.append(dict(slot=ex.get('slot', 'top'), est=est, skeleton=sk_out, phyb=phys, bones=ex['bones'],
                        fitted=[b for b, h in how.items() if h == 'fit']))
    return out


def cross_layers(done, log, rounds=4, together=()):
    """layer order BETWEEN slots (each slot is fitted on its own): wherever a piece of one slot lay over a piece of
    another in the source (the coat over the shorts' waist rings), the port keeps it over by at least
    clip(0.8 x source gap, 0.6, 3) mm. Heights are measured along the skin normal (the NIRÆ skin in the source, the
    FluxHD2 skin in the port), so the cloth's own winding does not matter; the outer piece rises locally with a smooth
    bump (a solid part as a whole). done: [(slot, items, out)]; changed models are written again.
    Returns {slot: max lift in mm}"""
    import numpy as np
    import lalaport as LP
    from surf import read
    from mdlio import write
    from scipy.spatial import cKDTree
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    unit = LP.unit
    B = LP.flux_collider('top')
    S = []
    for slot, items, out in done:
        col = [it for it in items if not it['shell']]
        if not col: continue
        offs = np.cumsum([0] + [len(it['V0']) for it in col])
        cat = lambda k: np.concatenate([it[k] for it in col])
        V0 = cat('V0'); P = cat('P'); I = np.concatenate([it['I'] + o for it, o in zip(col, offs)])
        key = np.unique(np.round(V0 / 2e-5).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
        nk = key.max() + 1
        E = np.concatenate([I[:, [0, 1]], I[:, [1, 2]]])
        lab = connected_components(coo_matrix((np.ones(len(E)), (key[E[:, 0]], key[E[:, 1]])), shape=(nk, nk)), directed=False)[1][key]
        S.append(dict(slot=slot, items=items, col=col, offs=offs, V0=V0, P=P, P0=P.copy(), I=I, key=key, lab=lab,
                      rig=cat('rigid'), off=cat('off'), sn=LP.unit(cat('sn')), out=out))
    if len(S) < 2: return {}
    # source pairs: a vertex of b right over / under a triangle of a along b's skin normal (<= 2 cm, foot point
    # within 2 mm sideways); height difference from the NIRÆ skin offsets
    pairs = []
    for a in S:
        Sa = LP.surf_of(a['V0'], a['I'])
        for b in S:
            if a is b or (a['slot'] in together and b['slot'] in together): continue
            t, w, q, d = Sa.closest(b['V0'])
            dv = b['V0'] - q; al = np.einsum('nd,nd->n', dv, b['sn'])
            lat = np.linalg.norm(dv - al[:, None] * b['sn'], axis=1)
            h0 = b['off'] - np.einsum('ni,ni->n', w, a['off'][a['I'][t]])
            sel = np.where((d < 0.02) & (lat < 0.002) & (np.abs(h0) > 3e-4) & (np.sign(h0) == np.sign(al)))[0]
            if len(sel): pairs.append((a, b, sel, t[sel], w[sel], h0[sel]))
    if not pairs: return {}

    def measure():
        for x in S:
            tq, wq, qq, dq = B.closest(x['P']); n_ = B.nrm(tq, wq)
            x['sd'] = np.einsum('nd,nd->n', x['P'] - qq, n_); x['n'] = unit(B.at(tq, wq, B.Ns))
        out = []
        for a, b, v, t, w, h0 in pairs:
            ha = np.einsum('ni,ni->n', w, a['sd'][a['I'][t]]); hb = b['sd'][v]
            out.append(np.where(h0 < 0, ha - hb, hb - ha))       # + = the source order, in m
        return out

    sep0 = measure()
    # pieces the fit already crossed by more than 6 mm are structural (a strap through a ring, a mapping that slid a
    # part past another): they are not chased
    keep = [s_ > -0.006 for s_ in sep0]
    dropped = int(sum((~k).sum() for k in keep))
    pairs = [(a, b, v[k], t[k], w[k], h0[k]) for (a, b, v, t, w, h0), k in zip(pairs, keep)]
    sep0 = [s_[k] for s_, k in zip(sep0, keep)]
    crossed0 = int(sum((s_ < 0).sum() for s_ in sep0))
    tot = {id(x): np.zeros(len(x['V0'])) for x in S}
    for rnd in range(rounds):
        sep = measure() if rnd else sep0
        lift = {id(x): np.zeros(len(x['V0'])) for x in S}
        worst = 0.0
        for (a, b, v, t, w, h0), s_ in zip(pairs, sep):
            tgt = np.clip(0.5 * np.abs(h0), 3e-4, 1.5e-3)
            need = np.minimum(tgt - s_, 0.003)
            m = need > 2e-5
            if not m.any(): continue
            worst = max(worst, need[m].max())
            under = h0 < 0                                    # b was under a: a rises; else b rises
            Ta = a['I'][t]
            for k in range(3):
                mm = m & under
                np.maximum.at(lift[id(a)], Ta[mm, k], need[mm])
            mm = m & ~under
            np.maximum.at(lift[id(b)], v[mm], need[mm])
        if worst < 2e-5: break
        for x in S:
            L = np.minimum(lift[id(x)], np.maximum(0.006 - tot[id(x)], 0))   # at most 6 mm in all
            if not L.any(): continue
            L = np.maximum(LP.bumps(x['P'], L, elen=LP.edge_len(x['P'], x['I'])), L)
            L = np.minimum(L, np.maximum(0.006 - tot[id(x)], 0))
            Lk = np.zeros(x['key'].max() + 1); np.maximum.at(Lk, x['key'], L); L = Lk[x['key']]
            nn = x['n'].copy()
            for c in np.unique(x['lab'][x['rig'] & (L > 0)]):          # solid parts rise as a whole
                k = x['lab'] == c
                L[k] = L[k].max(); nn[k] = unit(nn[k].mean(0))
            x['P'] = x['P'] + L[:, None] * nn; tot[id(x)] += L
    sep1 = measure()
    crossed1 = int(sum((s_ < 0).sum() for s_ in sep1))
    log.append('cross-slot layers: %d source pairs, %d structural dropped; crossed %d -> %d' % (sum(len(p_[2]) for p_ in pairs), dropped, crossed0, crossed1))
    res = {}
    for x in S:
        mv = np.linalg.norm(x['P'] - x['P0'], axis=1)
        if mv.max() < 1e-6: continue
        res[x['slot']] = round(float(mv.max()) * 1000, 2)
        for k, it in enumerate(x['col']):
            it['P'] = x['P'][x['offs'][k]:x['offs'][k + 1]]
        for it in x['items']:                                # fur shells follow their base
            if not it['shell']: continue
            stem = re.sub(r'\d\.mtrl$', '.mtrl', it['mat'])
            cand = [c for c in x['col'] if c['mat'] == stem and c['mi'] < it['mi'] and len(c['V0']) == len(it['V0'])]
            if cand:
                bse = max(cand, key=lambda c: c['mi']); it['P'] = it['V0'] + (bse['P'] - bse['V0'])
        M = read(x['out'])
        built = [LP.cloth_mesh(it) for it in x['items']]
        nf = len(M['meshes']) - len(built)
        for k, mm in enumerate(built): M['meshes'][nf + k] = mm
        write(M, x['out'])
        log.append('cross-slot layers: %s raised up to %.1f mm (%d verts over 0.1 mm)' % (x['slot'], mv.max() * 1000, int((mv > 1e-4).sum())))
    return res


def nirae2lala(job, log):
    import mapbody as MB
    import lalaport as LP
    from surf import read
    from mdlio import write
    import numpy as np
    no = job.get('nirae', {})
    MB.NIRAE.update(build=no.get('build', 'curvy'), hips=no.get('hips', 'medium'))
    LP.SEL.update(chest=no.get('chest', 'earth'), belly=no.get('belly', 'soft'), hips=MB.NIRAE['hips'])
    LP.DROP_ATTRS = set()
    sig = resolve_bodies(log)
    extra_skeletons(job.get('skeletons'), log)
    lg = Stream(); usable = prepare_extra(job, lg); log.extend(lg)          # streamed: the plugin shows these lines
    maps_used = []
    cache = job.get('cache') or os.path.join(HERE, 'cache'); os.makedirs(cache, exist_ok=True)
    res = []; done = []
    is_body = lambda mat: any(x in mat for x in ('fluxhd', 'c1101b0001', 'c1201b0001', 'e0000'))

    def map_file(kind, src=None):
        if kind == 'body':
            name = 'map_n2l2_%s_%s_%s_%s_%s.npz' % (MB.NIRAE['build'], MB.NIRAE['hips'], LP.SEL['chest'], LP.SEL['belly'], sig)
        else:
            h = hashlib.sha1(open(src, 'rb').read()).hexdigest()[:12]
            name = 'map_n2l_%s_%s_%s.npz' % (kind, h, sig)
        p = os.path.join(cache, name)
        if os.path.exists(p): return p
        say(stage='map', msg='fitting the NIRÆ %s to the Lalafell (first time only, a few minutes)' % ('body' if kind == 'body' else kind))
        lg = Stream()
        if kind == 'body':
            A, Wa, na, Y, (maps, cyl, limbs), X1, X2 = MB.run(LP.SEL['chest'], LP.SEL['belly'], 'vanilla', lg)
        else:
            A, Wa, na, Y, (maps, cyl, limbs), X1, X2 = MB.run_part(kind, lg)
        t, w, Q, d = Y.closest(X2)
        tmp = p + '.tmp.npz'
        np.savez_compressed(tmp, P=A.P, T=A.T, N=A.Nst, fsign=A.fsign, part=A.part, W=Wa, names=np.array(na), X1=X1, X2=X2, Q=Q, d=d,
                            maps=np.array([maps[b] for b in sorted(maps)]), mapnames=np.array(sorted(maps)))
        os.replace(tmp, p)
        log.extend(lg)
        return p

    def fit(grp):
        """one LP.run over the group's slots (top + dwn together share the body map: one cloth, one layer order)"""
        t0 = time.time(); slots = [it['slot'] for it in grp]
        say(stage='slot', slot='+'.join(slots), msg='fitting %s' % ' + '.join(slots))
        if slots[0] in ('top', 'dwn'):
            for it in grp: LP.SRC[it['slot']] = it['src']
            mf = map_file('body'); maps_used.append(mf)
        else:
            it = grp[0]; part = LP.PART[it['slot']]; MB.PART_SRC[part] = it['src']; LP.SRC[it['slot']] = it['src']
            mf = map_file(part, it['src'])
        lg = Stream()
        reps, items, Y = LP.run(slots, mf, [it['out'] for it in grp], lg)
        log.extend(lg)
        for it in grp:
            done.append((it['slot'], [x for x in items if x['slot'] == it['slot']], it['out']))
            res.append(dict(slot=it['slot'], out=it['out'], report=reps[it['slot']], seconds=round(time.time() - t0, 1)))
        say(stage='slot_done', slot='+'.join(slots), msg='%s fitted in %.0f s' % (' + '.join(slots), time.time() - t0))

    body = [it for it in job['items'] if it['slot'] in ('top', 'dwn')]
    groups = ([body] if body else []) + [[it] for it in job['items'] if it['slot'] in ('glv', 'sho')]
    for it in job['items']:
        if it['slot'] not in ('top', 'dwn', 'glv', 'sho'):
            res.append(dict(slot=it['slot'], error='the %s slot is not supported yet' % it['slot']))
    for grp in groups:
        try:
            fit(grp)
        except Exception as e:
            log.append(traceback.format_exc())
            if len(grp) > 1:                                  # together failed: each on its own
                say(stage='log', msg='fitting %s together failed (%s): one by one' % ('+'.join(it['slot'] for it in grp), e))
                for it in grp:
                    try:
                        fit([it])
                    except Exception as e2:
                        log.append(traceback.format_exc())
                        res.append(dict(slot=it['slot'], error='%s: %s' % (type(e2).__name__, e2)))
                        say(stage='slot_error', slot=it['slot'], msg='%s failed: %s' % (it['slot'], e2))
            else:
                res.append(dict(slot=grp[0]['slot'], error='%s: %s' % (type(e).__name__, e)))
                say(stage='slot_error', slot=grp[0]['slot'], msg='%s failed: %s' % (grp[0]['slot'], e))
    # the outfit's own physics skeleton for the Lalafell (before the models are tagged: bone fits use the fitted cloth)
    extra_out = []
    if usable and done:
        try:
            say(stage='physics', msg='rebuilding the outfit\'s physics bones for the Lalafell')
            outdir = os.path.dirname(os.path.abspath(done[0][2]))
            lg = Stream()
            try:
                extra_out = build_extra(usable, done, maps_used[0] if maps_used else None, outdir, lg)
            finally:
                log.extend(lg)
        except Exception as e:
            log.append('extra skeleton port failed: %s: %s' % (type(e).__name__, e)); log.append(traceback.format_exc())
        made = {b for ex in extra_out for b in ex['bones']}
        lost = {b: root_of(b, ex['S']) for ex in usable for b in ex['bones'] if b not in made}
        if lost:                                          # no Lalafell skeleton for them: fold them like before
            fold_bones(done, lost, log)
    job['_extra_out'] = extra_out
    # pieces of different slots keep their source layer order
    if len(done) > 1 and os.environ.get('LP_CROSS', '0') == '1':      # off: the sleeve / glove pairs chase each other
        try:
            say(stage='layers', msg='keeping the layer order between the pieces')
            lg = Stream()
            lifted = cross_layers(done, lg, together={'top', 'dwn'})
            log.extend(lg)
            for r in res:
                if r['slot'] in lifted: r['report']['cross_lift_mm'] = lifted[r['slot']]
        except Exception as e:
            log.append('cross-slot layers skipped: %s: %s' % (type(e).__name__, e)); log.append(traceback.format_exc())
    # material names without race codes, one switch per piece
    for r in res:
        if 'error' in r: continue
        if job.get('preview'):
            try:
                import preview
                r['previews'] = preview.make_lala(r['slot'], r['out'], os.path.join(os.path.dirname(os.path.abspath(r['out'])), 'preview'))
            except Exception as e:
                log.append('preview failed: %s' % e)
        try:
            M = read(r['out'])
            ren = rename_materials(M, is_body)
            pcs = auto_pieces(M, r['slot'], is_body) if job.get('pieces', True) else []
            write(M, r['out'])
            M2 = read(r['out'])
            r.update(materials=material_list(M2), renamed=ren, pieces=[dict(attribute=a, name=n, materials=ms) for a, n, ms in pcs],
                     attributes=sorted({a for m in M2['meshes'] for s in m['subs'] for a in s['attr']}))
        except Exception as e:
            log.append(traceback.format_exc())
            sl = r['slot']; r.clear(); r.update(slot=sl, error='%s: %s' % (type(e).__name__, e))
    return res


LAYOUTS = (('build', False, False, False), ('build', True, False, False), ('build_cg', True, False, True),
           ('build_hips', True, True, False), ('build_hips_cg', True, True, True))


def tall2nirae(job, log):
    """tall-race outfit -> NIRÆ: port4 for every build (tall2nirae.run), then one file layout for all builds - the
    least splitting that keeps every model under the vertex budget: as ported, cloth in the compact layout, one file
    per hips option, one per hips option and chest group - and a Shown / Removed attribute per clothing piece"""
    import tall2nirae as TN, budget as BG
    from surf import read
    from mdlio import write, bonebbox_map
    lg = Stream()
    res = TN.run(job, say, lg)
    log.extend(lg)
    keep = dict(job.get('acc_keep') or {})
    for r in res:
        if r.get('outs') and r['slot'] in TN.ACC:
            # accessories: only the body options worn now (their slot can't switch chest / belly / waist variants)
            for b, f in list(r['outs'].items()):
                M = read(f)
                # the body's own skin comes with the Body slot: an accessory model carries only its cloth
                M['meshes'] = [m for m in M['meshes'] if 'b0001' not in m['mat']]
                for pre, dflt in (('atrx_cb_chest_', 'medium'), ('atrx_cb_belly_', 'soft'), ('atrx_cb_waist_', 'std'), ('atrx_cb_cg_', None), ('atrx_cb_nip_', 'soft')):
                    if not BG.has_family(M, pre):
                        continue
                    opt = keep.get(pre[8:-1], dflt)
                    if opt is None:
                        opt = next(a[len(pre):] for m in M['meshes'] for sb in m['subs'] for a in sb['attr'] if a.startswith(pre))
                    try:
                        BG.split(M, pre, (opt,), drop_attr=True)
                    except ValueError as e:
                        log.append('%s %s: %s option not cut (%s)' % (r['slot'], b, pre, e))
                M['bones'] = []
                write(M, f)
            log.append('%s: kept the body options worn now %s' % (r['slot'], keep or '(defaults)'))
            r['force_hips'] = True
        if r.get('outs'):
            t2n_finish(r, log)
            if job.get('preview') and r.get('files'):
                # pictures for the plugin's review (a few chest options of the first build)
                try:
                    import preview
                    say(stage='budget', msg='%s: drawing the preview pictures' % r['slot'])
                    d = os.path.join(os.path.dirname(next(iter(r['files'].values()))), 'preview')
                    r['previews'] = preview.make(r, d, job.get('builds'))
                except Exception as e:
                    log.append('preview failed: %s' % e)
    return res


def t2n_finish(r, log):
    """the file layout, piece attributes and final files of one ported item (r: slot, outs {build: raw port4 model})"""
    import tall2nirae as TN, budget as BG
    from surf import read
    from mdlio import write, bonebbox_map
    outs = r['outs']
    if True:
        say(stage='budget', msg='%s: fitting the models into the game\'s vertex budget' % r['slot'])
        variants = {}                                         # key -> M
        layout = None
        fam = {'hips': False, 'chest': False}
        for f in outs.values():
            M0 = read(f)
            fam['hips'] |= BG.has_family(M0, 'atrx_cb_hips_'); fam['chest'] |= BG.has_family(M0, 'atrx_cb_chest_')
        worst = 0
        for name, comp, hips, cg in LAYOUTS:
            if (hips and not fam['hips']) or (cg and not fam['chest']):
                continue                                      # nothing to split by
            if r.get('force_hips') and fam['hips'] and not hips:
                continue                                      # accessories: their slot can't switch hips, one file per hips
            cand = {}
            for b, f in outs.items():
                M = read(f); bb = bonebbox_map(M)
                if comp:
                    BG.compact(M)
                hs = [h for h in TN.HIPS if hips and BG.has_family(M, 'atrx_cb_hips_')] or [None]
                for h in hs:
                    Mh = M if h is None or len(hs) == 1 else _clone(M)
                    if h is not None:
                        BG.split(Mh, 'atrx_cb_hips_', (h,), drop_attr=True)
                    gs = [g for g in ('s', 'l') if cg] or [None]
                    for g in gs:
                        Mg = Mh if g is None else _clone(Mh)
                        if g is not None:
                            BG.split(Mg, 'atrx_cb_chest_', BG.CG[g], drop_attr=False)
                            BG.split(Mg, 'atrx_cb_cg_', (g,), drop_attr=False)
                        Mg['bonebbox_by_name'] = bb
                        key = '_'.join(x for x in (b, h, ('cg' + g) if g else None) if x)
                        cand[key] = Mg
            worst = max(BG.vb(M) for M in cand.values())
            log.append('%s layout %s%s: largest model %.2f MB' % (r['slot'], name, ' (compact cloth)' if comp else '', worst / 2 ** 20))
            if worst < BG.LIMIT:
                layout = (name, comp); variants = cand
                break
        if layout is None:
            r['error'] = 'the outfit is too heavy for one model even split by hips and chest group (%.1f MB)' % (worst / 2 ** 20)
            return r
        # one Shown / Removed attribute per clothing piece (the same names in every file: materials decide)
        pieces = None
        n_cloth = max(len({re.sub(r'(_fur)\d(\.mtrl)$', r'\1\2', m['mat'].split('/')[-1]) for m in M['meshes'] if m['nv'] and 'b0001' not in m['mat']})
                      for M in variants.values())
        n_attr = max(len({a for m in M['meshes'] for sb in m['subs'] for a in sb['attr']} | set(M['attrs'])) for M in variants.values())
        if r['slot'] in TN.ACC:
            # accessories: no piece switches - a custom attribute on an accessory model is not switched on like on the
            # gear slots, so every tagged piece stayed hidden (the ported hoodie did not show at all)
            log.append('%s: accessory, no piece switches' % r['slot'])
        elif n_attr + n_cloth > 32:
            log.append('%s: %d attributes + %d piece switches > 32: no piece switches' % (r['slot'], n_attr, n_cloth))
        else:
            order = sorted({re.sub(r'(_fur)\d(\.mtrl)$', r'\1\2', m['mat'].split('/')[-1]) for M in variants.values()
                            for m in M['meshes'] if m['nv'] and 'b0001' not in m['mat']})
            for key, M in sorted(variants.items()):
                p = auto_pieces(M, r['slot'], lambda mat: 'b0001' in mat, order)
                if pieces is None or len(p) > len(pieces): pieces = p
        files = {}; grown = 0.0
        for key, M in variants.items():
            f = os.path.join(os.path.dirname(outs[next(iter(outs))]), '%s_%s_final.mdl' % (r['slot'], key))
            grown = max(grown, max(BG.fix_bbox(M)))
            M['bones'] = []
            write(M, f); files[key] = f
        log.append('%s: bounding boxes grown by up to %.1f mm to hold the ported cloth' % (r['slot'], grown))
        r.update(layout=layout[0], compact=layout[1], files=files, pieces=[dict(attribute=a, name=n, materials=m) for a, n, m in pieces or []],
                 vb_mb={k: round(BG.vb(M) / 2 ** 20, 2) for k, M in variants.items()},
                 materials=sorted({m['mat'] for M in variants.values() for m in M['meshes'] if m['nv']}),
                 attributes=sorted({a for M in variants.values() for m in M['meshes'] for sb in m['subs'] for a in sb['attr']}))
        say(stage='slot_done', slot=r['slot'], msg='%s: %d file(s), layout %s%s' % (r['slot'], len(files), layout[0], ' with compact cloth' if layout[1] else ''))
    return r


def tall2lala(job, log):
    """any tall-race outfit (Rue / Bibo / YAB / the game's own) -> Lalafell, chained through NIRÆ: tall2nirae for the
    one NIRÆ build the Lalafell port starts from (with the same repairs, smoothing and checks), that build's model cut
    down to the hips / chest / belly options the Lalafell body map uses, then nirae2lala as for a NIRÆ outfit"""
    import tall2nirae as TN, budget as BG
    from surf import read
    from mdlio import write
    no = job.get('nirae', {})
    build = no.get('build', 'curvy'); hips = no.get('hips', 'medium')
    keep = {'atrx_cb_hips_': hips, 'atrx_cb_chest_': no.get('chest', 'earth'), 'atrx_cb_belly_': no.get('belly', 'soft'), 'atrx_cb_waist_': 'std'}
    items2 = []; failed = []
    # pieces already made for NIRÆ go straight to the Lalafell fit
    for it in job['items']:
        if it.get('direct'):
            items2.append(dict(slot=it['slot'], src=it['src'], out=it.get('lala_out') or it['out']))
    j1 = dict(job, builds=[build], preview=False, pieces=False)
    j1['items'] = [dict(it) for it in job['items'] if not it.get('direct')]
    res1 = []
    if j1['items']:
        say(stage='slot', msg='first fitting %d piece(s) to NIRÆ %s (%s hips)' % (len(j1['items']), build, hips))
        lg = Stream()
        res1 = TN.run(j1, say, lg)
        log.extend(lg)
    for r, it in zip(res1, j1['items']):
        outs = r.get('outs') or {}
        f = outs.get(build) or next(iter(outs.values()), None)
        if not f or not os.path.exists(f):
            err = r.get('error') or '; '.join('%s' % v for v in (r.get('errors') or {}).values()) or 'the NIRÆ fit made no model'
            failed.append(dict(slot=r['slot'], error='NIRÆ step: %s' % err)); continue
        M = read(f)
        for pre, opt in keep.items():
            if BG.has_family(M, pre):
                try:
                    BG.split(M, pre, (opt,), drop_attr=True)
                except ValueError as e:
                    log.append('%s: %s option not cut (%s)' % (r['slot'], pre, e))
        M['bones'] = []
        mid = os.path.join(it['out'], '%s_nirae_%s_%s.mdl' % (r['slot'], build, hips))
        write(M, mid)
        log.append('%s: NIRÆ %s fit done (%s)' % (r['slot'], build, os.path.basename(mid)))
        items2.append(dict(slot=r['slot'], src=mid, out=it.get('lala_out') or os.path.join(it['out'], r['slot'] + '.mdl')))
    if not items2:
        return failed
    j2 = dict(job, direction='nirae2lala', items=items2)
    return nirae2lala(j2, log) + failed


def _clone(M):
    import copy
    return copy.deepcopy(M)


def main(jobf):
    job = json.load(open(jobf, encoding='utf-8-sig'))
    log = []
    out = dict(ok=False, items=[], log=log, engine=ENGINE_VERSION)
    try:
        if job['direction'] == 'nirae2lala':
            out['items'] = nirae2lala(job, log)
            out['extra'] = job.get('_extra_out', [])
        elif job['direction'] == 'tall2lala':
            out['items'] = tall2lala(job, log)
            out['extra'] = job.get('_extra_out', [])
        elif job['direction'] == 'tall2nirae':
            out['items'] = tall2nirae(job, log)
        elif job['direction'] == 'detect':
            import tall2nirae as TN
            lg = Stream(); d = TN.detect(job, say, lg); log.extend(lg)
            out['items'] = d['items']; out['library'] = d['library']
        else:
            raise ValueError('direction %s not supported yet' % job['direction'])
        out['ok'] = any('error' not in x for x in out['items'])
    except Exception as e:
        out['error'] = '%s: %s' % (type(e).__name__, e); out['trace'] = traceback.format_exc()
        say(stage='error', msg=out['error'])
    res = job.get('result') or jobf.replace('.json', '_result.json')
    with open(res + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1, default=str)
    os.replace(res + '.tmp', res)
    say(stage='done', ok=out['ok'])
    return 0 if out['ok'] else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1]))
