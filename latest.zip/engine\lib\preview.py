"""Preview pictures of a finished NIRÆ port: the final model as the game shows it for a few chest options (belly full,
hips medium), front / three-quarter / side, rendered by splatting dense surface samples into a depth buffer (numpy
only), written as PNG (zlib) for the plugin to show before the mod is written."""
import os, struct, zlib
import numpy as np
from mdlio import read
from lib import attr

CHESTS = [('flat', 'Flat'), ('smallperky', 'Small Perky'), ('perky', 'Medium Perky'), ('medium', 'Medium Round'),
          ('large', 'Large Round'), ('mireya', 'Mireya')]
CG_S = ('flat', 'small', 'champs', 'smallperky', 'medium', 'earth')
BUILDS = ('curvy', 'thick', 'athletic', 'slim')


def png(path, img):
    h, w, _ = img.shape
    raw = b''.join(b'\x00' + img[y].astype(np.uint8).tobytes() for y in range(h))
    def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
                + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b''))


def visible(M, ch):
    cg = 's' if ch in CG_S else 'l'
    on = {'atrx_cb_chest_' + ch, 'atrx_cb_cg_' + cg, 'atrx_cb_belly_full', 'atrx_cb_hips_medium', 'atrx_cb_nip_soft', 'atrx_cb_vulva_closed'}
    parts = []
    for m in M['meshes']:
        if not m['nv']: continue
        P = attr(m, 0)[0][:, :3].astype(float); idx = np.frombuffer(m['idx'], np.uint16).astype(int); T = []
        for s in m['subs']:
            if s['cnt'] and all((not a.startswith('atrx_cb_')) or a in on for a in s['attr']):
                T.append(idx[s['off']:s['off'] + s['cnt']].reshape(-1, 3))
        if T:
            skin = 'b0001' in m['mat']
            parts.append((P, np.concatenate(T), (222, 186, 172) if skin else (92, 104, 158)))
    return parts


def render(parts, view, box, H=240, seed=1):
    L = np.array([0.35, 0.55, 0.76]); L /= np.linalg.norm(L)
    def proj(P):
        if view == 'front': return np.c_[P[:, 0], P[:, 1], P[:, 2]]
        if view == 'side': return np.c_[P[:, 2], P[:, 1], -P[:, 0]]
        a = np.radians(40); return np.c_[P[:, 0] * np.cos(a) + P[:, 2] * np.sin(a), P[:, 1], -P[:, 0] * np.sin(a) + P[:, 2] * np.cos(a)]
    u0, u1, v0, v1 = box; sc = H / (v1 - v0); W = int((u1 - u0) * sc)
    rng = np.random.default_rng(seed)
    pts = []; cols = []
    for P, T, col in parts:
        Q = proj(P); A = Q[T[:, 0]]; B = Q[T[:, 1]]; C = Q[T[:, 2]]
        fn = np.cross(B - A, C - A); ar = np.linalg.norm(fn, axis=1) / 2; fn /= np.maximum(2 * ar, 1e-12)[:, None]
        n = np.clip(np.ceil(ar * sc * sc * 6), 2, 600).astype(int)
        ti = np.repeat(np.arange(len(T)), n)
        r1 = np.sqrt(rng.random(len(ti))); r2 = rng.random(len(ti))
        S = (1 - r1)[:, None] * A[ti] + (r1 * (1 - r2))[:, None] * B[ti] + (r1 * r2)[:, None] * C[ti]
        shade = np.abs(fn[ti] @ L) * 0.7 + 0.25
        pts.append(S); cols.append(np.array(col)[None, :] * shade[:, None])
    S = np.concatenate(pts); Cc = np.concatenate(cols)
    x = ((S[:, 0] - u0) * sc).astype(int); y = (H - 1 - (S[:, 1] - v0) * sc).astype(int)
    ok = (x >= 0) & (x < W) & (y >= 0) & (y < H)
    x, y, z, Cc = x[ok], y[ok], S[ok, 2], Cc[ok]
    pix = y * W + x; o = np.lexsort((-z, pix)); pix = pix[o]; Cc = Cc[o]
    first = np.r_[True, pix[1:] != pix[:-1]]
    img = np.full((H * W, 3), 245.0); img[pix[first]] = Cc[first]
    return img.reshape(H, W, 3)


def make(r, out_dir, builds=None):
    """pictures for one ported item r (slot, files {key: final model}); returns [{label, png}]"""
    files = r.get('files') or {}
    if not files: return []
    order = [b for b in (builds or BUILDS) if any(k.split('_')[0] == b for k in files)]
    if not order: return []
    b = order[0]
    top = r['slot'] == 'top'
    box_f, box_s = {'top': ((-0.36, 0.36, 0.78, 1.52), (-0.22, 0.26, 0.78, 1.52)), 'dwn': ((-0.30, 0.30, 0.10, 1.12), (-0.22, 0.26, 0.10, 1.12)),
                    'glv': ((-0.90, 0.90, 0.70, 1.25), (-0.30, 0.30, 0.70, 1.25)), 'sho': ((-0.25, 0.25, -0.02, 0.45), (-0.20, 0.25, -0.02, 0.45))}[r['slot']]
    chests = CHESTS if top else [('medium', {'dwn': 'NIRÆ legs', 'glv': 'NIRÆ hands', 'sho': 'NIRÆ feet'}[r['slot']])]
    out = []; cache = {}
    os.makedirs(out_dir, exist_ok=True)
    for ch, label in chests:
        cg = 's' if ch in CG_S else 'l'
        keys = [k for k in files if k.split('_')[0] == b]
        keys = sorted(keys, key=lambda k: (('cg' in k) and ('cg' + cg) not in k, ('_small' in k or '_large' in k)))
        k = keys[0]
        if k not in cache: cache[k] = read(files[k])
        parts = visible(cache[k], ch)
        if not parts: continue
        ims = [render(parts, 'front', box_f), render(parts, 'q', box_f), render(parts, 'side', box_s)]
        sep = np.full((ims[0].shape[0], 6, 3), 255.0)
        img = np.concatenate([ims[0], sep, ims[1], sep, ims[2]], 1)
        p = os.path.join(out_dir, 'preview_%s_%s_%s.png' % (r['slot'], b, ch))
        png(p, img); out.append(dict(label='%s · %s' % (b.capitalize(), label), png=p))
    return out
