"""Bloodrake [NeoLithe] -> Crimson Body port (all chest, belly and hips/legs options, all builds).
Pipeline (see ffxiv-outfit-port skill):
  * each chest option is fitted from the author size closest to it (XS or S, measured through shared Bibo UVs)
  * cloth on the author's skin is glued to the same skin spot of our body (exact UV interpolation) at the author's
    exact height; bridging/free cloth (straps, frills, the long skirt) gets a smooth fill of the displacement
  * clipping: one smooth lift field along the skin normal shared by every layer
  * belly (none/soft/full) and hips (small/medium/large): attribute variants of the cloth near the moving skin,
    displaced by the body's own shape field, propagated smoothly into hanging cloth
  * weights: the body's own skin + jiggle weights at the same skin spot (skirt bones kept)"""
import sys, os, json, copy as _copy
from surf import *
from scipy.sparse import coo_matrix, diags, identity
from scipy.sparse.linalg import splu


GAP = float(os.environ.get('GAP', '0.002'))
PICK = None   # filled by measuring
DIST = {}
REF = 'medium'
SNUG_DEFAULT = {'perky': 0.6, 'smallperky': 0.6}   # snug upper chest (share of the author's float removed there)

# ---------------------------------------------------------------- cloth graph + smooth solves
def weld_key(V, tol=2e-5):
    """same id for vertices closer than tol (seam duplicates), robust to rounding boundaries"""
    from scipy.sparse.csgraph import connected_components
    pr = cKDTree(V).query_pairs(tol, output_type='ndarray')
    A = coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(V), len(V)))
    return connected_components(A, directed=False)[1]

class Graph:
    def __init__(s, V0, T):
        key = weld_key(V0); n = key.max() + 1
        Tk = key[T]
        r = np.r_[Tk[:, 0], Tk[:, 1], Tk[:, 2], Tk[:, 1], Tk[:, 2], Tk[:, 0]]; c = np.r_[Tk[:, 1], Tk[:, 2], Tk[:, 0], Tk[:, 0], Tk[:, 1], Tk[:, 2]]
        A = coo_matrix((np.ones(len(r)), (r, c)), shape=(n, n)).tocsr(); A.data[:] = 1; A.setdiag(0); A.eliminate_zeros()
        deg = np.asarray(A.sum(1)).ravel(); s.deg = deg
        W = diags(1 / np.maximum(deg, 1)) @ A
        s.key, s.n, s.A, s.W = key, n, A, W
        s.L = (identity(n, format='csr') - W)
        dm = diags(1 / np.sqrt(np.maximum(deg, 1)))
        s.Ls = identity(n, format='csr') - dm @ A @ dm
        s.cnt = np.bincount(key, minlength=n)
        s.W0 = s.avg(V0)
        from scipy.sparse.csgraph import connected_components
        s.ncomp, s.comp = connected_components(A, directed=False)
    def avg(s, X):
        out = np.zeros((s.n,) + X.shape[1:]); np.add.at(out, s.key, X); return out / s.cnt.reshape((-1,) + (1,) * (X.ndim - 1))
    def solve(s, wa, target, mu=0.6, nu=0.02):
        """minimise sum wa|d-target|^2 + mu|L d|^2 + nu d'Ls d  (welded vertices)"""
        M = (diags(wa) + mu * (s.L.T @ s.L) + nu * s.Ls).tocsc()
        lu = splu(M)
        return np.stack([lu.solve(wa * target[:, i]) for i in range(target.shape[1])], 1)

def G_avg_bool(G, b):
    out = np.ones(G.n, bool); np.logical_and.at(out, G.key, b); return out

def frames(G, V0, P, N0, T0):
    """rotate normals/tangents with the local deformation (polar decomposition of the 1-ring)"""
    W0 = G.avg(V0); W1 = G.avg(P)
    A = G.A.tocoo(); e0 = W0[A.col] - W0[A.row]; e1 = W1[A.col] - W1[A.row]
    M = np.zeros((G.n, 3, 3)); np.add.at(M, A.row, e1[:, :, None] * e0[:, None, :])
    U, S, Vt = np.linalg.svd(M); D = np.ones((G.n, 3)); D[:, 2] = np.sign(np.linalg.det(U @ Vt))
    R = U @ (D[:, :, None] * Vt)
    bad = S[:, 1] < 1e-12; R[bad] = np.eye(3)
    Rv = R[G.key]
    return np.einsum('nij,nj->ni', Rv, N0), np.einsum('nij,nj->ni', Rv, T0)

def cloth_data(m):
    V = attr(m, 0)[0][:, :3].astype(float); N = attr(m, 3)[0][:, :3].astype(float)
    tg = np.frombuffer(m['streams'][1], np.uint8).reshape(m['nv'], -1)[:, 12:15] / 255 * 2 - 1
    return V, N, tg.astype(float), np.frombuffer(m['idx'], np.uint16).astype(int).reshape(-1, 3)

# ---------------------------------------------------------------- fitting one chest option
def fit_chest(B, A, X, ch, log):
    tri, w, err = uv_map(A, B)
    QA = B.at(tri, w); NA = B.at(tri, w, B.N); NA /= np.linalg.norm(NA, axis=1)[:, None]
    if CFG.get('smooth_nipples'):
        # tight fabric bridges over the nipples: glue to a smoothed copy of our chest (collision still uses the real skin)
        Ps_ = B.P.copy(); reg_ = (B.part == 0) & (B.P[:, 1] > 1.10) & (B.P[:, 1] < 1.33) & (B.P[:, 2] > 0.03)
        nb_ = cKDTree(B.P).query_ball_point(B.P[reg_], 0.012); idx_ = np.where(reg_)[0]
        # Taubin smoothing (shrink 0.6 / inflate -0.64): flattens the nipples but keeps the breast's size. The plain
        # neighbour mean (3 passes) shrank the chest by 2.7 mm, so the cups were glued INSIDE the breast and the collision
        # push afterwards bent the bra lacing (Gothkini)
        for _ in range(6):
            for lam_ in (0.6, -0.64):
                Pn_ = np.array([Ps_[j].mean(0) for j in nb_]); Ps_[idx_] += lam_ * (Pn_ - Ps_[idx_])
        # along the skin normal only: the smoothing also slides vertices sideways, which dragged the glued cloth with it
        # (bent lacing over the nipple)
        Ps_ = B.P + B.N * np.einsum('nd,nd->n', Ps_ - B.P, B.N)[:, None]
        QA = np.einsum('ni,nid->nd', w, Ps_[B.T[tri]])
    if CFG.get('smooth_crotch'):
        # tight fabric bridges the cleft between the thighs at the crotch instead of following each thigh into it:
        # glue to a copy of our skin smoothed across both thighs there (collision still uses the real skin)
        Pc = B.P.copy(); y, x, z = B.P[:, 1], np.abs(B.P[:, 0]), B.P[:, 2]
        fw = (B.part == 1) * np.clip((0.95 - y) / 0.04, 0, 1) * np.clip((y - 0.74) / 0.03, 0, 1) * np.clip((0.085 - x) / 0.03, 0, 1) * np.clip((z + 0.03) / 0.03, 0, 1)
        idx_ = np.where(fw > 0)[0]; nb_ = cKDTree(B.P).query_ball_point(B.P[idx_], 0.015)
        for _ in range(4):
            Pn = np.array([Pc[j].mean(0) for j in nb_]); Pc[idx_] += fw[idx_, None] * (Pn - Pc[idx_])
        base_ = QA if CFG.get('smooth_nipples') else B.at(tri, w)
        QA = base_ + np.einsum('ni,nid->nd', w, (Pc - B.P)[B.T[tri]])
        log.append('%s crotch bridge: max %.1f mm' % (ch, np.linalg.norm(Pc - B.P, axis=1).max() * 1000))
    # where the UV match is not trustworthy (point outside our UV islands, normal flipped, jumped far), fill the
    # author->our displacement smoothly from the trusted neighbours over the author body surface
    good = (err < 5e-4) & (np.einsum('nd,nd->n', NA, A.N) > 0.3) & (np.linalg.norm(QA - A.P, axis=1) < 0.08)
    if hasattr(B, 'vulva') and not CFG.get('no_vulva_bridge'):
        # author skin that lands on our vulva (labia, slit): an author body without one is smooth there, the UV match
        # crumples crotch cloth into the labia. Untrusted: the displacement is filled smoothly from the mons, thighs and
        # perineum around it, so the crotch strip bridges over the vulva; the collision then lifts it onto the labia
        vb = B.vulva[B.T[tri]].any(1); good &= ~vb
        log.append('%s vulva bridge: %d author skin points untrusted' % (ch, int(vb.sum())))
    if (~good).any():
        GA = Graph(A.P, A.T)
        wa = np.where(G_avg_bool(GA, good), 1.0, 0.0) + 1e-6
        Dg = GA.solve(wa, GA.avg(QA - A.P), mu=0.0, nu=1.0)
        Dg = Dg[GA.key]; QA = np.where(good[:, None], QA, A.P + Dg)
        Ng = GA.avg(NA)[GA.key]; NA = np.where(good[:, None], NA, A.N)
        log.append('%s untrusted UV matches filled: %d of %d' % (ch, int((~good).sum()), len(good)))
    SM = CFG.get('smooth_map')
    if SM:
        # a smooth map in a region (crotch of an author body without a vulva): every author skin point there takes the
        # gaussian average (sigma) of the author->our displacement of the trusted points around it, projected onto our
        # skin; ramps back to the plain UV map over the box margin. The plain map (UV glue + filled vulva) crumpled the
        # Gothkini front panel and squashed its lacing
        bx = np.array(SM.get('box', [0.06, 0.80, 0.95, -0.08, 0.10])); sig = SM.get('sigma', 0.015); mg = SM.get('margin', 0.02)
        x, y, z = np.abs(A.P[:, 0]), A.P[:, 1], A.P[:, 2]
        ins = np.minimum.reduce([(bx[0] - x) / mg, (y - bx[1]) / mg, (bx[2] - y) / mg, (z - bx[3]) / mg, (bx[4] - z) / mg])
        wgt = np.clip(ins, 0, 1); idx_ = np.where(wgt > 0)[0]
        if len(idx_):
            src = np.where(good & (A.part == np.bincount(A.part[idx_]).argmax()))[0]; Dm = QA - A.P
            tr_ = cKDTree(A.P[src]); nbs = tr_.query_ball_point(A.P[idx_], 2.5 * sig)
            Ds_ = np.zeros((len(idx_), 3)); ok_ = np.zeros(len(idx_), bool)
            for k_, (i_, js) in enumerate(zip(idx_, nbs)):
                if not js: continue
                js = src[js]; wj = np.exp(-np.sum((A.P[js] - A.P[i_]) ** 2, 1) / (2 * sig * sig)); Ds_[k_] = (wj[:, None] * Dm[js]).sum(0) / wj.sum(); ok_[k_] = True
            idx_ = idx_[ok_]; Ds_ = Ds_[ok_]
            t2, w2, q2, _ = B.closest(A.P[idx_] + Ds_); n2 = B.nrm(t2, w2); n2 /= np.maximum(np.linalg.norm(n2, axis=1), 1e-9)[:, None]
            a_ = wgt[idx_][:, None]
            QA = QA.copy(); NA = NA.copy()
            QA[idx_] = (1 - a_) * QA[idx_] + a_ * q2; NA[idx_] = (1 - a_) * NA[idx_] + a_ * n2; NA[idx_] /= np.linalg.norm(NA[idx_], axis=1)[:, None]
            log.append('%s smooth map: %d author skin points (sigma %.0f mm), moved median %.1f max %.1f mm' % (ch, len(idx_), sig * 1000, np.median(np.linalg.norm(q2 - (A.P[idx_] + Dm[idx_]), axis=1)) * 1000, np.linalg.norm(q2 - (A.P[idx_] + Dm[idx_]), axis=1).max() * 1000))
    if CFG.get('chest_smooth', True):
        # chests far from the author's (flat / earth vs a big author bust, Mireya vs a small one): the skin-to-skin map
        # over the chest is smoothed (gaussian of the author->our move, same side of the body only, then back onto our
        # skin), more the more the chest differs (sigma 0.4 x the bust difference, 6-20 mm). Glued point by point, every
        # local squeeze of the breast crumpled lace and bows; smoothed, the cloth shrinks / grows evenly
        regA = (A.part == 0) & (A.P[:, 1] > 1.10) & (A.P[:, 1] < 1.32); regB = (B.part == 0) & (B.P[:, 1] > 1.10) & (B.P[:, 1] < 1.32)
        dg = abs(float(B.P[regB, 2].max() - A.P[regA, 2].max())) if regA.any() and regB.any() else 0.0
        sig = min(0.020, 0.4 * dg)
        if sig > 0.006:
            x, y, z = np.abs(A.P[:, 0]), A.P[:, 1], A.P[:, 2]; mg = 0.03
            wgt = np.clip(np.minimum.reduce([(0.17 - x) / mg, (y - 1.04) / mg, (1.42 - y) / mg, (z + 0.01) / mg]), 0, 1) * (A.part == 0)
            idx_ = np.where(wgt > 0)[0]
            src = np.where(good & (A.part == 0))[0]; Dm = QA - A.P
            tr_ = cKDTree(A.P[src]); nbs = tr_.query_ball_point(A.P[idx_], 2.5 * sig)
            Ds_ = np.zeros((len(idx_), 3)); ok_ = np.zeros(len(idx_), bool)
            for k_, (i_, js) in enumerate(zip(idx_, nbs)):
                if not js: continue
                js = src[js]
                js = js[(np.sign(A.P[js, 0]) == np.sign(A.P[i_, 0])) | (np.abs(A.P[js, 0]) < 0.005) | (abs(A.P[i_, 0]) < 0.005)]
                if not len(js): continue
                wj = np.exp(-np.sum((A.P[js] - A.P[i_]) ** 2, 1) / (2 * sig * sig)); Ds_[k_] = (wj[:, None] * Dm[js]).sum(0) / wj.sum(); ok_[k_] = True
            idx_ = idx_[ok_]; Ds_ = Ds_[ok_]
            if len(idx_):
                t2, w2, q2, _ = B.closest(A.P[idx_] + Ds_); n2 = B.nrm(t2, w2); n2 /= np.maximum(np.linalg.norm(n2, axis=1), 1e-9)[:, None]
                a_ = wgt[idx_][:, None]
                mv = np.linalg.norm(q2 - QA[idx_], axis=1)
                QA = QA.copy(); NA = NA.copy()
                QA[idx_] = (1 - a_) * QA[idx_] + a_ * q2; NA[idx_] = (1 - a_) * NA[idx_] + a_ * n2; NA[idx_] /= np.linalg.norm(NA[idx_], axis=1)[:, None]
                log.append('%s chest map smoothed (bust %.0f mm from the author\'s, sigma %.0f mm): %d skin points, moved median %.1f max %.1f mm'
                           % (ch, dg * 1000, sig * 1000, len(idx_), np.median(mv) * 1000, mv.max() * 1000))
    AF = CFG.get('affine_region'); Maff = None; AFF_ = {}
    if AF:
        # cloth in a region (author space, e.g. the crotch of an author body without a vulva) keeps its own shape: placed
        # by one affine map fitted (least squares) to the trusted author->our skin matches in the region, blended into
        # the glue over the margin. Gluing each vertex bunched a thong's front panel into the creases between the thighs
        abx = np.array(AF.get('box', [0.08, 0.80, 0.93, -0.10, 0.10]))
        xa, ya, za = np.abs(A.P[:, 0]), A.P[:, 1], A.P[:, 2]
        sa = good & (xa < abx[0]) & (ya > abx[1]) & (ya < abx[2]) & (za > abx[3]) & (za < abx[4])
        if sa.sum() > 30:
            Xh = np.c_[A.P[sa], np.ones(int(sa.sum()))]; sol, *_ = np.linalg.lstsq(Xh, QA[sa], rcond=None); Maff = sol.T
            resid = np.linalg.norm(Xh @ sol - QA[sa], axis=1)
            log.append('%s affine region: %d skin matches, residual median %.1f p90 %.1f mm, linear part %s' % (
                ch, int(sa.sum()), np.median(resid) * 1000, np.percentile(resid, 90) * 1000, np.round(np.linalg.svd(Maff[:, :3])[1], 3).tolist()))
    res = []
    TT = CFG.get('tighten') or {}
    reg = lambda S, P: (S.part == 0) & (P[:, 1] > 1.10) & (P[:, 1] < 1.32)
    gain = float(B.P[reg(B, B.P), 2].max() - A.P[reg(A, A.P), 2].max())
    log.append('%s chest protrudes %.1f mm more than the author body' % (ch, gain * 1000))
    # snug upper chest strength for this chest (cfg snug: {chest: 0..1}; default the perky chests)
    snug_s = float((CFG.get('snug') if CFG.get('snug') is not None else SNUG_DEFAULT).get(ch, 0.0))
    Sb = B.P[(B.part == 0) & (B.P[:, 2] > 0) & (np.abs(B.P[:, 0]) > 0.04) & (np.abs(B.P[:, 0]) < 0.09) & (B.P[:, 1] > 1.08) & (B.P[:, 1] < 1.32)]
    apy = float(Sb[np.argmax(Sb[:, 2]), 1]) if len(Sb) else 1.22
    for mi, m in enumerate(X['meshes']):
        if is_skin(m): continue
        V0, N0, T0, I = cloth_data(m); G = GR[mi]
        t, bw, sp, dist = A.closest(V0)
        sn = A.nrm(t, bw)
        off = np.einsum('nd,nd->n', V0 - sp, sn)
        legs_ = A.part[A.T[t, 0]] == 1
        q = np.einsum('ni,nid->nd', bw, QA[A.T[t]]); qn = np.einsum('ni,nid->nd', bw, NA[A.T[t]]); qn /= np.linalg.norm(qn, axis=1)[:, None]
        Pg = q + off[:, None] * qn
        a = np.clip((0.016 - dist) / 0.006, 0, 1)
        if snug_s > 0:
            # snug upper chest: over the top of OUR breast (from just above the bust line up to the upper chest) the cloth
            # keeps only part of the author's float (h' = gap + (h - gap) * (1 - s)), glued there. The author's tops float
            # over a fuller upper breast; copied as they are they stand off the flatter top of the perky chests.
            # Monotonic in h, so layers keep their order; loose garments get half of it
            sy = q[:, 1]
            r = (np.clip((sy - (apy + 0.004)) / 0.016, 0, 1) * np.clip((apy + 0.105 - sy) / 0.03, 0, 1)
                 * np.clip((q[:, 2] - 0.02) / 0.02, 0, 1) * np.clip((0.13 - np.abs(q[:, 0])) / 0.03, 0, 1)
                 * np.clip((0.030 - off) / 0.008, 0, 1) * (~legs_))
            if any(k in m['mat'] for k in CFG.get('loose', [])): r = r * 0.5
            cut = snug_s * r * np.clip(off - GAP, 0, None)
            if (cut > 1e-4).any():
                Pg = Pg - cut[:, None] * qn
                a = np.maximum(a, np.clip(r * 2, 0, 1) * (cut > 1e-4))
                log.append('%s %s snug upper chest: %d verts, float cut median %.1f max %.1f mm' % (
                    ch, m['mat'][-8:-5], int((cut > 1e-4).sum()), np.median(cut[cut > 1e-4]) * 1000, cut.max() * 1000))
        if Maff is not None and (not AF.get('mats') or any(k_ in m['mat'] for k_ in AF['mats'])):
            mg_ = AF.get('margin', 0.02); x_, y_, z_ = np.abs(V0[:, 0]), V0[:, 1], V0[:, 2]
            wr = np.clip(np.minimum.reduce([(abx[0] - x_) / mg_, (y_ - abx[1]) / mg_, (abx[2] - y_) / mg_, (z_ - abx[3]) / mg_, (abx[4] - z_) / mg_]), 0, 1)
            Pa = V0 @ Maff[:, :3].T + Maff[:, 3]
            rg = np.where(wr > 0)[0]
            if len(rg):
                # shrink-wrap the affine copy onto our skin (closest point + its height, at least the gap), the move
                # smoothed over 8 mm (no kinks where the closest point jumps), then whatever still lacks the gap is lifted
                # as one smooth field (need dilated by 1 cm, gaussian 1 cm). The pipeline's later pushes are undone here
                # at the end of the fit (freeze), so the panel keeps this smooth shape
                kd_ = cKDTree(V0[rg]); kk = min(96, len(rg)); dd1, jj1 = kd_.query(V0[rg], k=kk)
                def gsm(F, sg):
                    gw_ = np.exp(-dd1 ** 2 / (2 * sg ** 2)) * (dd1 < 2.5 * sg)
                    return np.einsum('nk,nk...->n...', gw_, F[jj1]) / np.maximum(gw_.sum(1), 1e-12).reshape(-1, *([1] * (F.ndim - 1)))
                th_ = np.maximum(off[rg], GAP + 0.0005)
                t_, w_, q_, d_ = B.closest(Pa[rg]); n_ = B.nrm(t_, w_); n_ /= np.maximum(np.linalg.norm(n_, axis=1), 1e-9)[:, None]
                # along the (smoothed) skin normal only: sideways parts of the closest-point move pulled the panel's tip
                # in from both labia and crossed it over
                # ONE direction for the whole region (the mean skin normal there): per-vertex normals in the crease between
                # the thighs face each other, moving both sides of the narrow tip along them crossed it over (knot)
                Nw_ = n_.mean(0); Nw_ = np.repeat((Nw_ / np.linalg.norm(Nw_))[None], len(rg), 0)
                mv_ = np.einsum('nd,nd->n', q_ + n_ * th_[:, None] - Pa[rg], Nw_)
                P2 = Pa[rg] + gsm(mv_, 0.008)[:, None] * Nw_
                t_, w_, q_, d_ = B.closest(P2); n_ = B.nrm(t_, w_); n_ /= np.maximum(np.linalg.norm(n_, axis=1), 1e-9)[:, None]
                need_ = np.clip(GAP - np.einsum('nd,nd->n', P2 - q_, n_), 0, None)
                # dilate over 2 cm (ball), then gaussian 1 cm: the smooth field covers each peak itself (a 1 cm dilation left
                # the peaks above the field: a 2 mm spike knotted the panel's tip)
                dil = np.array([need_[j].max() for j in kd_.query_ball_point(V0[rg], 0.02)])
                nb25 = kd_.query_ball_point(V0[rg], 0.025)
                Ls = np.array([(np.exp(-np.sum((V0[rg][j] - V0[rg][i]) ** 2, 1) / 2e-4) * dil[j]).sum() / np.exp(-np.sum((V0[rg][j] - V0[rg][i]) ** 2, 1) / 2e-4).sum() for i, j in enumerate(nb25)])
                Lf = np.maximum(Ls, need_)
                Ns_ = Nw_
                P2 = P2 + Lf[:, None] * Ns_
                # second pass along the LOCAL skin normal smoothed over 1 cm (gaussian, 2.5 cm balls): the one region-wide
                # direction cannot lift cloth where the skin faces another way (the strip under the crotch faces down:
                # 45 verts stayed 0.7 mm inside, frozen). Smoothed over 1 cm the normals facing each other across the
                # narrow tip cancel, so the tip is not crossed over; only what still lacks the gap moves (dilated 2 cm)
                t_, w_, q_, d_ = B.closest(P2); n_ = B.nrm(t_, w_); n_ /= np.maximum(np.linalg.norm(n_, axis=1), 1e-9)[:, None]
                # target: just clear the skin (1.5 mm, cfg lift2_gap), not the full gap: lifting every vertex under 3 mm
                # (1322) along the local normals pushed the scalloped hem sideways into spikes. The lift is ONE smooth
                # field (no per-vertex max with the need: that brought the spikes back), the cosine correction smoothed too
                need2 = np.clip(AF.get('lift2_gap', 0.0015) - np.einsum('nd,nd->n', P2 - q_, n_), 0, None)
                if need2.max() > 1e-4:
                    gw2 = [np.exp(-np.sum((V0[rg][j] - V0[rg][i]) ** 2, 1) / 2e-4) for i, j in enumerate(nb25)]
                    sm2 = lambda F: np.array([(g_ * F[j]).sum() / g_.sum() for g_, j in zip(gw2, nb25)])
                    Nl_ = np.array([(g_[:, None] * n_[j]).sum(0) for g_, j in zip(gw2, nb25)]); Nl_ /= np.maximum(np.linalg.norm(Nl_, axis=1), 1e-9)[:, None]
                    dil2 = np.array([need2[j].max() for j in kd_.query_ball_point(V0[rg], 0.02)])
                    L2 = sm2(dil2)
                    cs = np.clip(sm2(np.einsum('nd,nd->n', Nl_, n_)), 0.7, 1)
                    P2 = P2 + (L2 / cs)[:, None] * Nl_
                    t_, w_, q_, d_ = B.closest(P2); n_ = B.nrm(t_, w_); n_ /= np.maximum(np.linalg.norm(n_, axis=1), 1e-9)[:, None]
                    h2 = np.einsum('nd,nd->n', P2 - q_, n_)
                    log.append('%s affine region %s: second lift along the 1 cm local normal: %d verts lacked the gap (max %.1f mm), '
                               'lifted max %.1f mm, now min height %.1f mm' % (ch, m['mat'][-14:], int((need2 > 1e-4).sum()), need2.max() * 1000,
                                                                              (L2 / cs).max() * 1000, h2.min() * 1000))
                    # repeat while anything is still INSIDE the skin (Thick: the panel's sides cut into the thighs up to 5.6 mm and
                    # one smooth pass left -3.7 mm); builds that came out clear (min > 0) are left exactly as they were
                    # cfg lift2_repeat (default 0 = off): where both thighs touch (Thick) there is no free side to lift to and
                    # the repeats oscillated (-7.9 .. -2.8 mm) instead of converging: the panel tip there is hidden between them
                    for it2 in range(int(AF.get('lift2_repeat', 0))):
                        if h2.min() > 0: break
                        need2 = np.clip(AF.get('lift2_gap', 0.0015) - h2, 0, None)
                        Nl_ = np.array([(g_[:, None] * n_[j]).sum(0) for g_, j in zip(gw2, nb25)]); Nl_ /= np.maximum(np.linalg.norm(Nl_, axis=1), 1e-9)[:, None]
                        dil2 = np.array([need2[j].max() for j in kd_.query_ball_point(V0[rg], 0.02)])
                        L2 = sm2(dil2); cs = np.clip(sm2(np.einsum('nd,nd->n', Nl_, n_)), 0.7, 1)
                        P2 = P2 + (L2 / cs)[:, None] * Nl_
                        t_, w_, q_, d_ = B.closest(P2); n_ = B.nrm(t_, w_); n_ /= np.maximum(np.linalg.norm(n_, axis=1), 1e-9)[:, None]
                        h2 = np.einsum('nd,nd->n', P2 - q_, n_)
                        log.append('%s affine region %s: lift repeat %d: %d verts under the target (max %.1f mm), lifted max %.1f mm, '
                                   'now min height %.1f mm, %d inside' % (ch, m['mat'][-14:], it2 + 1, int((need2 > 1e-4).sum()), need2.max() * 1000,
                                                                       (L2 / cs).max() * 1000, h2.min() * 1000, int((h2 < 0).sum())))
                Pg = Pg.copy(); Pg[rg] = Pg[rg] + wr[rg][:, None] * (P2 - Pg[rg])
                AFF_[mi] = (wr, Pg.copy())
                log.append('%s affine region %s: %d verts, wrapped then lifted median %.1f max %.1f mm' % (ch, m['mat'][-14:], len(rg), np.median(Lf) * 1000, Lf.max() * 1000))
        # cloth lying over the underside of OUR breast (skin faces down) bridges straight down instead of following the fold
        legs = A.part[A.T[t, 0]] == 1
        chest = (~legs) & (q[:, 1] > 1.08) & (q[:, 1] < 1.33) & (q[:, 2] > 0.02)
        rel = chest * np.clip((-qn[:, 1] - 0.30) / 0.25, 0, 1)
        kl = np.zeros(len(V0))
        if any(k in m['mat'] for k in CFG.get('drape', [])):
            # the cape hangs from the bust: below it, it must not be pulled back in to the waist when our bust is bigger
            k = np.clip(gain / 0.02, 0, 1) * (V0[:, 2] > 0.0) * np.clip((1.20 - V0[:, 1]) / 0.04, 0, 1)
            rel = np.maximum(rel, k)
        lw = np.ones(len(V0))
        if any(k in m['mat'] for k in CFG.get('loose', [])):
            # loose garments hang from a bigger bust instead of being glued back onto the ribs/belly below it:
            # the front below the bust is released and filled smoothly (bridges down from the bust)
            # ... only where the cloth stands off the author's body itself (6 -> 14 mm, smoothed over the cloth): tight
            # parts of a 'loose' piece (a fitted vanilla top with a flared belt) kept hugging, instead of tenting 3 cm
            lw = np.clip((off - 0.006) / 0.008, 0, 1)
            for _ in range(6): lw = (G.W @ G.avg(lw))[G.key]
            lw = np.clip(lw * 1.25, 0, 1)
            k = (np.clip(gain / 0.02, 0, 1) * np.clip((V0[:, 2] - 0.0) / 0.03, 0, 1) * np.clip((0.16 - np.abs(V0[:, 0])) / 0.05, 0, 1)
                 * np.clip((1.21 - V0[:, 1]) / 0.05, 0, 1) * np.clip((V0[:, 1] - TT.get('below', 0.0)) / 0.05, 0, 1)) * lw * float(CFG.get('hang', 1.0))
            rel = np.maximum(rel, k); kl = np.maximum(kl, k)
            # ... and bridge the cleavage instead of following each breast into it: cloth over OUR skin that faces the
            # midline (the inner sides of the breasts) is released and filled from the breast fronts (a hoodie on
            # NIRÆ Large hugged both breasts and the tie on it dived into the cleavage)
            if not CFG.get('follow_cleavage'):
                fm = -np.sign(q[:, 0]) * qn[:, 0]
                k2 = (chest * np.clip((fm - 0.30) / 0.25, 0, 1) * np.clip((0.07 - np.abs(q[:, 0])) / 0.02, 0, 1)
                      * np.clip(V0[:, 2] / 0.03, 0, 1))
                rel = np.maximum(rel, k2); kl = np.maximum(kl, k2)
                log.append('%s %s cleavage bridged: %d verts released' % (ch, m['mat'][-8:-5], int((k2 > 0.5).sum())))
        if TT and any(k_ in m['mat'] for k_ in CFG.get('loose', [])):
            # tighten: the lower part of a loose top sits closer to the body than the author made it
            # (its height above the skin shrinks: h' = min + (h - min) * scale), glued all around
            r_ = np.clip((TT['below'] - V0[:, 1]) / 0.06, 0, 1)
            r_ = r_ * (TT.get('side', 1.0) + (1 - TT.get('side', 1.0)) * np.clip((V0[:, 2] + 0.02) / 0.06, 0, 1))   # front fully, sides/back less
            offt = np.where(off > TT['min'], TT['min'] + (off - TT['min']) * TT['scale'], off)
            offu = off + r_ * (offt - off)
            Pg = q + offu[:, None] * qn
            a = np.maximum(a, r_)
        a = a * (1 - rel)
        Db = np.einsum('ni,nid->nd', bw, (QA - A.P)[A.T[t]])          # skin displacement under the vertex
        # cloth floating 1.6-7 cm off the author's skin (padded cups, cape) follows the skin under it (keeps its float)
        af = 0.3 * np.clip((0.070 - dist) / 0.054, 0, 1) * (1 - a) * (1 - rel)
        # a faint pull toward the skin's own move everywhere (keeps free cloth with the body) - nearly none where a loose
        # garment is released: over a big released front it outweighed the smooth fill and wrapped the hoodie under
        # each breast again (Rebel Rabbit, NIRÆ Saggy)
        wb = G.avg(0.002 * (1 - 0.9 * kl))
        wa = G.avg(a + af) + wb
        tgt = (G.avg(a[:, None] * (Pg - V0)) + G.avg(af[:, None] * Db) + wb[:, None] * G.avg(Db)) / wa[:, None]
        log.append('%s %s anchored %d/%d released-under-breast %d' % (ch, m['mat'][-8:-5], int((a > 0.5).sum()), m['nv'], int((rel > 0.5).sum())))
        res.append(dict(mi=mi, G=G, V0=V0, I=I, wa=wa, tgt=tgt, off=off, sn=sn, mat=m['mat'], loose=any(k in m['mat'] for k in CFG.get('loose', [])), aff=AFF_.get(mi), lw=lw))
    return res

def layer_pairs(items, lim=0.03, latlim=0.004):
    """author layer order between pieces. For every vertex v of piece i and the point q right above/below it on piece j
    (same skin spot): da = author height(v) - author height(q). da>0: v must stay over j; da<0: j's triangle must stay over v."""
    offs = np.cumsum([0] + [len(it['V0']) for it in items]); R = []
    for i, a in enumerate(items):
        for j, b in enumerate(items):
            if i == j: continue
            # alternative copies of one garment (toggled skirts): no layer order between them
            if any(k in a['mat'] and k in b['mat'] for k in CFG.get('alternatives', [])): continue
            C = Surf.__new__(Surf); C.P = b['V0']; C.T = b['I']; C.C = cKDTree(b['V0'][b['I']].mean(1))
            t, w, q, d = C.closest(a['V0'], k=8)
            dv = a['V0'] - q; h = np.einsum('nd,nd->n', dv, a['sn']); lat = np.linalg.norm(dv - h[:, None] * a['sn'], axis=1)
            offq = np.einsum('ni,ni->n', w, b['off'][b['I'][t]])
            da = a['off'] - offq
            ok = (d < lim) & (lat < latlim) & (np.abs(da) > 0.0008)
            # tight layers (<4 mm apart) keep their order everywhere; the cape keeps floating over everything
            dr = lambda mat: any(k in mat for k in CFG.get('drape', []))
            cape_out = dr(a['mat']) & (da > 0) | dr(b['mat']) & (da < 0)
            ok &= (np.abs(da) < 0.004) | cape_out
            v = np.where(ok)[0]
            R.append((v + offs[i], b['I'][t[ok]] + offs[j], w[ok], da[ok], np.full(len(v), j)))
    if not R: return np.zeros(0, int), np.zeros((0, 3), int), np.zeros((0, 3)), np.zeros(0)   # single cloth piece
    v, tv, w, da, jj = [np.concatenate(x) for x in zip(*R)]
    # a part (connected piece of cloth) that is both over and under the same mesh pierces it in the author's model
    # (stitches, threads, a lip cutting through the layer below): no consistent order there, skip all its pairs
    cid = np.concatenate([it['G'].comp[it['G'].key] + 100000 * k for k, it in enumerate(items)])
    key = cid[v] * 16 + jj
    up = set(key[da > 0].tolist()); dn = set(key[da < 0].tolist()); bad = up & dn
    keep = np.array([k not in bad for k in key.tolist()], bool)
    return v[keep], tv[keep], w[keep], da[keep]

def needs(Ps, Is, B, gap=GAP, reach=0.02, pairs=None):
    """how far each cloth vertex must rise along the skin normal: (a) the vertex itself is too close / inside,
    (b) skin pokes through the middle of a cloth triangle (nipples, coarse cups)"""
    P = np.concatenate(Ps)
    t, w, q, d = B.closest(P); n = B.nrm(t, w)
    sd = np.einsum('nd,nd->n', P - q, n)
    if hasattr(B, 'Ns'):
        n = B.at(t, w, B.Ns); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
    need = np.where(((d < reach) & (sd < gap)) | ((d < 0.06) & (sd < 0)), gap - sd, 0.0)
    o = 0; Ts = []
    for Pi, I in zip(Ps, Is): Ts.append(I + o); o += len(Pi)
    C = Surf.__new__(Surf); C.P = P; C.T = np.concatenate(Ts); C.C = cKDTree(P[C.T].mean(1))
    # skin near the cloth: near a vertex, or near the middle / an edge of a big triangle (the game's own low-poly gear
    # has 5-8 cm triangles: skin poking through their middle was more than 2 cm from every corner and went unseen)
    Tall = C.T; Mid = np.r_[P, P[Tall].mean(1), 0.5 * (P[Tall[:, 0]] + P[Tall[:, 1]]), 0.5 * (P[Tall[:, 1]] + P[Tall[:, 2]]), 0.5 * (P[Tall[:, 2]] + P[Tall[:, 0]])]
    near = cKDTree(Mid).query(B.P, distance_upper_bound=0.02)[0] < 0.02
    used = np.zeros(len(B.P), bool); used[np.unique(B.T)] = True        # (arm vertices are not part of the collider)
    sp = np.where(near & used)[0]
    if len(sp):
        tt, ww, qq, dd = C.closest(B.P[sp], k=8)
        dv = qq - B.P[sp]; h = np.einsum('nd,nd->n', dv, B.N[sp]); lat = np.linalg.norm(dv - h[:, None] * B.N[sp], axis=1)
        # only skin that faces the cloth there (|cos| > 0.3 between the skin normal and the cloth triangle): the walls of
        # NIRÆ's closed vulva slit face sideways under a crotch strip; counting them pushed the strip 17 mm down per
        # round until it hung under the crotch (Gothkini panties)
        Tc = C.T[tt]; Tn = np.cross(P[Tc[:, 1]] - P[Tc[:, 0]], P[Tc[:, 2]] - P[Tc[:, 0]]); Tn /= np.maximum(np.linalg.norm(Tn, axis=1), 1e-12)[:, None]
        facing = np.abs(np.einsum('nd,nd->n', Tn, B.N[sp])) > 0.3
        # and only outer skin: inner surfaces of the closed vulva face UP into the body (their normal disagrees with the
        # skin normal averaged over 2.5 cm); the cloth under them always looked 'pushed through' and was shoved down
        if hasattr(B, 'Ns'): facing &= np.einsum('nd,nd->n', B.N[sp], B.Ns[sp]) > 0.2
        bad = (dd < 0.02) & (lat < 0.003) & (h < gap) & facing
        for k in range(3):
            v = C.T[tt[bad], k]; np.maximum.at(need, v, gap - h[bad])
    needL = np.zeros(len(P))
    if pairs is not None:
        v, tv, w, da = pairs
        h = sd; hq = np.einsum('ni,ni->n', w, h[tv]); dob = h[v] - hq
        up = da > 0
        tgt = np.clip(0.8 * np.abs(da), 0.0006, 0.003)     # keep (most of) the author's own spacing, never inflate it
        np.maximum.at(needL, v[up], np.maximum(tgt[up] - dob[up], 0))           # outer vertex over inner triangle
        miss = np.maximum(tgt[~up] + dob[~up], 0)                              # inner vertex under outer triangle
        for k in range(3): np.maximum.at(needL, tv[~up, k], miss)
    return need, n, needL

class Drape:
    """loose garments hang from the bust: in front, below the bust, cloth may come back in toward the body by at most
    K per unit of drop (z >= max over skin above it of z' - K*(y'-y)) plus its own author looseness"""
    def __init__(s, B, K=0.45, bw=0.006):
        S = B.P[(B.P[:, 2] > 0.0) & (np.abs(B.P[:, 0]) < 0.2)]
        s.K = K; s.bw = bw; s.cols = {}
        g = S[:, 2] - K * S[:, 1]; b = np.floor(S[:, 0] / bw).astype(int)
        for c in np.unique(b):
            m = np.abs(b - c) <= 1; y = S[m, 1]; o = np.argsort(-y)
            s.cols[c] = (-y[o], np.maximum.accumulate(g[m][o]))
    def env(s, P):
        out = np.full(len(P), -np.inf); b = np.floor(P[:, 0] / s.bw).astype(int)
        for c in np.unique(b):
            if c not in s.cols: continue
            ny, cm = s.cols[c]; k = b == c
            j = np.searchsorted(ny, -(P[k, 1] + 0.02), side='left') - 1     # skin at least 2 cm higher (not the slope beside it)
            ok = j >= 0; e = np.full(k.sum(), -np.inf); e[ok] = cm[j[ok]] + s.K * P[k, 1][ok]; out[k] = e
        return out


def _nbr(P, r):
    """neighbourhoods within r of every point (itself included) as CSR (cols, indptr): the same sets as
    cKDTree.query_ball_point(P, r), for vectorised maxima / means"""
    pr = cKDTree(P).query_pairs(r, output_type='ndarray')
    n = len(P); ar = np.arange(n)
    rows = np.r_[ar, pr[:, 0], pr[:, 1]]; cols = np.r_[ar, pr[:, 1], pr[:, 0]]
    o = np.argsort(rows, kind='stable')
    return cols[o], np.searchsorted(rows[o], np.arange(n + 1))


def _nmax(v, nbr):
    return np.maximum.reduceat(v[nbr[0]], nbr[1][:-1])


def _nmean(v, nbr):
    return np.add.reduceat(v[nbr[0]], nbr[1][:-1]) / np.diff(nbr[1])

def collide(items, B, log, ch, r=0.006, iters=16):
    cw = [np.zeros(it['G'].n) for it in items]; ct = [np.zeros((it['G'].n, 3)) for it in items]
    pairs = layer_pairs(items)
    log.append('%s layer pairs %d' % (ch, len(pairs[0])))
    drape = None
    if CFG.get('drape_envelope') and any(it['loose'] for it in items):
        drape = Drape(B)
        V0c = np.concatenate([it['V0'] for it in items]); offc = np.concatenate([it['off'] for it in items])
        lo = np.concatenate([np.full(len(it['V0']), it['loose']) for it in items])
        dmask = lo & (V0c[:, 2] > 0.03) & (np.abs(V0c[:, 0]) < 0.10) & (V0c[:, 1] < 1.20) & (V0c[:, 1] > 0.75)
        gapd = np.clip(offc, 0.002, 0.03)
    for k in range(iters):
        Ps = []
        for j, it in enumerate(items):
            G = it['G']; wa = it['wa'] + cw[j]
            tg = (it['wa'][:, None] * it['tgt'] + cw[j][:, None] * ct[j]) / wa[:, None]
            Ps.append(it['V0'] + G.solve(wa, tg)[G.key])
        if k == 0:
            # pairs the fit already crosses by a lot are structural (e.g. corset lip under a bigger bust): don't fight them
            P0 = np.concatenate(Ps); t0, w0, q0, d0 = B.closest(P0); h0 = np.einsum('nd,nd->n', P0 - q0, B.nrm(t0, w0))
            v_, tv_, w_, da_ = pairs; dob0 = h0[v_] - np.einsum('ni,ni->n', w_, h0[tv_])
            viol0 = np.where(da_ > 0, -dob0, dob0)
            keep = viol0 < 0.006
            pairs = (v_[keep], tv_[keep], w_[keep], da_[keep])
            log.append('%s layer pairs kept %d dropped (structural crossing) %d' % (ch, int(keep.sum()), int((~keep).sum())))
        need, n, needL = needs(Ps, [it['I'] for it in items], B, pairs=pairs)
        P = np.concatenate(Ps)
        if drape is not None:
            # front of loose pieces below the bust: hang from it (push straight forward)
            e = drape.env(P) + gapd
            nd = np.where(dmask, e - P[:, 2], 0); nd[~np.isfinite(nd)] = 0; nd = np.maximum(nd, 0)
            usez = nd > need
            need = np.maximum(need, nd); n = np.where(usez[:, None], np.array([0, 0, 1.0]), n)
        if max(need.max(), needL.max()) < 5e-5: break
        NB = _nbr(P, r)
        L = _nmax(need, NB)
        if CFG.get('smooth_nipples'):
            # tight fabric over a nipple lifts as a wide smooth tent (2 cm), not a small bump
            R_ = 0.02; hot = np.where(need > 0)[0]
            if len(hot):
                for jj_, i_ in zip(cKDTree(P[hot]).query_ball_point(P, R_), range(len(P))):
                    if jj_:
                        dd_ = np.linalg.norm(P[hot[jj_]] - P[i_], axis=1)
                        L[i_] = max(L[i_], float((need[hot[jj_]] * np.clip(1 - (dd_ / R_) ** 2, 0, 1)).max()))
        # layer-order needs move only the outer piece (spreading them to the layer below would never separate the two)
        mid = np.repeat(np.arange(len(items)), [len(it['V0']) for it in items])
        same = mid[NB[0]] == np.repeat(mid, np.diff(NB[1]))
        LL = np.maximum.reduceat(np.where(same, needL[NB[0]], -np.inf), NB[1][:-1])
        L = np.maximum(L, LL); need0 = need; need = np.maximum(need, needL)
        o = 0
        for j, it in enumerate(items):
            G = it['G']; nv = len(it['V0']); Lj = L[o:o + nv]; nj = n[o:o + nv]; o += nv
            Lw = np.zeros(G.n); np.maximum.at(Lw, G.key, Lj)
            if not (Lw > 0).any(): continue
            Dcur = G.avg(Ps[j] - it['V0']); nw = G.avg(nj); nw /= np.maximum(np.linalg.norm(nw, axis=1), 1e-9)[:, None]
            m = Lw > 0
            ct[j][m] = Dcur[m] + (Lw[m] * 1.15)[:, None] * nw[m]; cw[j][m] = 20.0
        log.append('%s collide iter %d max need %.1f mm, verts %d (skin %.1f / layers %.1f mm)' % (ch, k, need.max() * 1000, int((need > 0).sum()), need0.max() * 1000, needL.max() * 1000))
    items[0]['_pairs'] = pairs
    return Ps

def lift(Ps, B, gap=GAP, reach=0.02, r=0.006, iters=4):
    """smooth lift along the skin normal; every layer over a spot rises together"""
    P = np.concatenate(Ps); sizes = [len(x) for x in Ps]
    total = np.zeros(len(P))
    for it in range(iters):
        t, w, q, d = B.closest(P); n = B.nrm(t, w)
        sd = np.einsum('nd,nd->n', P - q, n)
        need = np.where(((d < reach) & (sd < gap)) | ((d < 0.06) & (sd < 0)), gap - sd, 0.0)
        if need.max() < 2e-5: break
        NB = _nbr(P, r)
        L = _nmax(need, NB)
        L = _nmean(L, NB) if it < iters - 1 else np.maximum(L, need)
        P = P + L[:, None] * n; total += L
    out = []; o = 0
    for s in sizes: out.append(P[o:o + s]); o += s
    return out, total

ARM = ('j_ude_a', 'j_ude_b', 'n_hhiji', 'n_hte', 'j_te', 'n_hkata', 'j_oya')
def outer_only(B, log=None, ch=''):
    """our skin without the inside of the vulva (NIRÆ's closed vulva: slit walls and the vestibule facing up into the
    body): triangles of the vulva pieces whose normal disagrees with the skin normal averaged over 2.5 cm. Cloth is
    measured against the outer shell only: the inner faces made the collision, the lifts and the closest-point weights
    treat a crotch strip under the vulva as 'inside' and shove it down (Gothkini thong hung 5-8 mm under the crotch)"""
    if not hasattr(B, 'vulva') or not B.vulva.any(): return B
    T = B.T; vt = B.vulva[T].all(1)
    if not vt.any(): return B
    vv = np.unique(T[vt]); nb = cKDTree(B.P).query_ball_point(B.P[vv], 0.025)
    Ns = np.zeros_like(B.P); Ns[vv] = np.array([B.N[j].sum(0) for j in nb]); Ns /= np.maximum(np.linalg.norm(Ns, axis=1), 1e-9)[:, None]
    Tv = T[vt]; fn = np.cross(B.P[Tv[:, 1]] - B.P[Tv[:, 0]], B.P[Tv[:, 2]] - B.P[Tv[:, 0]]); fn /= np.maximum(np.linalg.norm(fn, axis=1), 1e-12)[:, None]
    inner = np.einsum('nd,nd->n', fn, Ns[Tv].mean(1)) < 0.2
    keep = np.ones(len(T), bool); keep[np.where(vt)[0][inner]] = False
    S = Surf(B.P, T[keep], B.UV, B.part, B.W, B.names); S.vulva = B.vulva
    if log is not None: log.append('%s outer skin: %d inner vulva triangles left out of %d vulva triangles' % (ch, int(inner.sum()), int(vt.sum())))
    return S

def no_arms(B):
    """collision surface without the arms (cloth near the armpit must not be pushed along the arm's normals)"""
    aw = B.W[:, [i for i, n in enumerate(B.names) if n.startswith(ARM)]].sum(1)
    # (excluding the arm triangles left an open edge at the shoulder whose normals pushed the cape up: keep them)
    S = Surf(B.P, B.T, B.UV, B.part, B.W, B.names)
    # push direction: skin normal averaged over 2.5 cm, so cloth in a fold (under a hanging breast) is pushed out
    # of the fold instead of deeper into it along the breast's underside
    nb = cKDTree(B.P).query_ball_point(B.P, 0.025)
    Ns = np.array([S.N[j].sum(0) for j in nb]); S.Ns = Ns / np.maximum(np.linalg.norm(Ns, axis=1), 1e-9)[:, None]
    return S

# ---------------------------------------------------------------- body shape variants for the cloth
def variant_field(P, B, Dk, G, near=0.015, far=0.060):
    t, w, q, d = B.closest(P)
    tree = cKDTree(B.P); dd, jj = tree.query(P, k=8)
    wi = 1 / np.maximum(dd, 1e-4) ** 2; wi /= wi.sum(1, keepdims=True)
    Dv = np.einsum('nk,nkd->nd', wi, Dk[jj])
    a = np.clip((far - d) / (far - near), 0, 1)
    wb = 0.004
    wa = G.avg(a) + wb
    tgt = G.avg(a[:, None] * Dv) / wa[:, None]
    D = G.solve(wa, tgt, mu=0.6, nu=0.05)[G.key]
    return D

def smooth_mask(G, mag, lo, hi):
    m = np.clip((G.avg(mag) - lo) / (hi - lo), 0, 1)
    for _ in range(2): m = np.maximum(m, G.W @ m * 0.999)   # never shrink the moving region
    return m[G.key]

# ---------------------------------------------------------------- weights from the body
SKIRT_PREFIX = 'j_sk'
def body_weights(P, B, Wc_names, Wc, near=0.008, far=0.020):
    t, w, q, d = B.closest(P)
    Wb = np.einsum('ni,nij->nj', w, B.W[B.T[t]])
    names = sorted(set(Wc_names) | set(B.names))
    F = np.zeros((len(P), len(names))); F[:, [names.index(n) for n in Wc_names]] = Wc
    Fb = np.zeros((len(P), len(names))); Fb[:, [names.index(n) for n in B.names]] = Wb
    skirt = (Wc[:, [i for i, n in enumerate(Wc_names) if n.startswith(SKIRT_PREFIX)]].sum(1) > 0) if any(n.startswith(SKIRT_PREFIX) for n in Wc_names) else np.zeros(len(P), bool)
    tt = np.clip((far - d) / (far - near), 0, 1); tt[skirt] = 0
    # arms: cloth near the arm (cape) keeps the author's own arm rigging; elsewhere arm bones are not taken from the body
    armc = [i for i, n in enumerate(names) if n.startswith(ARM + ('iv_nitoukin',))]
    af = Fb[:, armc].sum(1); tt[af > 0.3] = 0
    Fb[:, armc] = 0; Fb /= np.maximum(Fb.sum(1, keepdims=True), 1e-9)
    out = (1 - tt[:, None]) * F + tt[:, None] * Fb
    return add_jiggle(out, names, Fb, d, skirt, af), names, tt

# body jiggle bones every outfit takes advantage of: breasts, pecs, belly, butt, thighs (never genital/arm bones)
JIGGLE = ('iv_c_mune', 'iv_kyokin_phys', 'iv_fukubu_phys', 'ya_fukubu_phys', 'iv_shiri', 'ya_shiri_phys', 'iv_daitai_phys', 'ya_daitai_phys')
JIG_FULL, JIG_ZERO, JIG_SKIRT = 0.020, 0.050, 0.6
def add_jiggle(F, names, Fb, d, skirt, af):
    """loose cloth beyond the glued zone still jiggles with the body under it: up to JIG_FULL from the skin it takes the
    body's full jiggle share at that skin spot, fading to 0 at JIG_ZERO (skirt-bone cloth gets JIG_SKIRT of it, so the
    skirt bones still swing it). The jiggle weight replaces the parent bones' share, so the cloth's rest motion is kept."""
    jc = [i for i, n in enumerate(names) if n.startswith(JIGGLE)]
    if not jc: return F
    Jb = Fb[:, jc]; share = Jb.sum(1)
    reach = np.clip((JIG_ZERO - d) / (JIG_ZERO - JIG_FULL), 0, 1) * np.where(skirt, JIG_SKIRT, 1.0) * (af < 0.3)
    target = share * reach
    have = F[:, jc].sum(1)
    up = target > have + 1e-4
    if not up.any(): return F
    F = F.copy(); rest = 1 - have
    k = np.where(up, (1 - target) / np.maximum(rest, 1e-9), 1.0)
    nonj = np.ones(F.shape[1], bool); nonj[jc] = False
    F[:, nonj] *= k[:, None]
    dist = Jb / np.maximum(share, 1e-9)[:, None]
    F[np.ix_(up, jc)] = (target[up, None] * dist[up])
    return F


def quant(Wf, names):
    used = np.nonzero(Wf.sum(0) > 1e-6)[0]; tbl = [names[j] for j in used]; Wf = Wf[:, used]
    if Wf.shape[1] < 8: Wf = np.c_[Wf, np.zeros((len(Wf), 8 - Wf.shape[1]))]
    order = np.argsort(-Wf, 1)[:, :8]; top = np.take_along_axis(Wf, order, 1); top /= np.maximum(top.sum(1, keepdims=True), 1e-12)
    q8 = np.floor(top * 255).astype(int); rem = 255 - q8.sum(1)
    frac = top * 255 - q8
    for r in np.nonzero(rem)[0]: q8[r, np.argsort(-frac[r])[:rem[r]]] += 1
    order = np.where(q8 > 0, order, 0)
    return q8.astype(np.uint8), order.astype(np.uint8), tbl


# ---------------------------------------------------------------- skin-tight garments (underwear): relax + pose-aware lift
def relax_tight(Ps, items, log, ch):
    """restore the author's local shape where the fit crumpled it (crotch between touching thighs): keep the author's
    Laplacian (detail, lace edges) and stay near the fit where it is smooth"""
    out = []
    for P, it in zip(Ps, items):
        G = it['G']; V0 = it['V0']
        D = G.avg(P - V0); r = np.linalg.norm(G.L @ D, axis=1)
        wa = np.clip(1.0 - (r - 0.0004) / 0.0012, 0.03, 1.0)
        Dn = G.solve(wa, D, mu=1.0, nu=0.0)
        out.append(V0 + Dn[G.key])
        log.append('%s relax: rough verts %d, max move %.1f mm' % (ch, int((r > 0.0008).sum()), np.linalg.norm(Dn - D, axis=1).max() * 1000))
    return out

def pose_lift(Ps, items, Bw, Bc, Xm, log, ch, cap=0.003, iters=3):
    """approximate animation (thigh swing/abduction/sitting/jiggle, linear blend skinning with the body's weights):
    where cloth goes under the posed skin, lift it at rest (smooth, capped) so it stays out in motion"""
    import pose as PZ
    bary_ = PZ.bary_
    SW = Bw.W; SN = Bw.names
    cl = PZ.pivot(Bw.P, SW, SN, PZ.LEFT); cr = PZ.pivot(Bw.P, SW, SN, PZ.RIGHT)
    specs = dict(PZ.poses(cl, cr)); specs.pop('sit')
    specs['sit60'] = {'rot': [(PZ.LEFT, PZ.rotm((1, 0, 0), -60), cl), (PZ.RIGHT, PZ.rotm((1, 0, 0), -60), cr)]}
    posed = {k: Surf(PZ.pose_pts(Bw.P, SW, SN, None, sp), Bw.T, None, Bw.part) for k, sp in specs.items()}
    total = [np.zeros(len(P)) for P in Ps]
    for it_ in range(iters):
        worst = 0.0
        for k_, (P, it) in enumerate(zip(Ps, items)):
            m = Xm[it['mi']]; Wc = dense_w(m)
            W, names, _ = body_weights(P, Bw, m['table'], Wc)
            T = it['I']; need = np.zeros(len(P))
            for k, sp in specs.items():
                C = PZ.pose_pts(P, W, names, None, sp)
                S = np.einsum('kb,tbd->tkd', bary_, C[T]); Sf = S.reshape(-1, 3)
                t, w, q, d = posed[k].closest(Sf); n = posed[k].nrm(t, w); h = np.einsum('nd,nd->n', Sf - q, n)
                pen = np.where((d < 0.03), np.maximum(0.0006 - h, 0), 0).reshape(len(T), -1)
                # a sample's need goes to the triangle's vertices by barycentric share
                for j in range(3):
                    np.maximum.at(need, T[:, j], (pen * (bary_[None, :, j] > 0.3)).max(1))
            need = np.minimum(need, np.maximum(cap - total[k_], 0))
            worst = max(worst, need.max())
            if need.max() < 5e-5: continue
            nb = cKDTree(P).query_ball_point(P, 0.006)
            L = np.array([need[j].max() for j in nb]); L = np.array([L[j].mean() for j in nb])
            t, w, q, d = Bc.closest(P); nn = Bc.nrm(t, w)
            Ps[k_] = P + L[:, None] * nn; total[k_] += L
        log.append('%s pose lift iter %d: max need %.1f mm' % (ch, it_, worst * 1000))
        if worst < 5e-5: break
    return Ps, np.concatenate(total)

def settle(Ps, items, Bc, log, ch):
    """tight crotch cloth that ended further off the skin than the gap (collision overshoot + pose lift: the Gothkini
    thong strip hung 5-8 mm under the crotch where the author's sits 1 mm off): pulled back to the gap along the skin
    normal, as a smooth field, where the author had it within 3 mm of their skin. cfg "settle": {"box": [|x| <, y <,
    z >, z <], "gap": m} (default box = crotch, gap = GAP + 0.5 mm)"""
    st = CFG.get('settle')
    if not st: return Ps
    bx = st.get('box', [0.025, 0.90, -0.05, 0.07]); g_ = st.get('gap', GAP + 0.0005)
    out = []
    for P, it in zip(Ps, items):
        t, w, q, d = Bc.closest(P); n = Bc.nrm(t, w); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-9)[:, None]
        h = np.einsum('nd,nd->n', P - q, n)
        reg = ((np.abs(P[:, 0]) < bx[0]) & (P[:, 1] < bx[1]) & (P[:, 2] > bx[2]) & (P[:, 2] < bx[3]) & (it['off'] < 0.003)
               & (h > g_ + 0.001) & (d < 0.03))
        if not reg.any(): out.append(P); continue
        G = it['G']; dsp = np.where(reg[:, None], (g_ - h)[:, None] * n, 0.0)
        Dn = G.solve(G.avg(np.where(reg, 1.0, 0.3)), G.avg(dsp))[G.key]
        out.append(P + Dn)
        log.append('%s settle %s: %d verts pulled back to %.1f mm, moved max %.1f mm' % (ch, it['mat'][-14:], int(reg.sum()), g_ * 1000, np.linalg.norm(Dn, axis=1).max() * 1000))
    return out

def arap_settle(Ps, items, Bc, log, ch):
    """tight cloth inside a box (author space; the crotch) relaxed as-rigid-as-possible against the author's own shape
    while it stays at its height over our skin (max(author height, GAP)), the rest of the piece fixed: an evenly
    stretched panel instead of ripples where the fit squeezed it sideways and stretched it lengthwise (Gothkini front
    panel: edges 0.8x-1.6x the author's, bunched lacing). cfg "arap": {"mats": [...], "box": [|x|, ymax, zmin, zmax], "iters": n}"""
    cf = CFG.get('arap')
    if not cf: return Ps
    from scipy.sparse import coo_matrix
    from scipy.sparse.linalg import factorized
    bx = cf.get('box', [0.06, 0.905, -0.10, 0.10]); iters = cf.get('iters', 25)
    out = list(Ps)
    for k, it in enumerate(items):
        if not any(m_ in it['mat'] for m_ in cf.get('mats', [])): continue
        G = it['G']; key = G.key; n = G.n
        A0 = G.avg(it['V0']); X = G.avg(Ps[k]); offn = G.avg(it['off'])
        Tn = key[it['I']]; E = np.unique(np.sort(np.r_[Tn[:, [0, 1]], Tn[:, [1, 2]], Tn[:, [2, 0]]], 1), axis=0); E = E[E[:, 0] != E[:, 1]]
        nbrs = [[] for _ in range(n)]
        for a, b in E: nbrs[a].append(b); nbrs[b].append(a)
        reg = (np.abs(A0[:, 0]) < bx[0]) & (A0[:, 1] < bx[1]) & (A0[:, 2] > bx[2]) & (A0[:, 2] < bx[3]) & (np.array([len(x) for x in nbrs]) > 0)
        free = np.where(reg)[0]
        if len(free) < 10: continue
        fi = -np.ones(n, int); fi[free] = np.arange(len(free))
        rr, cc, vv = [], [], []
        for i in free:
            rr.append(fi[i]); cc.append(fi[i]); vv.append(float(len(nbrs[i])))
            for j in nbrs[i]:
                if fi[j] >= 0: rr.append(fi[i]); cc.append(fi[j]); vv.append(-1.0)
        solve = factorized(coo_matrix((vv, (rr, cc)), shape=(len(free), len(free))).tocsc())
        th = np.maximum(offn, GAP); X0 = X.copy()
        for _ in range(iters):
            R = np.zeros((n, 3, 3))
            for i in free:
                js = nbrs[i]; S_ = (A0[js] - A0[i]).T @ (X[js] - X[i]); U, sv, Vt = np.linalg.svd(S_)
                Ri = Vt.T @ U.T
                if np.linalg.det(Ri) < 0: Vt[-1] *= -1; Ri = Vt.T @ U.T
                R[i] = Ri
            b = np.zeros((len(free), 3))
            for i in free:
                for j in nbrs[i]:
                    Rij = 0.5 * (R[i] + R[j]) if fi[j] >= 0 else R[i]
                    b[fi[i]] += Rij @ (A0[i] - A0[j])
                    if fi[j] < 0: b[fi[i]] += X[j]
            X[free] = np.c_[solve(b[:, 0]), solve(b[:, 1]), solve(b[:, 2])]
            t, w, q, d = Bc.closest(X[free]); nn = Bc.nrm(t, w); nn /= np.maximum(np.linalg.norm(nn, axis=1), 1e-9)[:, None]
            X[free] = q + nn * th[free][:, None]
        L0 = np.linalg.norm(A0[E[:, 0]] - A0[E[:, 1]], axis=1); Ee = E[reg[E[:, 0]] & reg[E[:, 1]]]
        rb = np.linalg.norm(X0[Ee[:, 0]] - X0[Ee[:, 1]], axis=1) / np.maximum(np.linalg.norm(A0[Ee[:, 0]] - A0[Ee[:, 1]], axis=1), 1e-9)
        ra = np.linalg.norm(X[Ee[:, 0]] - X[Ee[:, 1]], axis=1) / np.maximum(np.linalg.norm(A0[Ee[:, 0]] - A0[Ee[:, 1]], axis=1), 1e-9)
        out[k] = X[key]
        log.append('%s arap %s: %d nodes, edge length vs author p10/median/p90 %.2f/%.2f/%.2f -> %.2f/%.2f/%.2f' % (
            ch, it['mat'][-14:], len(free), *np.percentile(rb, [10, 50, 90]), *np.percentile(ra, [10, 50, 90])))
    return out

def bind_layers(Ps, items, log, ch):
    """decorative layers (lacing, bows, trims) follow the fitted base cloth under them exactly: each layer vertex is bound
    in the author's model to the closest point of its base piece (triangle + barycentric, height along the base normal,
    leftover offset in the base triangle's frame) and rebuilt on the fitted base. Pushed on their own by the collision,
    thin ribbons kinked (Gothkini bra lacing). cfg "bind": {"layer material substring": "base material substring"}"""
    spec = CFG.get('bind') or {}
    if not spec: return Ps
    Ps = list(Ps)
    def frame(P, T, t, n):
        e = P[T[t, 1]] - P[T[t, 0]]; e -= n * np.einsum('nd,nd->n', e, n)[:, None]; e /= np.maximum(np.linalg.norm(e, axis=1), 1e-12)[:, None]
        return np.stack([e, np.cross(n, e), n], 2)
    for j, it in enumerate(items):
        key = [k for k in spec if k in it['mat']]
        if not key: continue
        base = [k for k, ib in enumerate(items) if spec[key[0]] in ib['mat'] and k != j]
        if not base: log.append('%s bind: no base piece for %s' % (ch, it['mat'])); continue
        k = base[0]; Vb = items[k]['V0']; Ib = items[k]['I']
        S0 = Surf(Vb, Ib, None, None); t, bw, q, d = S0.closest(it['V0'])
        # a double-walled base (front and back face 0.5-0.8 mm apart): a layer vertex bound to the BACK wall ends up behind
        # the front wall after the fit (Gothkini Slim: the top lace strand hidden). Vertices lying behind their closest
        # triangle are re-bound to the closest triangle within 3 mm that they lie in front of (at most 1.5 mm further)
        if CFG.get('bind_front', False):   # off: on Gothkini Slim it did not bring the strand back and left specks at strand ends
            import surf as _sf
            FNb = np.cross(Vb[Ib[:, 1]] - Vb[Ib[:, 0]], Vb[Ib[:, 2]] - Vb[Ib[:, 0]]); FNb /= np.maximum(np.linalg.norm(FNb, axis=1), 1e-14)[:, None]
            back = np.flatnonzero((np.einsum('nd,nd->n', it['V0'] - q, FNb[t]) < 0) & (d < 0.004)); nre = 0
            if len(back):
                t, bw, q, d = t.copy(), bw.copy(), q.copy(), d.copy(); kdc = cKDTree(Vb[Ib].mean(1))
                for i_, cand in zip(back, kdc.query_ball_point(it['V0'][back], 0.003)):
                    cand = np.array(cand, int)
                    if not len(cand): continue
                    X = it['V0'][i_]; front = np.einsum('nd,nd->n', X - Vb[Ib[cand, 0]], FNb[cand]) > 0
                    if not front.any(): continue
                    cand = cand[front]; Ta, Tb_, Tc = Vb[Ib[cand, 0]], Vb[Ib[cand, 1]], Vb[Ib[cand, 2]]
                    cp = _sf._closest_on_tris(np.repeat(X[None], len(cand), 0), Ta, Tb_, Tc); dist_ = np.linalg.norm(cp - X, axis=1)
                    k_ = int(np.argmin(dist_))
                    if dist_[k_] > d[i_] + 0.0015: continue
                    bc = bary(cp[k_:k_ + 1], np.stack([Ta[k_:k_ + 1], Tb_[k_:k_ + 1], Tc[k_:k_ + 1]], 1))[0]; bc = np.clip(bc, 0, 1); bc /= bc.sum()
                    t[i_] = cand[k_]; bw[i_] = bc; q[i_] = cp[k_]; d[i_] = dist_[k_]; nre += 1
            log.append('%s bind %s: %d verts lay behind their closest base triangle, %d re-bound to the wall in front' % (ch, it['mat'][-14:], len(back), nre))
        n0 = S0.nrm(t, bw); n0 /= np.maximum(np.linalg.norm(n0, axis=1), 1e-12)[:, None]
        loc = np.einsum('nji,nj->ni', frame(Vb, Ib, t, n0), it['V0'] - q)
        S1 = Surf(Ps[k], Ib, None, None); n1 = S1.nrm(t, bw); n1 /= np.maximum(np.linalg.norm(n1, axis=1), 1e-12)[:, None]
        q1 = np.einsum('ni,nid->nd', bw, Ps[k][Ib[t]]); newP = q1 + np.einsum('nij,nj->ni', frame(Ps[k], Ib, t, n1), loc)
        near = d < 0.02
        # every layer vertex the author had ABOVE its base stays above the CLOSEST point of the fitted base, at least
        # 0.15 mm: bound to one triangle, a ribbon crossing a crease of the fitted base can end up under the next triangle.
        # Smoothed along the layer (dilate 2 mm, mean 3 mm): no kinks. (Heights along a 5 mm-averaged normal lifted 4819
        # lace verts up to 5.6 mm and crumpled the bow: don't)
        hA = loc[:, 2]; t2, w2, q2, d2 = S1.closest(newP); n2 = S1.nrm(t2, w2); n2 /= np.maximum(np.linalg.norm(n2, axis=1), 1e-12)[:, None]
        h2 = np.einsum('nd,nd->n', newP - q2, n2)
        lack = np.where(near & (hA > 1e-4), np.clip(np.clip(hA, 0.00015, 0.0015) - h2, 0, None), 0.0)
        if lack.max() > 1e-5:
            kdl = cKDTree(it['V0'])
            dil = np.array([lack[jj].max() for jj in kdl.query_ball_point(it['V0'], 0.002)])
            lk = np.array([dil[jj].mean() for jj in kdl.query_ball_point(it['V0'], 0.003)]); lk = np.maximum(lk, lack)
            newP = newP + (lk * near)[:, None] * n2
            log.append('%s bind %s: %d verts under the fitted base that the author had above it, lifted max %.2f mm' % (
                ch, it['mat'][-14:], int((lack > 1e-5).sum()), lk.max() * 1000))
        moved = np.linalg.norm(newP - Ps[j], axis=1)[near]
        Ps[j] = np.where(near[:, None], newP, Ps[j])
        log.append('%s bind %s onto %s: %d of %d verts, moved median %.1f max %.1f mm' % (ch, it['mat'][-14:], items[k]['mat'][-14:], int(near.sum()), len(near), np.median(moved) * 1000 if len(moved) else 0, moved.max() * 1000 if len(moved) else 0))
    return Ps

# ---------------------------------------------------------------- accessories that keep their shape
# Gluing every vertex to its own skin spot tears small hard pieces apart and squeezes or widens strips lying over the
# cleavage (Rebel Rabbit Bibo+ hoodie, NIRÆ Large: the tie squeezed to 1/3 of its width, a 4 mm pin spread to 23 mm
# on Flat, the 49 mm safety pins bent by 19 mm). Two kinds of pieces keep their author shape instead:
#   rigid: small separate pieces (pins, chain links, crosses, buttons, buckles, studs: largest extent < cfg rigid_max,
#          default 5 cm, not skin-tight) move as ONE solid piece with the cloth they sit on (best rigid motion of that
#          cloth patch), or with their own fit when nothing is under them; one weight set per piece (no tearing in
#          animation either)
#   stiff: narrow strips hanging over the chest on top of other cloth (ties, drawstrings, ribbons; found automatically,
#          cfg "stiff": [materials] adds whole materials, "auto_stiff": false turns the search off) are relaxed
#          as-rigid-as-possible against the author's own strip, pulled weakly to the fit and firmly at their top,
#          never inside the skin or the cloth under them
RIGID_MAX = 0.05


def kabsch(A, B, w=None):
    """best rotation R and centroids (ca, cb) with B ~ (A - ca) R^T + cb (weighted least squares)"""
    w = np.ones(len(A)) if w is None else np.asarray(w, float)
    w = w / max(float(w.sum()), 1e-12)
    ca = (w[:, None] * A).sum(0); cb = (w[:, None] * B).sum(0)
    H = ((A - ca) * w[:, None]).T @ (B - cb)
    U, S, Vt = np.linalg.svd(H)
    d = 1.0 if np.linalg.det(Vt.T @ U.T) >= 0 else -1.0
    return Vt.T @ np.diag([1.0, 1.0, d]) @ U.T, ca, cb


def rigid_project(P, V0, comps):
    """every rigid piece back to its author shape at its best rigid fit to P"""
    if not comps: return P
    P = P.copy()
    for v in comps:
        R, ca, cb = kabsch(V0[v], P[v]); P[v] = (V0[v] - ca) @ R.T + cb
    return P


def hang_loose(Ps, items, parts, Bc, log, ch, K=0.30, reach=0.15, cap=0.04):
    """loose garments hang from the bust: in every 6 mm column of the front (|x| < 13 cm), below the cloth's most
    forward point on the bust (y 1.08-1.32), the front may come back in toward the body by at most K (0.30) per unit of
    drop, for 15 cm (the author's hoodie comes back 18 mm 6 cm under its own apex = 0.3). Glued under a bigger bust it
    came back 46 mm there: wrapped under each breast. What lacks (at most 4 cm) is pushed straight forward as one smooth
    field (dilated 1.5 cm, mean 1.5 cm) through the cloth's own smooth solve; only the front-most layer counts.
    (Matching the author's own profile column by column pushed the kangaroo pocket 10 cm out: the author's 'apex' was
    the pocket in some columns. Don't)"""
    if CFG.get('no_hang') or float(CFG.get('hang', 1.0)) <= 0: return Ps
    K = K / max(float(CFG.get('hang', 1.0)), 0.25) if float(CFG.get('hang', 1.0)) < 1 else K   # less hang: the front comes back in faster
    Ps = list(Ps); done = []
    # the bust per 6 mm column, from OUR skin: its most forward point between y 1.08 and 1.32, a real bust only (5 mm
    # ahead of the skin 3 cm above and below it; a flat chest or the collar never counts as an apex)
    bw = 0.006; S_ = Bc.P[(Bc.P[:, 2] > 0) & (np.abs(Bc.P[:, 0]) < 0.14) & (Bc.P[:, 1] > 1.0) & (Bc.P[:, 1] < 1.40)]
    apex = {}
    for c in np.unique(np.floor(S_[:, 0] / bw).astype(int)):
        C_ = S_[np.abs(S_[:, 0] - (c + 0.5) * bw) < bw]; bd = C_[(C_[:, 1] > 1.08) & (C_[:, 1] < 1.32)]
        if len(bd) < 3: continue
        j = np.argmax(bd[:, 2]); ys, zs = bd[j, 1], bd[j, 2]
        up = C_[np.abs(C_[:, 1] - (ys + 0.03)) < 0.006]; dn = C_[np.abs(C_[:, 1] - (ys - 0.03)) < 0.006]
        if len(up) and len(dn) and zs - up[:, 2].max() > 0.005 and zs - dn[:, 2].max() > 0.005: apex[c] = ys
    for k, it in enumerate(items):
        if not it['loose'] or not apex: continue
        G = it['G']; P = Ps[k]; V0 = it['V0']
        skip = np.zeros(len(V0), bool)
        for v in parts[k]['stiff'] + parts[k]['rigid']: skip[v] = True
        used = np.zeros(len(V0), bool); used[np.unique(it['I'])] = True; ok = used & ~skip
        front = ok & (P[:, 2] > 0) & (np.abs(P[:, 0]) < 0.13) & (P[:, 1] > 0.80) & (P[:, 1] < 1.36)
        # only where the body faces forward (not the sides of the breasts: pushed straight forward there the cloth cut
        # through the breast's side and left a hole)
        t_, w_, q_, d_ = Bc.closest(P); fn = Bc.nrm(t_, w_)[:, 2] > 0.45
        need = np.zeros(len(P))
        for c in np.unique(np.floor(P[front, 0] / bw).astype(int)):
            if c not in apex: continue
            ya = apex[c]
            col = front & (np.abs(P[:, 0] - (c + 0.5) * bw) < bw)
            at = col & (np.abs(P[:, 1] - ya) < 0.008)
            if not at.any(): continue
            za = P[at, 2].max()
            below = np.where(col & fn & (P[:, 1] < ya) & (P[:, 1] > ya - reach))[0]
            if not len(below): continue
            zmin = za - K * (ya - P[below, 1])
            # front-most layer only: within 15 mm of the column's front at that height
            yb_ = np.round(P[below, 1] / 0.004).astype(int); fz = {}
            for y_, z_ in zip(yb_.tolist(), P[below, 2].tolist()): fz[y_] = max(fz.get(y_, -9), z_)
            fm = P[below, 2] > np.array([fz[y_] for y_ in yb_.tolist()]) - 0.015
            # fade out over the last 3 cm of the reach (no step at its end)
            fd = np.clip((P[below, 1] - (ya - reach)) / 0.03, 0, 1)
            need[below] = np.where(fm, np.minimum(np.maximum(zmin - P[below, 2], 0), cap) * fd, 0) * it.get('lw', np.ones(len(P)))[below]
        if need.max() < 5e-4: continue
        reg = np.where(cKDTree(P[need > 0]).query(P, distance_upper_bound=0.04)[0] < 0.04)[0]
        kd = cKDTree(P[reg]); nb = kd.query_ball_point(P[reg], 0.015); nr = need[reg]
        dil = np.array([nr[j].max() for j in nb]); L = np.zeros(len(P))
        L[reg] = np.array([dil[j].mean() for j in nb]); L = np.maximum(L, need) * ok
        Lw = np.zeros(G.n); np.maximum.at(Lw, G.key, L)
        m = Lw > 1e-5
        # one smooth increment through the cloth's own solve: the pushed front pulls the free cloth around it along, the
        # glued cloth (its glue weight) stays where the fit put it
        w = np.where(m, 20.0, 0.0) + it['wa']
        tg = np.zeros((G.n, 3)); tg[m, 2] = 20.0 * Lw[m] / w[m]
        dD = G.solve(w, tg)
        Ps[k] = np.where(ok[:, None], P + dD[G.key], P)
        done.append('%s: %d verts lacked up to %.1f mm, moved max %.1f mm' % (it['mat'][-10:-5], int((need > 5e-4).sum()), need.max() * 1000,
                                                                          np.linalg.norm(Ps[k] - P, axis=1).max() * 1000))
    if done: log.append('%s hang from the bust: %s' % (ch, '; '.join(done)))
    return Ps


def rigid_lift(P, comps, B):
    """a rigid piece the skin pokes into moves out as a whole along its mean skin normal"""
    if not comps: return P
    P = P.copy()
    for v in comps:
        t_, w_, q_, d_ = B.closest(P[v]); n_ = B.nrm(t_, w_); h = np.einsum('nd,nd->n', P[v] - q_, n_)
        near = d_ < 0.03
        if not near.any(): continue
        need = GAP - h[near]
        if need.max() <= 0: continue
        nm = n_[near].mean(0); nm /= max(np.linalg.norm(nm), 1e-9)
        P[v] = P[v] + float(np.max(need / np.maximum(n_[near] @ nm, 0.3))) * nm
    return P


def classify_parts(X, cloth_idx, A, log):
    """per cloth mesh: {'rigid': [vertex index arrays], 'stiff': [vertex index arrays]} (author space, mesh X)"""
    rmax = CFG.get('rigid_max', RIGID_MAX); smats = CFG.get('stiff', []); auto = CFG.get('auto_stiff', True)
    data = []; allV = []; allG = []; gid = 0
    for i in cloth_idx:
        V0, _, _, I = cloth_data(X['meshes'][i]); G = GR[i]
        used = np.zeros(len(V0), bool); used[I.ravel()] = True
        cv = G.comp[G.key]; cs = {}
        for c in np.unique(cv[used]): cs[int(c)] = np.where((cv == c) & used)[0]
        data.append((i, V0, cs)); allV.append(V0[used]); allG.append(cv[used] + gid); gid += int(cv.max()) + 1
    allV = np.concatenate(allV); allG = np.concatenate(allG); tree = cKDTree(allV)
    out = []; gid = 0; nr = ns = 0; names = []
    for i, V0, cs in data:
        G = GR[i]; mat = X['meshes'][i]['mat']; rig, stf = [], []
        for c, v in cs.items():
            P = V0[v]; ext = np.ptp(P, 0); nodes = len(np.unique(G.key[v]))
            if rmax > 0 and ext.max() < rmax and nodes >= 4:
                if np.median(A.closest(P)[3]) > 0.002:      # skin-tight bits (pasties) keep following the skin
                    rig.append(v); continue
            if nodes < 20: continue
            if any(k in mat for k in smats):
                stf.append(v); continue
            if not auto: continue
            if not (np.median(P[:, 2]) > 0.02 and abs(np.median(P[:, 0])) < 0.12 and ext[1] > max(0.06, 2.5 * ext[0])
                    and P[:, 1].max() > 1.10 and P[:, 1].min() < 1.30):
                continue
            # an overlay: most of it lies on other cloth (within 12 mm of another piece)
            near = tree.query_ball_point(P, 0.012)
            other = np.array([bool(len(j)) and bool((allG[j] != c + gid).any()) for j in near])
            if other.mean() > 0.6:
                stf.append(v); names.append('%s %d verts %.0f x %.0f mm' % (mat[-10:-5], len(v), ext[0] * 1000, ext[1] * 1000))
        out.append({'rigid': rig, 'stiff': stf}); nr += len(rig); ns += len(stf); gid += int(G.comp.max()) + 1
    log.append('shape-keeping pieces: %d rigid (< %.0f mm), %d stiff strips%s' % (nr, rmax * 1000, ns, (': ' + '; '.join(names)) if names else ''))
    return out


def _smooth_normals(S, q, r=0.02):
    """the surface normal averaged over r around each point (a fold's own normal points sideways into it)"""
    tr = cKDTree(S.P); nb = tr.query_ball_point(q, r)
    N = np.array([S.N[j].sum(0) if len(j) else np.zeros(3) for j in nb])
    return N / np.maximum(np.linalg.norm(N, axis=1), 1e-9)[:, None]


def stiff_strips(Ps, items, parts, Bc, log, ch, iters=30, verbose=False):
    """narrow overlay strips keep their author shape (as-rigid-as-possible), hang from their top, follow the fit weakly
    (its overall place) and stay off the skin and off the cloth they lay on (at the author's height, 0.5-3 mm)"""
    if not any(p['stiff'] for p in parts): return Ps
    from scipy.sparse import coo_matrix, diags
    from scipy.sparse.linalg import splu
    Ps = [P.copy() for P in Ps]
    # the cloth a strip may lie on: every piece that is neither stiff nor rigid, in the author's model and as fitted.
    # Heights over it are measured along OUR skin's outward normal (cloth is often double-sided: its own vertex normals
    # cancel and its face normals point either way)
    bV0, bP, bT = [], [], []; o = 0
    for k, it in enumerate(items):
        skip = np.zeros(len(it['V0']), bool)
        for v in parts[k]['stiff'] + parts[k]['rigid']: skip[v] = True
        bV0.append(it['V0']); bP.append(Ps[k]); bT.append(it['I'][~skip[it['I']].any(1)] + o); o += len(it['V0'])
    bT = np.concatenate(bT)
    S0 = Surf(np.concatenate(bV0), bT, None, None); S1 = Surf(np.concatenate(bP), bT, None, None)
    for k, it in enumerate(items):
        G = it['G']
        for v in parts[k]['stiff']:
            nodes, inv = np.unique(G.key[v], return_inverse=True); n = len(nodes)
            A0 = G.avg(it['V0'])[nodes]; X = G.avg(Ps[k])[nodes]; T0 = X.copy()
            vm = -np.ones(len(it['V0']), int); vm[v] = inv
            Tl = vm[it['I']]; Tl = Tl[(Tl >= 0).all(1)]
            E = np.unique(np.sort(np.r_[Tl[:, [0, 1]], Tl[:, [1, 2]], Tl[:, [2, 0]]], 1), axis=0); E = E[E[:, 0] != E[:, 1]]
            deg = np.bincount(E.ravel(), minlength=n).astype(float)
            L = coo_matrix((np.r_[deg, -np.ones(2 * len(E))], (np.r_[np.arange(n), E[:, 0], E[:, 1]], np.r_[np.arange(n), E[:, 1], E[:, 0]])), shape=(n, n)).tocsc()
            c = np.where(A0[:, 1] > A0[:, 1].max() - 0.015, 5.0, 0.02)
            dA = S0.closest(A0)[3]; onb = dA < 0.015; hreq = np.clip(dA, 0.0005, 0.003)
            la = np.linalg.norm(A0[E[:, 0]] - A0[E[:, 1]], axis=1)
            r0 = np.linalg.norm(X[E[:, 0]] - X[E[:, 1]], axis=1) / np.maximum(la, 1e-9)
            cc = np.zeros(n); CT = np.zeros((n, 3)); ea = A0[E[:, 1]] - A0[E[:, 0]]
            for it_ in range(iters):
                ex = X[E[:, 1]] - X[E[:, 0]]; Sm = np.einsum('ei,ej->eij', ea, ex)
                S = np.zeros((n, 3, 3)); np.add.at(S, E[:, 0], Sm); np.add.at(S, E[:, 1], Sm)
                U, sv, Vt = np.linalg.svd(S)
                R = np.einsum('nji,nkj->nik', Vt, U)
                bad = np.linalg.det(R) < 0
                if bad.any():
                    Vt2 = Vt[bad].copy(); Vt2[:, 2] *= -1; R[bad] = np.einsum('nji,nkj->nik', Vt2, U[bad])
                d0 = np.einsum('eij,ej->ei', 0.5 * (R[E[:, 0]] + R[E[:, 1]]), A0[E[:, 0]] - A0[E[:, 1]])
                b = np.zeros((n, 3)); np.add.at(b, E[:, 0], d0); np.add.at(b, E[:, 1], -d0)
                lu = splu((L + diags(c + cc)).tocsc())
                rhs = b + c[:, None] * T0 + cc[:, None] * CT
                X = np.stack([lu.solve(rhs[:, j]) for j in range(3)], 1)
                t_, w_, q_, d_ = Bc.closest(X); nS = Bc.nrm(t_, w_)
                hs = np.einsum('nd,nd->n', X - q_, nS)
                o_ = Bc.at(t_, w_, Bc.Ns) if hasattr(Bc, 'Ns') else nS
                o_ = o_ / np.maximum(np.linalg.norm(o_, axis=1), 1e-9)[:, None]
                needS = np.where(((d_ < 0.03) & (hs < GAP)) | ((d_ < 0.06) & (hs < 0)), GAP - hs, 0.0)
                t2, w2, q2, d2 = S1.closest(X); hb = np.einsum('nd,nd->n', X - q2, o_)
                needB = np.where(onb & (d2 < 0.03), np.maximum(hreq - hb, 0), 0.0)
                need = np.maximum(needS, needB)
                hit = need > 5e-5
                if hit.any():
                    CT[hit] = X[hit] + 1.1 * need[hit, None] * o_[hit]; cc[hit] = 20.0
                if verbose:
                    rr = np.linalg.norm(X[E[:, 0]] - X[E[:, 1]], axis=1) / np.maximum(la, 1e-9)
                    print('  it %d: needS max %.1f needB max %.1f hits %d held %d edges p10/50/90 %.2f/%.2f/%.2f max %.2f' % (
                        it_, needS.max() * 1000, needB.max() * 1000, int(hit.sum()), int((cc > 0).sum()), *np.percentile(rr, [10, 50, 90]), rr.max()))
            r1 = np.linalg.norm(X[E[:, 0]] - X[E[:, 1]], axis=1) / np.maximum(la, 1e-9)
            Ps[k][v] = X[inv]
            gap = (hb - dA)[onb]   # how much further off the cloth under it than in the author's model
            log.append('%s stiff %s (%d verts): edge length vs author p10/median/p90 %.2f/%.2f/%.2f -> %.2f/%.2f/%.2f, '
                       'moved max %.1f mm, %d held off the skin / cloth, last need %.1f mm, off the cloth under it vs author '
                       'p50/p90 %+.1f/%+.1f mm' % (
                ch, it['mat'][-10:-5], len(v), *np.percentile(r0, [10, 50, 90]), *np.percentile(r1, [10, 50, 90]),
                np.linalg.norm(X - T0, axis=1).max() * 1000, int((cc > 0).sum()), need.max() * 1000,
                *(np.percentile(gap, [50, 90]) * 1000 if len(gap) else (0, 0))))
    return Ps


def rigid_parts(Ps, items, parts, Bc, log, ch):
    if not any(p['rigid'] for p in parts): return Ps
    Ps = [P.copy() for P in Ps]
    # bases: every vertex of the pieces that are not rigid (stiff strips included), with its piece id
    BV0, BP, BK = [], [], []
    for k, it in enumerate(items):
        r = np.zeros(len(it['V0']), bool); r[np.unique(it['I'])] = True
        for v in parts[k]['rigid']: r[v] = False
        idx = np.where(r)[0]; cv = it['G'].comp[it['G'].key]
        BV0.append(it['V0'][idx]); BP.append(Ps[k][idx]); BK.append(np.c_[np.full(len(idx), k), cv[idx]])
    BV0 = np.concatenate(BV0); BP = np.concatenate(BP); BK = np.concatenate(BK); tree = cKDTree(BV0)
    on_base = own = 0; mv = []; lifted = 0
    for k, it in enumerate(items):
        for v in parts[k]['rigid']:
            V0c = it['V0'][v]; ext = np.ptp(V0c, 0).max(); X = None
            d, j = tree.query(V0c); dmin = float(d.min())
            if dmin < 0.015:
                kb, cb_ = BK[j[np.argmin(d)]]
                rp = max(0.008, 0.3 * ext) + dmin
                cand = np.unique(np.concatenate([np.asarray(x, int) for x in tree.query_ball_point(V0c, rp)]))
                cand = cand[(BK[cand, 0] == kb) & (BK[cand, 1] == cb_)]
                if len(cand) >= 6 and np.linalg.svd(BV0[cand] - BV0[cand].mean(0), compute_uv=False)[1] > 1e-3:
                    dc = cKDTree(V0c).query(BV0[cand])[0]
                    R, ca, cb = kabsch(BV0[cand], BP[cand], np.exp(-0.5 * (dc / (0.5 * rp)) ** 2) + 1e-6)
                    X = (V0c - ca) @ R.T + cb; on_base += 1
            if X is None:
                R, ca, cb = kabsch(V0c, Ps[k][v]); X = (V0c - ca) @ R.T + cb; own += 1
            # never inside the skin: the whole piece moves out along its mean skin normal
            t_, w_, q_, d_ = Bc.closest(X); n_ = Bc.nrm(t_, w_); h = np.einsum('nd,nd->n', X - q_, n_)
            near = d_ < 0.03; need = np.where(near, GAP - h, 0.0)
            if near.any() and need.max() > 0:
                nm = n_[near].mean(0); nm /= max(np.linalg.norm(nm), 1e-9)
                X = X + float(np.max(need[near] / np.maximum(n_[near] @ nm, 0.3))) * nm; lifted += 1
            mv.append(np.linalg.norm(X - Ps[k][v], axis=1).max()); Ps[k][v] = X
    log.append('%s rigid pieces: %d move with the cloth under them, %d with their own fit, %d lifted off the skin; '
               'moved median %.1f max %.1f mm' % (ch, on_base, own, lifted, np.median(mv) * 1000, np.max(mv) * 1000))
    return Ps


def rigid_weights(F, comps):
    """one weight set per rigid piece (the mean of its vertices'): a pin over both breasts moves in one piece"""
    if not comps: return F
    F = F.copy()
    for v in comps:
        m = F[v].mean(0); F[v] = m / max(m.sum(), 1e-12)
    return F


# ---------------------------------------------------------------- main
def roughness(P, V0, G):
    """per welded vertex: how much bumpier the fitted cloth is than the author's (umbrella Laplacian length difference
    over the mean author edge length; 0 = same shape). Crumples, spikes and pulled-apart details score > 0.3"""
    Pw = G.avg(P); Vw = G.avg(V0)
    lap = lambda Z: np.linalg.norm(Z - G.W @ Z, axis=1)
    A_ = G.A.tocoo(); el = np.zeros(G.n); np.add.at(el, A_.row, np.linalg.norm(Vw[A_.row] - Vw[A_.col], axis=1)); el /= np.maximum(G.deg, 1)
    ex = lap(Pw) - lap(Vw)
    return ex / np.maximum(el, 1e-4), ex


def auto_fix(Ps, items, parts, Bc, log, ch, thr=0.3, sigma=0.012, rounds=3):
    """automatic repair: where the fit made the cloth much bumpier than the author made it (crumpled crotches, pulled-apart
    bows, spikes), the cloth's move there is replaced by its smooth version (gaussian over the author's cloth, sigma 12 mm),
    blended in over 1 cm around the bad spots, so the detail keeps its own shape and just moves with the body; then one
    smooth lift against the skin. Rigid / stiff pieces (already shape-kept) are left alone. cfg auto_fix: false = off"""
    if CFG.get('auto_fix') is False: return Ps
    if isinstance(CFG.get('auto_fix'), dict):
        thr = float(CFG['auto_fix'].get('thr', thr)); sigma = float(CFG['auto_fix'].get('sigma', sigma))
    Ps = list(Ps); notes = []
    for k, it in enumerate(items):
        G = it['G']; V0 = it['V0']
        keep = np.zeros(len(V0), bool)
        for v in parts[k]['stiff'] + parts[k]['rigid']: keep[v] = True
        used = np.zeros(len(V0), bool); used[np.unique(it['I'])] = True
        Vw = G.avg(V0); keepw = np.zeros(G.n, bool); np.logical_or.at(keepw, G.key, keep)
        usedw = np.zeros(G.n, bool); np.logical_or.at(usedw, G.key, used)
        tree = cKDTree(Vw); fixed = 0; worst0 = None
        for r_ in range(rounds):
            rel, ex = roughness(Ps[k], V0, G)
            bad = (rel > thr) & (ex > 0.001) & usedw & ~keepw
            if worst0 is None: worst0 = float(rel[usedw].max()) if usedw.any() else 0.0
            if not bad.any(): break
            # blend weight: 1 within 5 mm of a bad vertex, fading to 0 at 15 mm
            db = cKDTree(Vw[bad]).query(Vw, distance_upper_bound=0.015)[0]
            wgt = np.clip((0.015 - db) / 0.010, 0, 1) * ~keepw
            reg = np.where(wgt > 0)[0]
            D = G.avg(Ps[k] - V0)
            nb = tree.query_ball_point(Vw[reg], 2.5 * sigma)
            Ds = np.array([(np.exp(-np.sum((Vw[j] - Vw[i]) ** 2, 1) / (2 * sigma ** 2))[:, None] * D[j]).sum(0)
                           / np.exp(-np.sum((Vw[j] - Vw[i]) ** 2, 1) / (2 * sigma ** 2)).sum() for i, j in zip(reg, nb)])
            Dn = D.copy(); Dn[reg] = D[reg] + wgt[reg, None] * (Ds - D[reg])
            Ps[k] = np.where(used[:, None], V0 + Dn[G.key], Ps[k])
            fixed = max(fixed, int(bad.sum()))
        if fixed:
            rel, _ = roughness(Ps[k], V0, G)
            notes.append('%s: %d crumpled verts smoothed (worst %.2f -> %.2f)' % (it['mat'][-10:-5], fixed, worst0, float(rel[usedw & ~keepw].max()) if (usedw & ~keepw).any() else 0))
    if notes:
        Ps, lf = lift(Ps, Bc, iters=2)
        log.append('%s auto fix: %s; lifted max %.1f mm' % (ch, '; '.join(notes), lf.max() * 1000))
    return Ps


def arm_clear(Ps, items, B, log, ch, cap=0.015):
    """room around the arms: the collision surface leaves the arms out (no_arms), so sleeves and shoulders only kept the
    author's height and an arm moving in any animation pushed the elbow / shoulder through. Cloth over arm skin (arm
    bones carry >= 30-70 % of the skin's weight there) is lifted to at least cfg arm_gap (default 5 mm), 2 mm more at
    the elbow, as one smooth field; never from the inner side of the arm that faces the body. cfg arm_gap 0 = off"""
    g = float(CFG.get('arm_gap', 0.005))
    if g <= 0 or B.W is None: return Ps
    nm = list(B.names)
    aw = B.W[:, [i for i, n in enumerate(nm) if n.startswith(ARM)]].sum(1)
    col = lambda n: B.W[:, nm.index(n)] if n in nm else np.zeros(len(B.P))
    ew = np.zeros(len(B.P))
    for sd in ('_l', '_r'):
        ew = np.maximum(ew, np.minimum(col('j_ude_a' + sd), col('j_ude_b' + sd)) * 2 + col('n_hhiji' + sd))
    ew = np.clip(ew, 0, 1)
    P = np.concatenate(Ps); sizes = [len(x) for x in Ps]; total = np.zeros(len(P))
    for it in range(3):
        t, w, q, d = B.closest(P); n = B.nrm(t, w)
        h = np.einsum('nd,nd->n', P - q, n)
        a_ = np.einsum('ni,ni->n', w, aw[B.T[t]]); e_ = np.einsum('ni,ni->n', w, ew[B.T[t]])
        r = np.clip((a_ - 0.3) / 0.4, 0, 1) * (d < 0.04)
        qx = q[:, [0, 2]] - np.array([0.0, 0.0]); nx = n[:, [0, 2]]
        outw = np.einsum('nd,nd->n', nx, qx) / np.maximum(np.linalg.norm(nx, axis=1) * np.linalg.norm(qx, axis=1), 1e-9)
        r = r * np.clip(outw * 2 + 0.6, 0, 1)                  # the inner side of the arm (facing the body): left alone
        want = g + 0.002 * e_
        need = np.where((h > -0.01) & (h < want), (want - h) * r, 0.0)
        need = np.minimum(need, cap - total)
        if need.max() < 2e-4: break
        NB = _nbr(P, 0.006)
        L = _nmean(_nmax(need, NB), NB); L = np.maximum(L, need)
        P = P + L[:, None] * n; total += L
    if total.max() > 1e-4:
        log.append('%s arm room: %d verts lifted off the arms (median %.1f, max %.1f mm, gap %.1f mm)' % (ch, int((total > 1e-4).sum()), np.median(total[total > 1e-4]) * 1000, total.max() * 1000, g * 1000))
    out = []; o = 0
    for s_ in sizes: out.append(P[o:o + s_]); o += s_
    return out


def bust_cap(Ps, items, Bc, log, ch, slack=0.001):
    """over our bust (under and between the breasts above all) the cloth may not stand further off the skin than it
    stood off the author's skin (+ slack): the smoothed chest map filled the curve under a fuller chest and the port
    looked bigger than the naked body. Only pulls down (never under the gap), spread smoothly over each piece;
    loose garments (hoodies, capes) keep their hang. cfg bust_cap: false = off"""
    if CFG.get('bust_cap') is False: return Ps
    out = []; tot = []
    # the bust apex height on our chest: the cap works below it (under the breast) and between the breasts only, the
    # front of the cups keeps its shape
    Sb = Bc.P[(Bc.part == 0) & (Bc.P[:, 2] > 0) & (np.abs(Bc.P[:, 0]) > 0.04) & (np.abs(Bc.P[:, 0]) < 0.09) & (Bc.P[:, 1] > 1.08) & (Bc.P[:, 1] < 1.32)]
    apy = float(Sb[np.argmax(Sb[:, 2]), 1]) if len(Sb) else 1.22
    for P_, it in zip(Ps, items):
        if it.get('loose'):
            out.append(P_); continue
        G = it['G']; X = P_.copy(); off = it['off']
        allowed = np.maximum(off, GAP) + slack
        for k in range(3):
            t, w, q, d = Bc.closest(X); n = Bc.nrm(t, w)
            cur = np.einsum('nd,nd->n', X - q, n)
            part0 = Bc.part[Bc.T[t, 0]] == 0
            zone = np.maximum(np.clip((apy - 0.01 - q[:, 1]) / 0.02, 0, 1), np.clip((0.04 - np.abs(q[:, 0])) / 0.015, 0, 1))
            r = (part0 & (d < 0.03)).astype(float) * np.clip((q[:, 1] - 1.06) / 0.02, 0, 1) * np.clip((1.38 - q[:, 1]) / 0.02, 0, 1) \
                * np.clip((q[:, 2] - 0.0) / 0.02, 0, 1) * np.clip((0.14 - np.abs(q[:, 0])) / 0.02, 0, 1) * np.clip((0.02 - off) / 0.008, 0, 1) * zone
            down = np.minimum(allowed - cur, 0.0) * r
            if down.min() > -1e-4: break
            a = (down < -1e-4).astype(float)
            wa = G.avg(a) + 1e-4
            tg = G.avg(n * down[:, None]) / wa[:, None]
            X = X + G.solve(wa, tg, mu=0.3, nu=0.05)[G.key]
        mv = np.linalg.norm(X - P_, axis=1)
        if (mv > 1e-4).any(): tot.append(mv[mv > 1e-4])
        out.append(X)
    if tot:
        mv = np.concatenate(tot)
        log.append('%s bust cap: %d verts brought back to the author\'s height over the chest, median %.1f max %.1f mm' % (ch, len(mv), np.median(mv) * 1000, mv.max() * 1000))
    return out


def final_clear(Ps, items, Bc, log, ch, iters=4):
    """last check after the repairs: skin poking through a cloth triangle (between its corners) or a vertex under the
    gap lifts the cloth there as one smooth field (dilated 6 mm, mean over 6 mm), every layer over the spot together"""
    Ps = list(Ps); tot = 0.0
    for k in range(iters):
        need, n, _ = needs(Ps, [it['I'] for it in items], Bc)
        if need.max() < 1e-4: break
        P = np.concatenate(Ps); NB = _nbr(P, 0.006)
        L = _nmean(_nmax(need, NB), NB); L = np.maximum(L, need)
        P = P + L[:, None] * n; tot = max(tot, float(L.max()))
        o = 0
        for j, it in enumerate(items):
            nv = len(it['V0']); Ps[j] = P[o:o + nv]; o += nv
    if tot > 0: log.append('%s final clear: lifted max %.1f mm' % (ch, tot * 1000))
    return Ps


def pose_check(Ps, items, Bw, Bc, Xm, log, ch, cap=0.004):
    """quick animation test: the body and the cloth (with their weights) in a few poses - walking, legs apart,
    sitting, the breasts bouncing up and down - and wherever cloth goes under the posed skin, the cloth is lifted at
    rest by that much (one smooth field over every layer, at most `cap`), so it stays out when she moves.
    Only cloth near skin that the pose moves is tested (fast). cfg pose_check: false = off"""
    if CFG.get('pose_check') is False or Bw.W is None: return Ps
    import pose as PZ
    SW = Bw.W; SN = Bw.names
    cl = PZ.pivot(Bw.P, SW, SN, PZ.LEFT); cr = PZ.pivot(Bw.P, SW, SN, PZ.RIGHT)
    X_, Z_ = (1, 0, 0), (0, 0, 1)
    specs = {'walk': {'rot': [(PZ.LEFT, PZ.rotm(X_, -35), cl), (PZ.RIGHT, PZ.rotm(X_, 20), cr)]},
             'apart': {'rot': [(PZ.LEFT, PZ.rotm(Z_, 25), cl), (PZ.RIGHT, PZ.rotm(Z_, -25), cr)]},
             'sit': {'rot': [(PZ.LEFT, PZ.rotm(X_, -60), cl), (PZ.RIGHT, PZ.rotm(X_, -60), cr)]},
             'bounce_up': {'rot': [], 'tr': {'iv_c_mune_l': (0, 0.012, 0.004), 'iv_c_mune_r': (0, 0.012, 0.004)}},
             'bounce_down': {'rot': [], 'tr': {'iv_c_mune_l': (0, -0.012, 0.002), 'iv_c_mune_r': (0, -0.012, 0.002)}}}
    need_all = [np.zeros(len(P)) for P in Ps]
    Wc_ = []
    for P, it in zip(Ps, items):
        m = Xm[it['mi']]
        W, names, _ = body_weights(P, Bw, m['table'], dense_w(m)); Wc_.append((W, names))
    rest = [Bw.closest(P) for P in Ps]
    worst = {}
    for k, sp in specs.items():
        Q = PZ.pose_pts(Bw.P, SW, SN, None, sp); mv = np.linalg.norm(Q - Bw.P, axis=1)
        if mv.max() < 0.002: continue
        S_ = Surf(Q, Bw.T, None, Bw.part); wk = 0.0
        for j, (P, it) in enumerate(zip(Ps, items)):
            t, w, q, d = rest[j]
            moving = (d < 0.03) & (np.einsum('ni,ni->n', w, mv[Bw.T[t]]) > 0.002)
            idx = np.where(moving)[0]
            if not len(idx): continue
            W, names = Wc_[j]
            C = PZ.pose_pts(P[idx], W[idx], names, None, sp)
            t2, w2, q2, d2 = S_.closest(C); h = np.einsum('nd,nd->n', C - q2, S_.nrm(t2, w2))
            pen = np.where(d2 < 0.03, np.maximum(0.0006 - h, 0), 0)
            wk = max(wk, float(pen.max()) if len(pen) else 0)
            # deep folds (the hip crease when sitting) clip in the game's own clothes too: lifting would only puff the
            # cloth up at rest, so only what a small lift can fix counts
            pen = np.where(pen < 3 * cap, pen, 0)
            np.maximum.at(need_all[j], idx, pen)
        worst[k] = wk
    need = np.minimum(np.concatenate(need_all), cap)
    if need.max() < 1e-4:
        log.append('%s pose check: clear in every pose' % ch); return Ps
    P = np.concatenate(Ps); NB = _nbr(P, 0.008)
    L = _nmean(_nmax(need, NB), NB); L = np.maximum(L, need)
    t, w, q, d = Bc.closest(P); n = Bc.nrm(t, w)
    P = P + L[:, None] * n; out = []; o = 0
    for it in items:
        nv = len(it['V0']); out.append(P[o:o + nv]); o += nv
    log.append('%s pose check: cloth went under the skin by up to %s; lifted %d verts, max %.1f mm' % (
        ch, ', '.join('%s %.1f mm' % (k, v * 1000) for k, v in worst.items() if v > 1e-4) or '-', int((L > 1e-4).sum()), L.max() * 1000))
    return out


def run_group(top, dwn, AS, X, CHS, REF_, log, report):
    """fit + variants + emission for one group of chest options that share one author topology"""
    global GR
    cloth_idx = [i for i, m in enumerate(X['meshes']) if not is_skin(m)]
    GR = {}
    for i in cloth_idx:
        V0, N0, T0, I = cloth_data(X['meshes'][i]); GR[i] = Graph(V0, I)
    PARTS = classify_parts(X, cloth_idx, AS[PICK[REF_]][1], log)
    RIG = {i: PARTS[k]['rigid'] for k, i in enumerate(cloth_idx)}
    V0S = {(i, sz): cloth_data(AS[sz][0]['meshes'][i])[0] for i in cloth_idx for sz in AS}
    Bs = {}; Ds = {}; FIT = {}; BC = {}
    for ch in CHS:
        B, D = our_rest_and_shapes(top, dwn, ch); B = outer_only(B, log, ch); Bs[ch] = B; Ds[ch] = D
        sz = PICK[ch]; Xs, A = AS[sz]
        items = fit_chest(B, A, Xs, ch, log)
        Bc = no_arms(B); BC[ch] = Bc
        Ps = collide(items, Bc, log, ch)
        Ps, lifted = lift(Ps, Bc, iters=2)
        log.append('%s from %s: lift max %.1f mm, moved %d' % (ch, sz, lifted.max() * 1000, int((lifted > 1e-4).sum())))
        Ps = hang_loose(Ps, items, PARTS, Bc, log, ch)
        Ps, _ = lift(Ps, Bc, iters=2)
        if CFG.get('tight'):
            Ps = relax_tight(Ps, items, log, ch)
            Ps, _ = lift(Ps, Bc, iters=4)
            Ps, pl = pose_lift(Ps, items, B, Bc, Xs['meshes'], log, ch)
            Ps, _ = lift(Ps, Bc, iters=2)
            log.append('%s pose lift max %.1f mm' % (ch, pl.max() * 1000))
            if CFG.get('settle'):
                Ps = settle(Ps, items, Bc, log, ch); Ps, _ = lift(Ps, Bc, iters=2)
            if CFG.get('arap'):
                Ps = arap_settle(Ps, items, Bc, log, ch)
        Ps = [P_ if it_.get('aff') is None else P_ + it_['aff'][0][:, None] * (it_['aff'][1] - P_) for P_, it_ in zip(Ps, items)]   # affine region: keep the wrapped shape
        Ps = bind_layers(Ps, items, log, ch)
        Ps = stiff_strips(Ps, items, PARTS, Bc, log, ch)
        Ps = rigid_parts(Ps, items, PARTS, Bc, log, ch)
        Ps = auto_fix(Ps, items, PARTS, Bc, log, ch)
        Ps = bust_cap(Ps, items, Bc, log, ch)
        Ps = final_clear(Ps, items, Bc, log, ch)
        Ps = arm_clear(Ps, items, B, log, ch)
        Ps = pose_check(Ps, items, B, Bc, Xs['meshes'], log, ch)
        Ps = [P_ if not RIG[i] else rigid_lift(rigid_project(P_, V0S[(i, PICK[ch])], RIG[i]), RIG[i], Bc) for P_, i in zip(Ps, cloth_idx)]
        FIT[ch] = dict(zip(cloth_idx, Ps))
    # ---- chest dependency (relative to REF_), locked seams
    CHM = {}
    for i in cloth_idx:
        G = GR[i]; Pr = FIT[REF_][i]
        mag = np.max([np.linalg.norm(FIT[ch][i] - Pr, axis=1) for ch in CHS], 0)
        mk = smooth_mask(G, mag, 0.00025, 0.0006)
        for v in RIG[i]: mk[v] = mk[v].max()
        for ch in CHS: FIT[ch][i] = Pr + mk[:, None] * (FIT[ch][i] - Pr)
        CHM[i] = mk > 0
        log.append('mesh %d chest-dependent verts %d/%d' % (i, int(CHM[i].sum()), len(mk)))
    # ---- belly / hips variant displacements (per chest), then lift against the variant body
    VAR = {}  # (i, ch, group, opt) -> displacement
    DEP = {i: {'belly': np.zeros(len(FIT[REF_][i]), bool), 'hips': np.zeros(len(FIT[REF_][i]), bool)} for i in cloth_idx}
    for ch in CHS:
        for g, opts in (('belly', ('none', 'soft')), ('hips', ('small', 'large'))):
            for o in opts:
                for i in cloth_idx:
                    VAR[(i, ch, g, o)] = variant_field(FIT[ch][i], Bs[ch], Ds[ch][g + '_' + o], GR[i])
    for i in cloth_idx:
        G = GR[i]
        for g, opts in (('belly', ('none', 'soft')), ('hips', ('small', 'large'))):
            mag = np.max([np.linalg.norm(VAR[(i, ch, g, o)], axis=1) for ch in CHS for o in opts], 0)
            mk = smooth_mask(G, mag, 0.0003, 0.0008)
            for v in RIG[i]: mk[v] = mk[v].max()
            for ch in CHS:
                for o in opts: VAR[(i, ch, g, o)] *= mk[:, None]
            # vertices shared by every chest option must move the same way in every chest option (no seams)
            for ch in CHS:
                for o in opts: VAR[(i, ch, g, o)] = np.where(CHM[i][:, None], VAR[(i, ch, g, o)], VAR[(i, REF_, g, o)])
            # a rigid piece moves as a whole in every belly / hips option too
            for ch in (CHS if RIG[i] else []):
                for o in opts:
                    Pf = FIT[ch][i]; Pv = Pf + VAR[(i, ch, g, o)]
                    for v in RIG[i]:
                        R_, ca_, cb_ = kabsch(Pf[v], Pv[v]); VAR[(i, ch, g, o)][v] = (Pf[v] - ca_) @ R_.T + cb_ - Pf[v]
            DEP[i][g] = mk > 0
            log.append('mesh %d %s-dependent verts %d' % (i, g, int(DEP[i][g].sum())))
    # variant collision: lift the displaced cloth against the displaced body (only where it moved)
    shapeD = lambda ch, sel: sum(Ds[ch][g + '_' + o] for g, o in sel.items() if (g, o) not in (('belly', 'full'), ('hips', 'medium')))
    def positions(ch, belly, hips):
        out = {}
        for i in cloth_idx:
            P = FIT[ch][i].copy()
            if belly != 'full': P += VAR[(i, ch, 'belly', belly)]
            if hips != 'medium': P += VAR[(i, ch, 'hips', hips)]
            out[i] = P
        return out
    # layers bound to a base piece (cfg bind): their author-space binding (triangle + barycentric) for the variants below
    BINDS = []; BIND_T = {}
    for lk, bk in (CFG.get('bind') or {}).items():
        jls = [i for i in cloth_idx if lk in X['meshes'][i]['mat']]; kbs = [i for i in cloth_idx if bk in X['meshes'][i]['mat'] and i not in jls]
        if not jls or not kbs: continue
        jl, kb = jls[0], kbs[0]; Vl = cloth_data(X['meshes'][jl])[0]; Vb_, _, _, Ib_ = cloth_data(X['meshes'][kb])
        tb, wb, _, _ = Surf(Vb_, Ib_, None, None).closest(Vl); BIND_T[kb] = Ib_; BINDS.append((jl, kb, tb, wb))
        log.append('variants: %s follows %s in every belly / hips option' % (X['meshes'][jl]['mat'][-14:], X['meshes'][kb]['mat'][-14:]))
        for g in ('belly', 'hips'):   # a layer vertex is option-dependent wherever its base under it is (emitted per option)
            n0_ = int(DEP[jl][g].sum()); DEP[jl][g] = DEP[jl][g] | DEP[kb][g][Ib_[tb]].any(1)
            log.append('variants: %s %s-dependent verts %d -> %d (its base)' % (X['meshes'][jl]['mat'][-14:], g, n0_, int(DEP[jl][g].sum())))
    POS = {}
    for ch in [REF_] + [c for c in CHS if c != REF_]:
        for be in ('full', 'soft', 'none'):
            for hi in ('medium', 'small', 'large'):
                Pd = positions(ch, be, hi)
                if (be, hi) != ('full', 'medium'):
                    B = BC[ch]; Bv = Surf(B.P + shapeD(ch, {'belly': be, 'hips': hi}), B.T, B.UV, B.part)
                    mv = {i: DEP[i]['belly'] * (be != 'full') | DEP[i]['hips'] * (hi != 'medium') for i in cloth_idx}
                    Ps, lifted = lift([Pd[i] for i in cloth_idx], Bv)
                    for k, i in enumerate(cloth_idx):
                        # only moving cloth may change, so the seams to the shared piece stay closed
                        Pd[i] = np.where(mv[i][:, None], Ps[k], Pd[i])
                        if RIG[i]: Pd[i] = rigid_lift(rigid_project(Pd[i], V0S[(i, PICK[ch])], RIG[i]), RIG[i], Bv)
                    report.setdefault('variant_lift', {})['%s/%s/%s' % (ch, be, hi)] = round(float(lifted.max() * 1000), 2)
                    # bound layers (cfg bind) move with their base in every option: the variant lift pushed the panel out
                    # against the belly variant body but not the lace lying on it (Gothkini Slim, belly Soft / None: the
                    # top lace strand ended up behind the panel). Layer = its full / medium place + the base's move at
                    # the point it is bound to
                    for jl, kb, tb, wb in BINDS:
                        dB = Pd[kb] - POS[(ch, 'full', 'medium')][kb]
                        Pd[jl] = POS[(ch, 'full', 'medium')][jl] + np.einsum('ni,nid->nd', wb, dB[BIND_T[kb][tb]])
                if ch != REF_:
                    for i in cloth_idx: Pd[i] = np.where(CHM[i][:, None], Pd[i], POS[(REF_, be, hi)][i])
                POS[(ch, be, hi)] = Pd
    # ---- weights (shared vertices share weights)
    WT = {}
    for i in cloth_idx:
        m = X['meshes'][i]; Wc = dense_w(m)
        Wref, names, tt = body_weights(POS[(REF_, 'full', 'medium')][i], Bs[REF_], m['table'], Wc)
        Wref = rigid_weights(Wref, RIG[i])
        WT[(i, REF_, 'full', 'medium')] = (Wref, names)
        report.setdefault('reweighted', {})[i] = int((tt > 0).sum())
    def weights_for(i, ch, be, hi):
        key = (i, ch, be, hi)
        if key in WT: return WT[key]
        m = X['meshes'][i]; Wc = dense_w(m)
        B = Bs[ch]; Bv = Surf(B.P + shapeD(ch, {'belly': be, 'hips': hi}), B.T, B.UV, B.part, B.W, B.names)
        Wv, names, _ = body_weights(POS[(ch, be, hi)][i], Bv, m['table'], Wc)
        Wr, nr = WT[(i, REF_, 'full', 'medium')]
        allm = sorted(set(names) | set(nr)); F = np.zeros((len(Wv), len(allm))); F[:, [allm.index(n) for n in names]] = Wv
        Fr = np.zeros_like(F); Fr[:, [allm.index(n) for n in nr]] = Wr
        dep = np.zeros(len(F), bool)
        if ch != REF_: dep |= CHM[i]
        if be != 'full': dep |= DEP[i]['belly']
        if hi != 'medium': dep |= DEP[i]['hips']
        F = np.where(dep[:, None], rigid_weights(F, RIG[i]), Fr); WT[key] = (F, allm); return WT[key]
    # ---- emission
    pieces = []
    for i in cloth_idx:
        m = X['meshes'][i]; V0, N0, T0, I = cloth_data(m); G = GR[i]
        src = {k: cloth_data(AS[k][0]['meshes'][i]) for k in AS}
        ref_frames = None
        tc = CHM[i][I].any(1); tb = DEP[i]['belly'][I].any(1); th = DEP[i]['hips'][I].any(1)
        attr_sets = []; tri_attr = np.zeros(len(I), int)
        for s_ in m['subs']:
            if not s_['cnt']: continue
            a_ = tuple(s_['attr'])
            if a_ not in attr_sets: attr_sets.append(a_)
            tri_attr[s_['off'] // 3:(s_['off'] + s_['cnt']) // 3] = attr_sets.index(a_)
        for cdep in (0, 1):
            for bdep in (0, 1):
                for hdep in (0, 1):
                    sel = (tc == cdep) & (tb == bdep) & (th == hdep)
                    if not sel.any(): continue
                    combos = []
                    for ch in (CHS if cdep else [REF_]):
                        for be in (('full', 'soft', 'none') if bdep else ['full']):
                            for hi in (('medium', 'small', 'large') if hdep else ['medium']):
                                P = POS[(ch, be, hi)][i]
                                sV0, sN0, sT0, _ = src[PICK[ch]]
                                Nn, Tn = frames(G, sV0, P, sN0, sT0)
                                # vertices shared with the common piece keep the common piece's normals (no shading seam)
                                dep = np.zeros(len(P), bool)
                                if ch != REF_: dep |= CHM[i]
                                if be != 'full': dep |= DEP[i]['belly']
                                if hi != 'medium': dep |= DEP[i]['hips']
                                if ref_frames is None:
                                    rV0, rN0, rT0, _ = src[PICK[REF_]]; ref_frames = frames(G, rV0, POS[(REF_, 'full', 'medium')][i], rN0, rT0)
                                Nn = np.where(dep[:, None], Nn, ref_frames[0]); Tn = np.where(dep[:, None], Tn, ref_frames[1])
                                Wf, names = weights_for(i, ch, be, hi)
                                tags = (['atrx_cb_chest_' + ch] if cdep else []) + (['atrx_cb_belly_' + be] if bdep else []) + (['atrx_cb_hips_' + hi] if hdep else [])
                                combos.append((P, Nn, Tn, Wf, names, tags))
                    # keep the author's sub-meshes apart (each has its own toggle attributes)
                    for sa in sorted(set(tri_attr[sel].tolist())):
                        pieces += shared_pieces(m, I[sel & (tri_attr == sa)], combos, base_attr=list(attr_sets[sa]))
    return pieces

# ---------------------------------------------------------------- compact vertex layout for cloth (fits more cloth under 16 MB)
SZ = {0: 4, 1: 8, 2: 12, 3: 16, 5: 4, 8: 4, 13: 4, 14: 8, 17: 8}
def compact_layout(mm):
    """stream 1 floats -> halves: normal float3 -> half4, uv float4 -> half4, uv float2 -> half2 (byte types kept).
    Body skin keeps full precision; only cloth goes through this."""
    D = mm['decl']; ents = []
    for i in range(17):
        e = list(D[i * 8:i * 8 + 8])
        if e[0] == 255: break
        ents.append(e)
    s1 = [e for e in ents if e[0] == 1]
    if not s1 or not any(e[2] in (1, 2, 3) for e in s1): return mm
    nv = mm['nv']; st1 = mm['strides'][1] if 'strides' in mm else len(mm['streams'][1]) // nv
    A = np.frombuffer(mm['streams'][1], np.uint8).reshape(nv, -1)
    cols = []; newe = []; off = 0
    for e in sorted(s1, key=lambda e: e[1]):
        st, o, t, u = e[0], e[1], e[2], e[3]
        if t in (1, 2, 3):
            n = {1: 2, 2: 3, 3: 4}[t]; f = A[:, o:o + 4 * n].copy().view(np.float32).reshape(nv, n)
            if n == 3: f = np.c_[f, np.zeros((nv, 1), np.float32)]
            nt = 13 if f.shape[1] == 2 else 14
            h = f.astype(np.float16).view(np.uint8).reshape(nv, -1); cols.append(h); newe.append([1, off, nt, u] + e[4:]); off += h.shape[1]
        else:
            b = A[:, o:o + SZ[t]]; cols.append(b); newe.append([1, off, t, u] + e[4:]); off += SZ[t]
    B = np.concatenate(cols, 1)
    s0 = [e for e in ents if e[0] != 1]
    nd = bytearray(); 
    for e in s0 + newe: nd += bytes(e[:8])
    nd += bytes([255] + [0] * 7); nd += bytes(136 - len(nd))
    mm = dict(mm); mm['streams'] = [mm['streams'][0], B.tobytes()] + list(mm['streams'][2:]); mm['decl'] = bytes(nd)
    if 'strides' in mm: mm['strides'] = [mm['strides'][0], off] + list(mm['strides'][2:])
    return mm

def topo_key(X):
    return tuple((m['mat'], m['nv'], hash(m['idx'])) for m in X['meshes'] if not is_skin(m))

CG = {'s': ['flat', 'small', 'champs', 'smallperky', 'medium', 'earth'], 'l': ['large', 'saggy', 'perky', 'mireya']}   # Crimson chest groups (atrx_cb_cg_*)
def run(build, out_path, report):
    global PICK
    top, dwn = read(CB + BUILDS[build][0]), read_dwn(build)
    AS = {s: author_surface(s) for s in CFG['sizes']}
    log = []; pieces = []
    if CFG.get('auto_loose') and 'loose' not in CFG:
        # loose garments found in the author's model: in front below the bust the material hangs more than 1 cm off the
        # author's skin (median) -> it hangs from a bigger bust and bridges the cleavage instead of hugging every curve
        Xa, Aa = AS[list(CFG['sizes'])[0]]; lo = []; rep_ = []
        for m in Xa['meshes']:
            if is_skin(m) or not m['nv']: continue
            V = attr(m, 0)[0][:, :3][np.unique(tris(m))]
            reg = (V[:, 2] > 0.0) & (np.abs(V[:, 0]) < 0.12) & (V[:, 1] > 0.95) & (V[:, 1] < 1.12)
            if reg.sum() < 50: continue
            dm = float(np.median(Aa.closest(V[reg])[3])); rep_.append('%s %.1f mm' % (m['mat'][-10:-5], dm * 1000))
            if dm > CFG.get('loose_mm', 10) / 1000 and m['mat'] not in lo: lo.append(m['mat'])
        CFG['loose'] = lo
        log.append('auto loose: %s (median height over the author skin below the bust: %s)' % ([x[-10:-5] for x in lo] or 'none', ', '.join(rep_)))
    keys = {k: topo_key(AS[k][0]) for k in AS}
    if len(set(keys.values())) == 1:
        X = AS[list(CFG['sizes'])[0]][0]
        # Legs/Feet slots have no chest switches in the Crimson meta: one fit, against the chest given (default medium)
        chs = [CFG['only_chest']] if CFG.get('only_chest') else CH
        pieces = run_group(top, dwn, AS, X, chs, chs[0] if CFG.get('only_chest') else REF, log, report)
    else:
        # author sizes with different meshes: one fit per Crimson chest group (cg_s / cg_l), each from the sizes of that group
        for g, chs in CG.items():
            sizes = CFG['groups'][g]
            if len({keys[k] for k in sizes}) > 1 and DIST:
                # these sizes don't share a mesh: the group is fitted from the one size closest over all its chests
                sizes = [min(sizes, key=lambda k: sum(DIST[c][k] for c in chs))]
            PICK.update({c: min(sizes, key=lambda k: DIST[c][k]) if DIST else sizes[0] for c in chs})
            assert len({keys[PICK[c]] for c in chs}) == 1, 'sizes of one chest group must share the mesh'
            X = AS[PICK[chs[0]]][0]
            ref = 'medium' if 'medium' in chs else chs[0]
            pg = run_group(top, dwn, AS, X, chs, ref, log, report)
            for p in pg:
                for s_ in p['subs']: s_['attr'] = s_['attr'] + ['atrx_cb_cg_' + g]
            pieces += pg
            log.append('chest group %s: %s fitted from %s' % (g, chs, {c: PICK[c] for c in chs}))
    if CFG.get('skin'):   # gloves/shoes: the body pieces come from the user's own hands/feet model
        body_meshes = [mm for f in CFG['skin'] for mm in read(f)['meshes'] if 'piercing' not in mm['mat'] and mm['nv'] > 0]
        rep_ = CFG.get('skin_attr_replace', {})
        for mm in body_meshes:
            for s_ in mm['subs']: s_['attr'] = [rep_.get(a, a) for a in s_['attr']]
    else:
        body_meshes = [mm for mm in (dwn if CFG.get('slot', 'top') == 'dwn' else top)['meshes'] if 'piercing' not in mm['mat'] and 'pierce' not in mm['mat']]   # the body pieces (piercings dropped: under clothes) of the slot this garment replaces
    # body coverage: an outfit that hides other slots (full-length dress: EQP hides the Legs model) ships that skin
    # inside its own model. Carry the same pieces of OUR body, or the legs/hands/feet vanish in game.
    def _cover(meshes):
        out = set()
        for m_ in meshes:
            if not is_skin(m_) or m_['nv'] == 0 or 'b0001_bibo' not in m_['mat']: continue
            P_ = attr(m_, 0)[0][:, :3][np.unique(tris(m_))]; y_ = P_[:, 1]; ax_ = np.abs(P_[:, 0])
            if ((y_ > 1.0) & (y_ < 1.45) & (ax_ < 0.2)).sum() > 200: out.add('torso')
            if ((y_ > 0.2) & (y_ < 0.85)).sum() > 200: out.add('legs')
            if ((ax_ > 0.5) & (y_ > 0.8) & (y_ < 1.1)).sum() > 200: out.add('hands')
            if (y_ < 0.12).sum() > 200: out.add('feet')
        return out
    a_cov = _cover(read(CFG['sizes'][list(CFG['sizes'])[0]])['meshes'])
    if 'legs' in a_cov and not ('legs' in _cover(body_meshes)):
        body_meshes = body_meshes + [mm for mm in dwn['meshes'] if mm['mat'] == '/mt_c0201b0001_bibo.mtrl' and mm['nv'] > 0]
        log.append('author model carries the legs skin (dress hides the Legs model): our legs skin added to the model')
    miss = a_cov - _cover(body_meshes)
    if miss: log.append('WARNING body pieces the author ships but the port lacks: %s' % sorted(miss)); print('WARNING missing body pieces', miss)
    report['body_cover'] = sorted(_cover(body_meshes))
    cloth_meshes = merge(pieces)
    if CFG.get('compact'):   # cloth only: half normals / UVs (56 instead of 72 bytes a vertex), body skin keeps full precision
        cloth_meshes = [compact_layout(mm) for mm in cloth_meshes]
    meshes = body_meshes + cloth_meshes
    Y = _copy.copy(X); Y['meshes'] = meshes
    bb = bonebbox_map(X); bb.update(bonebbox_map(top)); bb.update(bonebbox_map(dwn))
    for f in CFG.get('skin', []): bb.update(bonebbox_map(read(f)))
    Y['bonebbox_by_name'] = bb
    Y['attrs'] = list(X['attrs']); Y['mats'] = []; Y['bones'] = []
    vb = sum(len(s) for mm in meshes for s in mm['streams'])
    report.update(vb_mb=round(vb / 2 ** 20, 2), meshes=len(meshes), max_nv=max(mm['nv'] for mm in meshes),
                  max_table=max(len(mm['table']) for mm in meshes), shape_vals=sum(len(v) for mm in meshes for v in mm['shapes'].values()),
                  pieces=len(pieces))
    if vb >= 15.5 * 2 ** 20:
        bym = {}
        for mm in meshes: bym[mm['mat']] = bym.get(mm['mat'], 0) + sum(len(s) for s in mm['streams'])
        print('VERTEX BUFFER TOO BIG', {k: round(v / 2 ** 20, 2) for k, v in sorted(bym.items(), key=lambda x: -x[1])})
        print('\n'.join(log))
    report['too_big'] = bool(vb >= 15.5 * 2 ** 20)
    assert vb < 15.5 * 2 ** 20 or os.environ.get('PORT4_ALLOW_BIG') == '1', vb
    assert report['max_table'] <= 64, report['max_table']
    assert report['shape_vals'] < 65536
    write(Y, out_path)
    report['log'] = log
    return report

def pick_sizes(build):
    """author size closest to each chest option: mean distance author chest skin -> our chest (same Bibo UV spot)"""
    keys = list(CFG['sizes'])
    if len(keys) == 1: return {c: keys[0] for c in CH}
    top, dwn = read(CB + BUILDS[build][0]), read_dwn(build); res = {}
    for sz in keys:
        X, A = author_surface(sz)
        for ch in CH:
            B = our_surface_from(top, dwn, ch); tri, w, err = uv_map(A, B); Q = B.at(tri, w)
            sel = (A.part == 0) & (A.P[:, 1] > 1.12) & (A.P[:, 1] < 1.34) & (A.P[:, 2] > 0.0)
            res.setdefault(ch, {})[sz] = float(np.linalg.norm(Q - A.P, axis=1)[sel].mean())
    print('chest distance mm', {c: {k: round(v * 1000, 1) for k, v in d.items()} for c, d in res.items()})
    DIST = res
    return {c: min(d, key=d.get) for c, d in res.items()}

def shared_pieces(m, Tsel, combos, qmm=float(os.environ.get('QMM', '0.05')), base_attr=None):
    """one vertex buffer for all option copies of these triangles: a vertex that sits at the same place in several
    options is stored once and referenced by each option's sub-mesh (saves most of the vertex buffer)"""
    u, inv = np.unique(Tsel, return_inverse=True); T = inv.reshape(-1, 3)
    out = []; cur = None
    for P, Nn, Tn, Wf, names, tags in combos:
        Pu = P[u]
        key = np.c_[np.arange(len(u)), np.rint(Pu / (qmm * 1e-3)).astype(np.int64)]
        if cur is not None:
            idmap = np.array([cur['keys'].get(tuple(k), -1) for k in key.tolist()])
            if cur['n'] + int((idmap < 0).sum()) > 65000: cur = None
        if cur is None:
            cur = {'keys': {}, 'n': 0, 'rows': [], 'subs': [], 'names': set()}; out.append(cur)
            idmap = np.full(len(u), -1)
        new = np.where(idmap < 0)[0]
        idmap[new] = cur['n'] + np.arange(len(new))
        for k, j in zip(key[new].tolist(), idmap[new].tolist()): cur['keys'][tuple(k)] = j
        cur['n'] += len(new)
        cur['rows'].append((u[new], Pu[new], Nn[u][new], Tn[u][new], Wf[u][new], names))
        cur['names'] |= set(names)
        cur['subs'].append((idmap[T], tags))
    pieces = []
    for c in out:
        names = sorted(c['names'])
        src_idx = np.concatenate([r[0] for r in c['rows']]); P = np.concatenate([r[1] for r in c['rows']])
        Nn = np.concatenate([r[2] for r in c['rows']]); Tn = np.concatenate([r[3] for r in c['rows']])
        Wf = np.zeros((len(P), len(names))); o = 0
        for r in c['rows']:
            Wf[o:o + len(r[1]), [names.index(n) for n in r[5]]] = r[4]; o += len(r[1])
        mm = make_piece(m, np.arange(len(P)).reshape(-1, 1).repeat(3, 1)[:0], P, Nn, Tn, Wf, names, [], src_idx=src_idx)
        idx = []; subs = []; off = 0
        for Ti, tags in c['subs']:
            idx.append(Ti.astype(np.uint16).tobytes()); subs.append({'off': off, 'cnt': Ti.size, 'attr': (list(m['subs'][0]['attr']) if base_attr is None else base_attr) + tags, 'sbm': list(range(len(mm['table'])))}); off += Ti.size
        mm['idx'] = b''.join(idx); mm['ic'] = off; mm['subs'] = subs
        pieces.append(mm)
    return pieces

def limit_bones(W, names, maxb=60):
    """a piece may use at most `maxb` bones (the game's limit is 64 per mesh): the weakest bones go first, squish skin
    bones (cb_skin_*, NIRÆ Squish) before any other; a dropped squish bone's weight goes to the breast bone of its side
    (iv_c_mune_l / _r), anything else is shared out over the vertex's remaining bones"""
    tot = W.sum(0); used = np.where(tot > 0)[0]
    if len(used) <= maxb: return W
    W = W.copy()
    sq = np.array([names[i].startswith('cb_skin') for i in used])
    order = used[np.lexsort((tot[used], ~sq))]          # squish bones first, weakest first
    drop = order[:len(used) - maxb]
    for i in drop:
        tgt = 'iv_c_mune_' + names[i][-1] if names[i].startswith('cb_skin') and names[i][-1] in 'lr' else None
        if tgt in names:
            W[:, names.index(tgt)] += W[:, i]
        W[:, i] = 0
    s = W.sum(1, keepdims=True); W = np.where(s > 0, W / np.maximum(s, 1e-12), W)
    return W

def make_piece(m, Tsel, P, Nn, Tn, Wf, names, tags, src_idx=None):
    if src_idx is not None:
        # rows given directly: P/Nn/Tn/Wf are already per output vertex, src_idx = source vertex for the other attributes
        u = src_idx; T = np.zeros((0, 3), int)
        P = _expand(P, u, m['nv']); Nn = _expand(Nn, u, m['nv']); Tn = _expand(Tn, u, m['nv']); Wf = _expand(Wf, u, m['nv'])
        u = np.arange(len(src_idx)); _src = src_idx
    else:
        u, inv = np.unique(Tsel, return_inverse=True); T = inv.reshape(-1, 3); _src = u
    s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(m['nv'], -1)[_src].copy()
    s1 = np.frombuffer(m['streams'][1], np.uint8).reshape(m['nv'], -1)[_src].copy()
    s0[:, :12] = P[u].astype(np.float32).view(np.uint8).reshape(-1, 12)
    q8, order, tbl = quant(limit_bones(Wf[u], names), names)
    s0[:, 12:20] = q8; s0[:, 20:28] = order
    Nq = Nn[u] / np.maximum(np.linalg.norm(Nn[u], axis=1), 1e-12)[:, None]
    assert np.isfinite(Nq).all()
    s1[:, :12] = Nq.astype(np.float32).view(np.uint8).reshape(-1, 12)
    Tq = Tn[u] - np.einsum('nd,nd->n', Tn[u], Nq)[:, None] * Nq
    Tq /= np.maximum(np.linalg.norm(Tq, axis=1), 1e-12)[:, None]
    s1[:, 12:15] = np.clip(np.rint((Tq + 1) / 2 * 255), 0, 255).astype(np.uint8)
    mm = dict(m); mm['nv'] = len(u); mm['ic'] = T.size; mm['idx'] = T.astype(np.uint16).tobytes()
    mm['streams'] = [s0.tobytes(), s1.tobytes()] + list(m['streams'][2:]); mm['shapes'] = {}
    mm['table'] = tbl
    base_attr = m['subs'][0]['attr']
    mm['subs'] = [{'off': 0, 'cnt': T.size, 'attr': list(base_attr) + tags, 'sbm': list(range(len(tbl)))}]
    return mm

def _expand(X, u, nv):
    return X   # rows are already in output order (indexed by np.arange below)

def merge(pieces):
    """pack pieces of the same material into meshes <=65000 vertices (shared bone table)"""
    groups = {}
    for p in pieces: groups.setdefault(p['mat'], []).append(p)
    out = []
    for mat, ps in groups.items():
        cur = None
        for p in ps:
            names = sorted(set(p['table']) | (set(cur['table']) if cur else set()))
            if cur is not None and cur['nv'] + p['nv'] <= 65000 and len(names) <= 64:
                remap_into(cur, names); q = dict(p); remap_into(q, names)
                off = cur['nv']; ic = cur['ic']
                cur['streams'] = [a + b for a, b in zip(cur['streams'], q['streams'])]
                cur['idx'] = cur['idx'] + (np.frombuffer(q['idx'], np.uint16).astype(np.int64) + off).astype(np.uint16).tobytes()
                cur['subs'] = cur['subs'] + [dict(s, off=s['off'] + ic, sbm=list(range(len(names)))) for s in q['subs']]
                for s in cur['subs']: s['sbm'] = list(range(len(names)))
                cur['nv'] += q['nv']; cur['ic'] += q['ic']
            else:
                cur = dict(p); cur['streams'] = list(p['streams']); out.append(cur)
    return out

def remap_into(mm, names):
    if mm['table'] == names: return
    old = mm['table']; lut = np.array([names.index(n) for n in old], np.uint8)
    s0 = np.frombuffer(mm['streams'][0], np.uint8).reshape(mm['nv'], -1).copy()
    w = s0[:, 12:20]; s0[:, 20:28] = np.where(w > 0, lut[s0[:, 20:28]], 0)
    mm['streams'] = [s0.tobytes()] + list(mm['streams'][1:]); mm['table'] = list(names)

if __name__ == '__main__':
    build = sys.argv[1]; out = sys.argv[2]   # usage: port4.py BUILD OUT.mdl outfit.json
    load_cfg(sys.argv[3]); import surf as _s; CFG = _s.CFG
    PICK = pick_sizes(build); print('PICK', PICK)
    rep = run(build, out, {})
    print(json.dumps({k: v for k, v in rep.items() if k != 'log'}, indent=0))
    print('\n'.join(rep['log']))
