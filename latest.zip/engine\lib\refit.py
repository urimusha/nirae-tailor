"""refit an existing NIRÆ port to a newer body version (same UV layout, e.g. NIRÆ 0.9.110 hips rework) without
re-porting: keeps every hand fix of the port.
  1. body pieces inside the outfit (exact copies of the old body's meshes) are replaced by the new body's meshes
     (positions, normals, weights, shape keys, topology - e.g. the reworked legs skin has more vertices)
  2. (optional, move=True) cloth keeps its height above the skin spot under it on the new body. Not used by default:
     the 0.9.110 change of the visible skin is <= 1-4 mm, and moving skin-level pieces (tights made from the old legs
     mesh) by projection made the crotch worse
  3. clean-up against the new body: only what the body change made worse - every cloth vertex keeps at least
     min(its old height above the skin, 1.5 mm), smoothly, option-aware (hips / belly options it is shown with)
usage: refit.py IN.mdl OUT.mdl BUILD [HIPS]   (HIPS = small|medium|large for per-hips files)"""
import sys, copy
from surf import *
from mdlio import write, bonebbox_map
from scipy.spatial import cKDTree
import surf as _S
import vtx
import copy

SKIN_MATS = ('bibo', 'cbinner', 'nirae_pube', 'nirae_pierce', 'nirae_nail')
HIPS = ('small', 'medium', 'large')
BELLY = ('full', 'soft', 'none', 'vnone', 'rfull')
BELLY_ATTR = {'vnone': 'none', 'rfull': 'full'}          # the waist options show the none / full cloth

def is_skin_mesh(m): return any(k in m['mat'] for k in SKIN_MATS)

def uv_disp(a, b):
    """per vertex of mesh a: displacement to the same UV spot of mesh b (a body mesh whose topology changed a little,
    e.g. the athletic / slim lower torso got 2-4 vertices in 0.9.110); 3D-closest wins among overlapping UV copies"""
    PA = attr(a, 0)[0][:, :3].astype(float); UA = attr(a, 4)[0][:, :2].astype(float)
    PB = attr(b, 0)[0][:, :3].astype(float); UB = attr(b, 4)[0][:, :2].astype(float); TB = tris(b)
    C = UB[TB].mean(1); _, cand = cKDTree(C).query(UA, k=16)
    best = np.full(len(PA), np.inf); Q = PA.copy(); q3 = np.c_[UA, np.zeros(len(UA))]
    for j in range(cand.shape[1]):
        t = cand[:, j]; tr = np.dstack([UB[TB[t]], np.zeros((len(t), 3, 1))])
        c = _S._closest_on_tris(q3, tr[:, 0], tr[:, 1], tr[:, 2]); du = np.linalg.norm(c - q3, axis=1)
        w = np.clip(_S.bary(c, tr), 0, 1); w /= w.sum(1, keepdims=True); X = np.einsum('ni,nij->nj', w, PB[TB[t]])
        score = du * 50 + np.linalg.norm(X - PA, axis=1)
        bt = score < best; best[bt] = score[bt]; Q[bt] = X[bt]
    return Q - PA

_F = {}
class Field:
    """old body surface (top lower torso + medium chest, dwn bibo meshes) with the per-vertex old -> new displacement"""
    def __init__(s, build, hips):
        ot = read(CB + _S.BUILDS_OLD[build][0]); nt = read(CB + _S.BUILDS[build][0])
        od = read(CB + _S.HIPSF_OLD[build][hips]); nd = read(CB + _S.HIPSF[build][hips])
        s.top_old, s.top_new, s.dwn_old, s.dwn_new = ot, nt, od, nd
        Dd = _S._hips_disp(od, nd)
        Ps, Ts, Ds = [], [], []; o = 0
        for M_, mi, D in [(ot, 0, None), (ot, 4, None)] + [(od, mi, D) for mi, D in Dd.items()]:
            m = M_['meshes'][mi]; P = attr(m, 0)[0][:, :3].astype(float); T = tris(m)
            if D is None:
                mn = nt['meshes'][mi]
                D = attr(mn, 0)[0][:, :3].astype(float) - P if mn['nv'] == m['nv'] else uv_disp(m, mn)
            u, inv = np.unique(T, return_inverse=True)
            Ps.append(P[u]); Ts.append(inv.reshape(-1, 3) + o); Ds.append(D[u]); o += len(u)
        s.P = np.concatenate(Ps); s.T = np.concatenate(Ts); s.D = np.concatenate(Ds)
        s.surf = Surf(s.P, s.T, None, None)
    def disp(s, X, near=0.02, far=0.08):
        t, w, q, d = s.surf.closest(X)
        Dx = np.einsum('ni,nij->nj', w, s.D[s.T[t]])
        f = np.clip((far - d) / (far - near), 0, 1); f = f * f * (3 - 2 * f)
        return Dx * f[:, None], d

def field(build, hips):
    if (build, hips) not in _F: _F[(build, hips)] = Field(build, hips)
    return _F[(build, hips)]

def _ii(m): return np.frombuffer(m['idx'], np.uint16).astype(int)

_TREES = {}
def _tree(mo):
    k = id(mo)
    if k not in _TREES:
        ub = np.unique(_ii(mo)); D = vtx.decode(mo)
        _TREES[k] = (cKDTree(D[(0, 0)][1][ub, :3]), ub, D)
    return _TREES[k]

def base_map(m, mo):
    """the outfit skin mesh's referenced vertices -> the old body mesh's vertices (exact position; ties by UV, normal).
    None when any referenced vertex has no exact counterpart (not a copy of this body mesh)"""
    tr, ubo, B = _tree(mo); A = vtx.decode(m); ub = np.unique(_ii(m))
    Pm = A[(0, 0)][1][:, :3]; Um = A[(4, 0)][1][:, :2]; Nm = A[(3, 0)][1][:, :3]
    Uo = B[(4, 0)][1][:, :2]; No = B[(3, 0)][1][:, :3]
    d, j = tr.query(Pm[ub[:64]])
    if d.max() > 1e-6: return None
    k = np.full(m['nv'], -1)
    for v, cs in zip(ub, tr.query_ball_point(Pm[ub], 1e-6)):
        if not cs: return None
        cs = ubo[np.array(cs)]
        if len(cs) > 1: cs = cs[np.argsort(np.linalg.norm(Uo[cs] - Um[v], axis=1) * 10 + np.linalg.norm(No[cs] - Nm[v], axis=1))]
        k[v] = cs[0]
    return k

def _pkeys(m):
    """per vertex: an exact key of its float32 position"""
    P = vtx.decode(m)[(0, 0)][1][:, :3].astype('<f4')
    _, inv = np.unique(np.ascontiguousarray(P).view('V12').ravel(), return_inverse=True)
    return P, inv

def tri_map(m, mo, k=None):
    """the outfit mesh's index positions -> the old body mesh's index positions, sub-mesh by sub-mesh, by the exact
    corner positions (ports keep the body's triangles verbatim, they only drop some: trimmed skin under cloth, removed
    option sub-meshes). The body has exact duplicate vertices (same position / UV / normal), so triangles are matched
    by position and order, not through a vertex map"""
    idx, ido = _ii(m), _ii(mo); pos = np.full(len(idx), -1)
    Pm, km = _pkeys(m); Po, ko_ = _pkeys(mo)
    # common key space
    allk = np.unique(np.concatenate([np.ascontiguousarray(Pm).view('V12').ravel(), np.ascontiguousarray(Po).view('V12').ravel()]))
    km = np.searchsorted(allk, np.ascontiguousarray(Pm).view('V12').ravel()); ko = np.searchsorted(allk, np.ascontiguousarray(Po).view('V12').ravel())
    subs = m['subs'] or [dict(off=0, cnt=len(idx), attr=[])]
    osubs = mo['subs'] or [dict(off=0, cnt=len(ido), attr=[])]
    sub_of = np.zeros(len(ido), int); aset = []
    for si, so in enumerate(osubs): sub_of[so['off']:so['off'] + so['cnt']] = si; aset.append(set(so['attr']))
    table = {}
    for t, tri in enumerate(map(tuple, ko[ido].reshape(-1, 3))): table.setdefault(tri, []).append(3 * t)
    for sb in subs:
        A = set(sb['attr'])          # ports drop attributes (e.g. the nip option ones) - the body sub-mesh has a superset
        T = km[idx[sb['off']:sb['off'] + sb['cnt']]].reshape(-1, 3)
        for t, tri in enumerate(map(tuple, T)):
            lst = table.get(tri)
            if not lst: return None
            sel = next((ii for ii, p in enumerate(lst) if A <= aset[sub_of[p]]), 0)
            p0 = lst.pop(sel); pos[sb['off'] + 3 * t:sb['off'] + 3 * t + 3] = (p0, p0 + 1, p0 + 2)
    return pos

KEEP_NEW_SHAPES = True
def rebuild(m, mn, pos):
    """the outfit skin mesh rebuilt from the NEW body mesh: the same triangles (index positions, mapped), the new body's
    vertex data (positions, normals, tangents, weights, UVs) and shape keys restricted to those triangles, written in
    the outfit mesh's own vertex layout; its sub-meshes (attributes) stay. The body's base topology is unchanged
    between 0.9.109 and 0.9.112 (same index buffers), only vertex data and shape-key pairs changed."""
    idn = _ii(mn); base = idn[pos]; inv = {int(p): i for i, p in enumerate(pos)}
    shapes = {}; dropped = []
    for name, pairs in mn['shapes'].items():
        sel = [(inv[io], rv) for io, rv in pairs if io in inv]
        if not sel: continue
        if name not in m['shapes'] and not KEEP_NEW_SHAPES: dropped.append(name); continue
        shapes[name] = sel
    extra = [n for n in m['shapes'] if n not in mn['shapes']]
    verts = np.unique(np.concatenate([base] + [np.array([rv for _, rv in v]) for v in shapes.values()]))
    data = vtx.decode(mn, sel=verts)
    m2 = dict(m); m2['nv'] = len(verts); ni = np.searchsorted(verts, base)
    assert len(verts) < 65536
    m2['idx'] = ni.astype('<u2').tobytes(); m2['ic'] = len(ni); m2['streams'] = vtx.encode_into(m, data, len(verts))
    m2['shapes'] = {n: [(int(io), int(np.searchsorted(verts, rv))) for io, rv in v] for n, v in shapes.items()}
    m2['table'] = list(mn['table'])
    return m2, dropped, extra

_MODELS = {}
def _model(fname):
    if fname not in _MODELS: _MODELS[fname] = read(CB + fname)
    return _MODELS[fname]

def replace_skin(M, build, hips_list):
    """outfit skin meshes (full or trimmed copies of an old body mesh) -> the new body's.
    Same base topology (index buffer): rebuilt from the new body mesh (rebuild: the outfit's triangles, sub-meshes and
    vertex layout stay). New topology (0.9.120 legs: reworked vulva): only full copies can follow - they are swapped
    for the new body mesh as it is, and body meshes the old body did not have (0.9.120: the vulva's own mesh 4) are
    added after the outfit's meshes, so the cloth keeps its mesh numbers."""
    rep = []
    cands = []
    models = [('top', _model(_S.BUILDS_OLD[build][0]), _model(_S.BUILDS[build][0]))]
    models += [('dwn_' + h, _model(_S.HIPSF_OLD[build][h]), _model(_S.HIPSF[build][h])) for h in hips_list]
    for tag, old, new in models:
        for j, m in enumerate(old['meshes']):
            if m['nv'] and j < len(new['meshes']): cands.append((tag, j, m, new['meshes'][j]))
    full_swapped = {}
    for i, m in enumerate(M['meshes']):
        if m['nv'] == 0 or not is_skin_mesh(m): continue
        hit = None
        for tag, j, mo, mn in cands:
            if mo['mat'] != m['mat']: continue
            k = base_map(m, mo)
            if k is None: continue
            pos = tri_map(m, mo, k)
            if pos is None: continue
            hit = (tag, j, mo, mn, pos); break
        if hit is None: rep.append((i, m['mat'][-24:], 'NO MATCH - left as is')); continue
        tag, j, mo, mn, pos = hit
        full = len(pos) == len(_ii(mo))
        if _ii(mo).tobytes() != _ii(mn).tobytes():
            if not full:
                rep.append((i, m['mat'][-24:], '%s mesh %d: NEW TOPOLOGY and the port only carries part of it - NOT replaced' % (tag, j))); continue
            M['meshes'][i] = copy.deepcopy(mn); full_swapped.setdefault(tag, set()).add(j)
            rep.append((i, m['mat'][-24:], '%s mesh %d (full copy, new topology) swapped for the new body mesh: %d -> %d verts, %d -> %d indices, sub-meshes %s, shapes %s' % (
                tag, j, m['nv'], mn['nv'], len(_ii(m)), len(_ii(mn)), [tuple(su['attr']) for su in mn['subs']], sorted(mn['shapes']))))
            continue
        P0 = attr(m, 0)[0][:, :3].astype(float); idx0 = _ii(m)
        m2, dropped, extra = rebuild(m, mn, pos)
        M['meshes'][i] = m2
        if full: full_swapped.setdefault(tag, set()).add(j)
        P1 = attr(m2, 0)[0][:, :3].astype(float); mv = np.linalg.norm(P1[_ii(m2)] - P0[idx0], axis=1)
        Da = vtx.decode(m); Db = vtx.decode(m2); i2 = _ii(m2); ch = np.zeros(len(idx0), bool)
        for key in Da:
            a = Da[key][1][idx0]; b = Db[key][1][i2]
            ch |= (a != b).any(1) if a.dtype == np.uint8 else (np.abs(a - b) > 1e-6).any(1)
        nsh = sum(len(v) for v in m['shapes'].values()); nsh2 = sum(len(v) for v in m2['shapes'].values())
        fl = 'full copy' if full else 'trimmed copy %d/%d idx' % (len(pos), len(_ii(mo)))
        newsh = sorted(set(m2['shapes']) - set(m['shapes']))
        rep.append((i, m['mat'][-24:], '%s mesh %d (%s) rebuilt: %d -> %d verts, corners moved max %.1f mm, corners with new data %d, shape pairs %d -> %d%s%s%s' % (
            tag, j, fl, m['nv'], m2['nv'], mv.max() * 1000, int(ch.sum()), nsh, nsh2, ', new shapes ' + ','.join(newsh) if newsh else '',
            ', port has no ' + ','.join(dropped) if dropped else '', ', port-only shapes kept OUT ' + ','.join(extra) if extra else '')))
    # body meshes the old body did not have, for outfits that carry that body model as full copies
    for tag, old, new in models:
        if tag not in full_swapped: continue
        for j, mn in enumerate(new['meshes']):
            if mn['nv'] == 0 or (j < len(old['meshes']) and old['meshes'][j]['nv']): continue
            M['meshes'].append(copy.deepcopy(mn))
            rep.append((len(M['meshes']) - 1, mn['mat'][-24:], '%s mesh %d is NEW in the body (%d verts, sub-meshes %s) - added' % (tag, j, mn['nv'], [tuple(su['attr']) for su in mn['subs']])))
    return rep

def replace_skin_old(M, build, hips_list):
    """(0.9.112 first version) exact copies only: positions in place / whole-mesh replacement"""
    rep = []
    cands = []
    F0 = field(build, hips_list[0])
    for tag, old, new in [('top', F0.top_old, F0.top_new)] + [('dwn_' + h, field(build, h).dwn_old, field(build, h).dwn_new) for h in hips_list]:
        for j, m in enumerate(old['meshes']):
            if m['nv']: cands.append((tag, j, m, new['meshes'][j]))
    for i, m in enumerate(M['meshes']):
        if m['nv'] == 0 or not is_skin_mesh(m): continue
        P = attr(m, 0)[0][:, :3].astype(float); best = None
        for tag, j, mo, mn in cands:
            if mo['mat'] != m['mat'] or mo['nv'] != m['nv']: continue
            Q = attr(mo, 0)[0][:, :3].astype(float)
            if np.abs(Q - P).max() < 1e-5: best = (tag, j, mo, mn); break
        if best is None: rep.append((i, m['mat'][-24:], 'NO MATCH - left as is')); continue
        tag, j, mo, mn = best
        if mn['nv'] == m['nv']:
            Pn = attr(mn, 0)[0][:, :3].astype(float); mv = np.linalg.norm(Pn - P, axis=1)
            s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(m['nv'], -1).copy()
            s0[:, :12] = Pn.astype('<f4').view(np.uint8).reshape(-1, 12); m['streams'] = [s0.tobytes()] + list(m['streams'][1:])
            rep.append((i, m['mat'][-24:], '%s mesh %d: positions updated (%d moved, max %.1f mm)' % (tag, j, int((mv > 1e-5).sum()), mv.max() * 1000)))
            continue
        same_subs = [sorted(x['attr']) for x in m['subs']] == [sorted(x['attr']) for x in mo['subs']]
        same_layout = list(m['strides']) == list(mn['strides']) and m['decl'] == mn['decl']
        if not (same_subs and same_layout):
            rep.append((i, m['mat'][-24:], 'NEW TOPOLOGY but the port changed its sub-meshes/layout - NOT replaced')); continue
        M['meshes'][i] = copy.deepcopy(mn)
        rep.append((i, m['mat'][-24:], '%s mesh %d replaced: %d -> %d verts' % (tag, j, m['nv'], mn['nv'])))
    return rep

def hips_of_subs(m, default):
    """per vertex: the hips option it belongs to (from atrx_cb_hips_* sub attributes; else `default`)"""
    idx = np.frombuffer(m['idx'], np.uint16).astype(int); hv = np.full(m['nv'], default, object); shared = np.zeros(m['nv'], bool)
    for sb in m['subs']:
        u = np.unique(idx[sb['off']:sb['off'] + sb['cnt']])
        hs = [a[len('atrx_cb_hips_'):] for a in sb['attr'] if a.startswith('atrx_cb_hips_')]
        if hs: hv[u] = np.where(shared[u], hv[u], hs[0])
        else: shared[u] = True; hv[u] = default          # shared pieces win (seam vertices stay on the common piece)
    # shape replacement vertices belong with the vertex they replace
    for sh in m.get('shapes', {}).values():
        for io, rv in sh: hv[rv] = hv[idx[io]]
    return hv

_SUR = {}; _OLDB = {}
def old_body(build):
    if build not in _OLDB:
        ot = read(CB + _S.BUILDS_OLD[build][0])
        od = read(CB + _S.HIPSF_OLD[build]['medium']); od['_hipsD'] = {'medium': None}
        for h in ('small', 'large'): od['_hipsD'][h] = _S._hips_disp(od, read(CB + _S.HIPSF_OLD[build][h]))
        _OLDB[build] = (ot, od)
    return _OLDB[build]
def _dwn_exact(fname):
    d = read(CB + fname); d['_hipsD'] = {'small': [0.0] * len(d['meshes']), 'medium': None, 'large': [0.0] * len(d['meshes'])}
    return d
_TOPS = {}
def _top(fname):
    if fname not in _TOPS: _TOPS[fname] = read(CB + fname)
    return _TOPS[fname]
def surfaces(build, hips, belly='full'):
    """old and new body surfaces (medium chest) for this hips / belly option, each from its own hips file"""
    if (build, hips, belly) not in _SUR:
        ot = _top(_S.BUILDS_OLD[build][0]); nt = _top(_S.BUILDS[build][0])
        od = _dwn_exact(_S.HIPSF_OLD[build][hips]); nd = _dwn_exact(_S.HIPSF[build][hips])
        _SUR[(build, hips, belly)] = (our_surface_from(ot, od, 'medium', belly, hips), our_surface_from(nt, nd, 'medium', belly, hips))
    return _SUR[(build, hips, belly)]

def move_cloth(M, build, file_hips, near=0.02, far=0.08):
    """cloth keeps its height above the skin: closest skin spot on the old body -> the same spot on the new body
    (closest point), + the same height along the new normal; full up to 2 cm off the skin, fading out by 8 cm"""
    st = []
    for i, m in enumerate(M['meshes']):
        if m['nv'] == 0 or is_skin_mesh(m): continue
        P = attr(m, 0)[0][:, :3].astype(float).copy(); hv = hips_of_subs(m, file_hips or 'medium'); mv = np.zeros(len(P))
        for h in HIPS:
            s = np.where(hv == h)[0]
            if not len(s): continue
            Bo, Bn = surfaces(build, h)
            t, w, q, d = Bo.closest(P[s]); no = Bo.nrm(t, w); hgt = np.einsum('nd,nd->n', P[s] - q, no)
            t2, w2, q2, d2 = Bn.closest(q); nn = Bn.nrm(t2, w2)
            target = q2 + nn * hgt[:, None] + (P[s] - q - no * hgt[:, None])
            f = np.clip((far - d) / (far - near), 0, 1); f = f * f * (3 - 2 * f)
            Dx = (target - P[s]) * f[:, None]; P[s] += Dx; mv[s] = np.linalg.norm(Dx, axis=1)
        nv = m['nv']; s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(nv, -1).copy()
        s0[:, :12] = P.astype('<f4').view(np.uint8).reshape(-1, 12); m['streams'] = [s0.tobytes()] + list(m['streams'][1:])
        st.append((i, m['mat'][-26:], int((mv > 0.0005).sum()), round(float(mv.max()) * 1000, 1)))
    return st

CFG2 = [(h, b) for h in HIPS for b in BELLY]
def cfg_mask(attrs, file_hips):
    mk = 0
    for ci, (h, b) in enumerate(CFG2):
        if file_hips and h != file_hips: continue
        sel = dict(belly=BELLY_ATTR.get(b, b), hips=h)
        ok = True
        for a in attrs:
            if not a.startswith('atrx_cb_'): continue
            k, v = a[8:].split('_', 1)
            if k in sel and sel[k] != v: ok = False
        if ok: mk |= 1 << ci
    return mk

def cloth_parts(M, file_hips, ymax=1.12):
    parts = []; masks = []
    for mi, m in enumerate(M['meshes']):
        if m['nv'] == 0 or is_skin_mesh(m): continue
        idx = np.frombuffer(m['idx'], np.uint16).astype(int); mk = np.zeros(m['nv'], np.int64)
        for sb in m['subs']:
            u = np.unique(idx[sb['off']:sb['off'] + sb['cnt']]); mk[u] |= cfg_mask(sb['attr'], file_hips)
        P = attr(m, 0)[0][:, :3].astype(float)
        v = np.where((mk > 0) & (P[:, 1] < ymax))[0]
        if len(v): parts.append((mi, v)); masks.append(mk[v])
    return parts, masks

def heights(build, P, MK, file_hips, which):
    """signed height above the old / new body per vertex for every option it is shown with: {config: (vis, sd, d)}"""
    out = {}
    for ci, (h, b) in enumerate(CFG2):
        if file_hips and h != file_hips: continue
        vis = np.where((MK >> ci) & 1)[0]
        if not len(vis): continue
        B = surfaces(build, h, b)[0 if which == 'old' else 1]
        t, w, q, d = B.closest(P[vis]); n = B.nrm(t, w); out[ci] = (vis, np.einsum('nd,nd->n', P[vis] - q, n), d, n)
    return out

WAIST = ('vnone', 'rfull')          # waist options: they show the None / Full cloth (no attributes of their own)
CLEAN_WAIST = False                 # False: the shared None / Full cloth stays fitted to None / Full (see report)

def _colocated(P, mesh_of):
    return cKDTree(P + mesh_of[:, None] * 10.0).query_pairs(5e-5, output_type='ndarray')

def _equalize(P0, P, pairs):
    """co-located vertices (seams, option copies) move together: the larger move wins"""
    if not len(pairs): return P
    for _ in range(2):
        T_ = P - P0; a, b = pairs[:, 0], pairs[:, 1]; la = np.linalg.norm(T_[a], axis=1); lb = np.linalg.norm(T_[b], axis=1)
        Tn = T_.copy(); Tn[b[la > lb]] = T_[a[la > lb]]; Tn[a[lb > la]] = T_[b[lb > la]]; P = P0 + Tn
    return P

def _write_parts(M, parts, P):
    o = 0
    for mi, v in parts:
        m = M['meshes'][mi]; nv = m['nv']; s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(nv, -1).copy()
        Pm = attr(m, 0)[0][:, :3].astype(float); Pm[v] = P[o:o + len(v)]; o += len(v)
        s0[:, :12] = Pm.astype('<f4').view(np.uint8).reshape(-1, 12); m['streams'] = [s0.tobytes()] + list(m['streams'][1:])

def follow(M, build, file_hips, base, near=0.02, far=0.04, sigma=0.005, lo=-0.003, hi=0.015):
    """cloth keeps its height above the skin where the body moved under it (0.9.120 lower body: up to 8 mm): per
    vertex the change of the skin height under it (old body -> new body) along the new skin normal, for the options
    it is shown with (its own belly / hips variant; waist options excluded), full up to 2 cm off the skin, fading out
    by 4 cm, smoothed over the cloth (sigma 5 mm, only between pieces shown together); co-located vertices together"""
    parts, MK, P_old, H_old = base
    if not parts: return 0, 0.0
    P0 = np.concatenate([attr(M['meshes'][mi], 0)[0][:, :3].astype(float)[v] for mi, v in parts])
    mesh_of = np.concatenate([np.full(len(v), k) for k, (mi, v) in enumerate(parts)])
    H_new = heights(build, P0, MK, file_hips, 'new')
    acc = np.zeros_like(P0); cnt = np.zeros(len(P0))
    for ci, (vis, so, do, no) in H_old.items():
        if CFG2[ci][1] in WAIST: continue
        _, sn, dn, nn = H_new[ci]
        dl = np.clip(so - sn, lo, hi)
        f = np.clip((far - do) / (far - near), 0, 1); f = f * f * (3 - 2 * f)
        acc[vis] += nn * (dl * f)[:, None]; cnt[vis] += 1
    D = acc / np.maximum(cnt, 1)[:, None]
    act = np.where(np.linalg.norm(D, axis=1) > 1e-5)[0]
    if not len(act): return 0, 0.0
    Ds = np.zeros_like(D)
    for k in range(len(parts)):
        s = np.where(mesh_of == k)[0]; a = act[mesh_of[act] == k]
        if not len(a): continue
        tr = cKDTree(P0[s]); reach = np.unique(np.concatenate([np.array(j, int) for j in tr.query_ball_point(P0[a], 3 * sigma)]))
        tgt = s[reach]
        for i0 in range(0, len(tgt), 4000):
            ii = tgt[i0:i0 + 4000]; nb = tr.query_ball_point(P0[ii], 3 * sigma)
            for i, js in zip(ii, nb):
                js = s[np.array(js, int)]; js = js[(MK[js] & MK[i]) != 0]
                w = np.exp(-np.sum((P0[js] - P0[i]) ** 2, 1) / (2 * sigma ** 2)); Ds[i] = (w[:, None] * D[js]).sum(0) / max(w.sum(), 1e-12)
    P = _equalize(P0, P0 + Ds, _colocated(P0, mesh_of))
    _write_parts(M, parts, P)
    mv = np.linalg.norm(P - P0, axis=1)
    return int((mv > 0.0005).sum()), round(float(mv.max()) * 1000, 1)

def clean(M, build, file_hips, base, gap=0.0015, sigma=0.01, iters=3):
    """push out only what the body change made worse: every vertex keeps at least min(its old height, gap) above the
    new skin (cloth that was already inside before - e.g. skin-tight pieces made at skin level - is not touched)"""
    parts, MK, P_old, H_old = base
    if not parts: return 0, 0.0, 0
    P = np.concatenate([attr(M['meshes'][mi], 0)[0][:, :3].astype(float)[v] for mi, v in parts]); P0 = P.copy()
    mesh_of = np.concatenate([np.full(len(v), k) for k, (mi, v) in enumerate(parts)])
    pairs = cKDTree(P0 + mesh_of[:, None] * 10.0).query_pairs(5e-5, output_type='ndarray')
    total = 0
    for it in range(iters):
        H_new = heights(build, P, MK, file_hips, 'new'); D = np.zeros_like(P); hit = np.zeros(len(P), bool)
        for ci, (vis, sd, d, n) in H_new.items():
            if CFG2[ci][1] in WAIST and not CLEAN_WAIST: continue
            req = np.minimum(H_old[ci][1], gap)
            need = (req - sd) * ((d < 0.02) & (sd < req - 0.0002)); m_ = need > np.linalg.norm(D[vis], axis=1)
            D[vis[m_]] = n[m_] * need[m_, None]; hit[vis[need > 0]] = True
        if not hit.any(): break
        total += int(hit.sum())
        hi = np.where(hit)[0]; tr = cKDTree(P[hi]); nb = tr.query_ball_point(P, 3 * sigma)
        S = np.zeros_like(P); Wt = np.zeros(len(P))
        for i, js in enumerate(nb):
            if not js: continue
            js = np.array(js); js = js[(MK[hi[js]] & MK[i]) != 0]
            if not len(js): continue
            w = np.exp(-np.sum((P[hi[js]] - P[i]) ** 2, 1) / (2 * sigma ** 2)); S[i] = (w[:, None] * D[hi[js]]).sum(0) / max(w.sum(), 1e-9)
            Wt[i] = w.max()
        P = P + S * Wt[:, None]
        if len(pairs):
            for _ in range(2):
                T_ = P - P0; a, b = pairs[:, 0], pairs[:, 1]; la = np.linalg.norm(T_[a], axis=1); lb = np.linalg.norm(T_[b], axis=1)
                Tn = T_.copy(); Tn[b[la > lb]] = T_[a[la > lb]]; Tn[a[lb > la]] = T_[b[lb > la]]; P = P0 + Tn
    o = 0
    for mi, v in parts:
        m = M['meshes'][mi]; nv = m['nv']; s0 = np.frombuffer(m['streams'][0], np.uint8).reshape(nv, -1).copy()
        Pm = attr(m, 0)[0][:, :3].astype(float); Pm[v] = P[o:o + len(v)]; o += len(v)
        s0[:, :12] = Pm.astype('<f4').view(np.uint8).reshape(-1, 12); m['streams'] = [s0.tobytes()] + list(m['streams'][1:])
    mv = np.linalg.norm(P - P0, axis=1)
    return total, round(float(mv.max()) * 1000, 1), int((mv > 0.001).sum())

def worse_report(M, build, file_hips, base, tol=0.0005):
    """per option: cloth vertices whose height above the NEW skin is below min(their height above the OLD skin, 0) - tol
    (= clipping the body change introduced), deepest of them; and how many sit inside at all (old / new)"""
    parts, MK, P_old, H_old = base
    if not parts: return {}
    P = np.concatenate([attr(M['meshes'][mi], 0)[0][:, :3].astype(float)[v] for mi, v in parts])
    H_new = heights(build, P, MK, file_hips, 'new'); out = {}
    for ci, (vis, sd, d, n) in H_new.items():
        so = H_old[ci][1]; near = d < 0.02
        worse = near & (sd < np.minimum(so, 0) - tol)
        out['%s/%s' % CFG2[ci]] = (int(worse.sum()), round(float(sd[worse].min()) * 1000, 1) if worse.any() else 0.0,
                                   int((near & (so < -tol)).sum()), int((near & (sd < -tol)).sum()))
    return out

FOLLOW = True
def refit(src, dst, build, file_hips=None, check=True, move=False):
    M = read(src); bb = bonebbox_map(M)
    parts, masks = cloth_parts(M, file_hips)
    MK = np.concatenate(masks) if masks else np.zeros(0, np.int64)
    P_old = np.concatenate([attr(M['meshes'][mi], 0)[0][:, :3].astype(float)[v] for mi, v in parts]) if parts else np.zeros((0, 3))
    H_old = heights(build, P_old, MK, file_hips, 'old') if parts else {}
    base = (parts, MK, P_old, H_old)
    before = worse_report(M, build, file_hips, base) if check else None
    rep = replace_skin(M, build, [file_hips] if file_hips else list(HIPS))
    st = move_cloth(M, build, file_hips) if move else []
    fo = follow(M, build, file_hips, base) if FOLLOW else (0, 0.0)
    if FOLLOW: st.append(('follow (verts moved > 0.5 mm, max mm)', fo))
    cl = clean(M, build, file_hips, base)
    after = worse_report(M, build, file_hips, base) if check else None
    M['bonebbox_by_name'] = bb; M['bones'] = []
    write(M, dst)
    return rep, st, cl, before, after

if __name__ == '__main__':
    src, dst, build = sys.argv[1], sys.argv[2], sys.argv[3]; fh = sys.argv[4] if len(sys.argv) > 4 else None
    rep, st, cl, before, after = refit(src, dst, build, fh)
    for r in rep: print('skin', r)
    for r in st: print('cloth moved (mesh, mat, verts > 0.5 mm, max mm)', r)
    print('clean-up (hits, max mm, verts moved > 1 mm)', cl)
    print('vs new body, unchanged cloth (option: newly clipping n, deepest mm, inside before n, inside now n)', before)
    print('vs new body, refitted cloth  (option: newly clipping n, deepest mm, inside before n, inside now n)', after)
