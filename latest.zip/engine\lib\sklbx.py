"""Bone names + parents of any FFXIV .sklb (base skeletons and the extra EST skeletons of gear, which have no n_root):
the bone-name list is the longest run of length-prefixed bone names, the parents the signed vint array before it."""
import re, struct
import numpy as np

NAME = re.compile(rb'[A-Za-z0-9_]+')


def _uvarint(d, o):
    r = 0; s = 0
    while True:
        b = d[o]; o += 1; r |= (b & 0x7f) << s; s += 7
        if not b & 0x80: return r, o


def _svint(d, o):
    b = d[o]; o += 1; neg = b & 1; v = (b & 0x7E) >> 1; pos = 6
    while b & 0x80:
        b = d[o]; o += 1; v |= (b & 0x7F) << pos; pos += 7
    return (-v if neg else v), o


def _names_at(d, st):
    o = st; names = []
    while o < len(d):
        L, o2 = _uvarint(d, o); n = L >> 1; s = d[o2:o2 + n]
        if L & 1 or n == 0 or len(s) < n or not NAME.fullmatch(s): break
        names.append(s.decode()); o = o2 + n
    return names, o


def parse(path):
    d = open(path, 'rb').read()
    best = None
    for m in re.finditer(rb'[jn][a-z]{0,3}_[A-Za-z0-9_]+', d):
        st = m.start() - 1
        if st < 0 or d[st] != (len(m.group()) << 1): continue
        names, o = _names_at(d, st)
        if not names: continue
        try:
            c, o2 = _uvarint(d, o)
        except IndexError:
            continue
        if c >> 1 != len(names): continue
        if best is None or len(names) > len(best[1]): best = (st, names, o2)
    if best is None: raise ValueError('no bone names in %s' % path)
    st, names, o = best; N = len(names)
    T = []; Q = []; S = []
    for k in range(N):
        f = struct.unpack_from('<12f', d, o + 48 * k); T.append(f[0:3]); Q.append(f[4:8]); S.append(f[8:11])
    par = None
    for s0 in range(max(0, st - 6 * N - 16), st):
        oo = s0; vals = []
        try:
            for k in range(N):
                v, oo = _svint(d, oo); vals.append(v)
        except IndexError:
            continue
        if oo <= st and vals[0] == -1 and all(-1 <= vals[k] < k for k in range(1, N)):
            par = vals; break
    if par is None: raise ValueError('no parent list in %s' % path)
    return names, par, np.array(T), np.array(Q), np.array(S)


def parents(path):
    names, par, T, Q, S = parse(path)
    return {b: (names[p] if p >= 0 else None) for b, p in zip(names, par)}
