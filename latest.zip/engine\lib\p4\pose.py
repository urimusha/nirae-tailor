"""approximate animation test: pose skin + cloth with linear blend skinning (pivots estimated from weight rings)
usage: pose.py OUT.mdl BUILD [chest/belly/hips]   |  pose.py --author cfg.json size"""
import sys, json
from surf import *
LEFT=('j_asi_a_l','j_asi_b_l','j_asi_c_l','j_asi_d_l','iv_daitai_phys_l','ya_daitai_phys_l')
RIGHT=tuple(n[:-1]+'r' for n in LEFT)
def rotm(axis,deg):
    a=np.radians(deg); c,s=np.cos(a),np.sin(a); x,y,z=axis
    return np.array([[c+x*x*(1-c),x*y*(1-c)-z*s,x*z*(1-c)+y*s],[y*x*(1-c)+z*s,c+y*y*(1-c),y*z*(1-c)-x*s],[z*x*(1-c)-y*s,z*y*(1-c)+x*s,c+z*z*(1-c)]])
def pivot(P,W,names,fam):
    f=W[:,[i for i,n in enumerate(names) if n in fam]].sum(1); k=(f>0.3)&(f<0.7)&(P[:,1]>0.75)
    return P[k].mean(0)
def pose_pts(P,W,names,piv,spec):
    """spec: list of (family, R, pivot) rotations, and translations {bone: vec}"""
    out=P.copy()
    for fam,R,c in spec['rot']:
        f=W[:,[i for i,n in enumerate(names) if n in fam]].sum(1)
        out+=f[:,None]*((P-c)@R.T+c-P)
    for b,v in spec.get('tr',{}).items():
        if b in names: out+=W[:,[names.index(b)]]*np.array(v)
    return out
def poses(cl,cr):
    X=(1,0,0); Z=(0,0,1)
    return {'walk':{'rot':[(LEFT,rotm(X,-40),cl),(RIGHT,rotm(X,20),cr)]},
            'stride_back':{'rot':[(LEFT,rotm(X,25),cl),(RIGHT,rotm(X,-25),cr)]},
            'abduct':{'rot':[(LEFT,rotm(Z,30),cl),(RIGHT,rotm(Z,-30),cr)]},
            'sit':{'rot':[(LEFT,rotm(X,-85),cl),(RIGHT,rotm(X,-85),cr)]},
            'jiggle':{'rot':[],'tr':{'ya_shiri_phys_l':(0.01,0.015,0.0),'ya_shiri_phys_r':(-0.01,0.015,0.0),'iv_shiri_l':(0.006,-0.01,0),'iv_shiri_r':(-0.006,-0.01,0),
                    'iv_daitai_phys_l':(0.012,0,0.005),'iv_daitai_phys_r':(-0.012,0,0.005),'ya_daitai_phys_l':(0.01,0.005,0),'ya_daitai_phys_r':(-0.01,0.005,0),'iv_fukubu_phys':(0,0,0.01)}}}
bary_=np.array([(i,j,5-i-j) for i in range(6) for j in range(6-i)],float)/5
def test(skin,cloth,tag):
    """skin: (P,T,W,names) ; cloth: list of (P,T,W,names)"""
    SP,ST,SW,SN=skin
    cl=pivot(SP,SW,SN,LEFT); cr=pivot(SP,SW,SN,RIGHT)
    res={}
    for pn,spec in [('rest',{'rot':[]})]+list(poses(cl,cr).items()):
        Q=pose_pts(SP,SW,SN,None,spec); S=Surf(Q,ST,None,np.zeros(len(Q),int))
        tot={}
        for CP,CT,CW,CN in cloth:
            C=pose_pts(CP,CW,CN,None,spec)
            Sm=np.einsum('kb,tbd->tkd',bary_,C[CT]).reshape(-1,3); S0=np.einsum('kb,tbd->tkd',bary_,CP[CT]).reshape(-1,3)
            t,w,q,d=S.closest(Sm); n=S.nrm(t,w); h=np.einsum('nd,nd->n',Sm-q,n)
            ok=d<0.03
            for rn,sel in [('sides',(np.abs(S0[:,0])>0.09)&(S0[:,1]>0.9)),('butt',(S0[:,2]<-0.03)&(np.abs(S0[:,0])<=0.09)),('front',(S0[:,2]>=-0.03)&(np.abs(S0[:,0])<=0.09)&(S0[:,1]>0.88)),('crotch',S0[:,1]<=0.88)]:
                s=sel&ok
                if s.any(): tot.setdefault(rn,[]).append((int((h[s]<0).sum()),int(s.sum()),h[s].min()))
        res[pn]={k:(sum(a for a,_,_ in v),sum(b for _,b,_ in v),min(c for _,_,c in v)) for k,v in tot.items()}
        print(tag,pn.ljust(11),'  '.join('%s %4d/%d inside (min %+.1fmm)'%(k,a,b,c*1000) for k,(a,b,c) in res[pn].items()),flush=True)
    return res
def our(out,build,opt='medium/full/medium'):
    ch,be,hi=opt.split('/'); top,dwn=read(CB+BUILDS[build][0]),read_dwn(build)
    B=our_surface_from(top,dwn,ch,be,hi,with_w=True)
    M=read(out); sel=optsel(ch,be,hi); cl=[]
    for m in M['meshes']:
        if is_skin(m): continue
        P=attr(m,0)[0][:,:3].astype(float); idx=np.frombuffer(m['idx'],np.uint16).astype(int)
        T=np.concatenate([idx[s['off']:s['off']+s['cnt']] for s in m['subs'] if all(sel.get(a[8:].split('_',1)[0])==a[8:].split('_',1)[1] for a in s['attr'] if a.startswith('atrx_cb_'))]).reshape(-1,3)
        cl.append((P,T,dense_w(m),m['table']))
    return (B.P,B.T,B.W,B.names),cl
def author(cfgp,size):
    cfg=json.load(open(cfgp)); X=read(cfg['sizes'][size]); L=read(cfg['legs'])
    lm=[m for m in L['meshes'] if m['mat']=='/mt_c0201b0001_bibo.mtrl'][0]
    subs=[s for s in lm['subs'] if not any(a.startswith('atr_dv_') for a in s['attr'])]
    P=attr(lm,0)[0][:,:3].astype(float); T=tris(lm,subs); W=dense_w(lm)
    cl=[]
    for m in X['meshes']:
        if is_skin(m): continue
        cl.append((attr(m,0)[0][:,:3].astype(float),np.frombuffer(m['idx'],np.uint16).astype(int).reshape(-1,3),dense_w(m),m['table']))
    return (P,T,W,lm['table']),cl
if __name__=='__main__':
    if sys.argv[1]=='--author': test(*author(sys.argv[2],sys.argv[3]),'author')
    else: test(*our(sys.argv[1],sys.argv[2],*(sys.argv[3:4])),sys.argv[2])

def where(skin,cloth,deg_list=((-40,20),(-60,-60),(-85,-85))):
    SP,ST,SW,SN=skin; cl=pivot(SP,SW,SN,LEFT); cr=pivot(SP,SW,SN,RIGHT); print('pivots',cl.round(3),cr.round(3))
    for a,b in deg_list:
        spec={'rot':[(LEFT,rotm((1,0,0),a),cl),(RIGHT,rotm((1,0,0),b),cr)]}
        Q=pose_pts(SP,SW,SN,None,spec); S=Surf(Q,ST,None,np.zeros(len(Q),int))
        for CP,CT,CW,CN in cloth:
            C=pose_pts(CP,CW,CN,None,spec); Sm=np.einsum('kb,tbd->tkd',bary_,C[CT]).reshape(-1,3); S0=np.einsum('kb,tbd->tkd',bary_,CP[CT]).reshape(-1,3)
            t,w,q,d=S.closest(Sm); n=S.nrm(t,w); h=np.einsum('nd,nd->n',Sm-q,n); bad=(d<0.03)&(h<0)
            if bad.any():
                from scipy.cluster.vq import kmeans2
                k=min(4,bad.sum()); cen,lab=kmeans2(S0[bad],k,seed=1,minit='++')
                print(' pose L%+d R%+d inside %d:'%(a,b,bad.sum()),'; '.join('n=%d at x%+.3f y%.3f z%+.3f min%+.1fmm'%((lab==i).sum(),*cen[i],h[bad][lab==i].min()*1000) for i in range(k) if (lab==i).any()))
